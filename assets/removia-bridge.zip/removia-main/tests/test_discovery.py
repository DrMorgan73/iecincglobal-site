import httpx

from bridge import discovery
from conftest import run

DESC = """<?xml version="1.0"?>
<root xmlns="urn:schemas-upnp-org:device-1-0">
  <device>
    <friendlyName>{friendly}</friendlyName>
    <manufacturer>{manufacturer}</manufacturer>
    <modelName>{model}</modelName>
    <serialNumber>{serial}</serialNumber>
  </device>
</root>
"""


def desc(manufacturer, friendly="TV", model="TV", serial="SN1"):
    return DESC.format(manufacturer=manufacturer, friendly=friendly,
                       model=model, serial=serial).encode()


def prelim(host="192.0.2.60", st="", server=""):
    return {"host": host, "location": f"http://{host}:8060/desc.xml",
            "st": st, "server": server, "usn": ""}


def classify(manufacturer, **kw):
    return discovery.classify(
        discovery.parse_description(desc(manufacturer, **kw)), prelim())


def test_parse_ssdp_response_and_prelim():
    raw = ("HTTP/1.1 200 OK\r\n"
           "LOCATION: http://192.0.2.70:8060/desc.xml\r\n"
           "ST: roku:ecp\r\nSERVER: Roku UPnP/1.0\r\n\r\n")
    headers = discovery.parse_ssdp_response(raw)
    p = discovery.ssdp_prelim(headers)
    assert p["host"] == "192.0.2.70"
    assert p["st"] == "roku:ecp"
    assert discovery.ssdp_prelim({}) is None


def test_classify_roku():
    d = classify("Roku", friendly="Roku TV", model="Roku TV")
    assert d["brand"] == "roku" and d["protocol"] == "roku"
    assert d["driver_built"] is True and d["port"] == 8060


def test_classify_samsung():
    d = classify("Samsung Electronics", friendly="Samsung TV", model="QN90B")
    assert d["brand"] == "samsung" and d["protocol"] == "samsung"
    assert d["driver_built"] is True


def test_classify_lg_is_detection_only():
    d = classify("LG Electronics", friendly="LG TV", model="OLED C3")
    assert d["brand"] == "lg" and d["protocol"] == "webos"
    assert d["driver_built"] is False


def test_classify_firetv():
    d = classify("Amazon", friendly="Fire TV", model="AFTKA")
    assert d["brand"] == "firetv" and d["protocol"] == "firetv"
    assert d["driver_built"] is True


def test_classify_famous_google_tv_makes():
    cases = [
        ("Sony Corporation", "BRAVIA", "sony"),
        ("TCL", "TCL TV", "tcl"),
        ("Hisense", "Hisense TV", "hisense"),
        ("TP Vision Europe B.V.", "Philips TV", "philips"),
        ("Xiaomi", "Mi TV", "xiaomi"),
        ("NVIDIA", "SHIELD Android TV", "shield"),
    ]
    for manufacturer, friendly, brand in cases:
        d = classify(manufacturer, friendly=friendly)
        assert d["brand"] == brand, manufacturer
        assert d["protocol"] == "androidtv"
        assert d["driver_built"] is True


def test_classify_generic_google_tv_fallback():
    d = classify("Google Inc.", friendly="Chromecast with Google TV")
    assert d["brand"] == "google_tv" and d["protocol"] == "androidtv"


def test_classify_unknown_renderer_is_listed_not_hidden():
    d = classify("Pioneer", friendly="Plasma")
    assert d["brand"] == "unknown" and d["protocol"] == "unknown"
    assert d["driver_built"] is False


ROKU_INFO = b"""<device-info>
  <serial-number>YN00ZZ999</serial-number>
  <model-name>Roku Ultra</model-name>
  <user-device-name>Bedroom Roku</user-device-name>
  <power-mode>PowerOn</power-mode>
</device-info>"""


def test_probe_roku_and_samsung():
    def handler(request):
        if request.url.host == "192.0.2.82":  # the "missing" TV
            return httpx.Response(404)
        if request.url.path == "/query/device-info":
            return httpx.Response(200, content=ROKU_INFO)
        if request.url.path == "/api/v2/":
            return httpx.Response(200, json={
                "name": "Samsung QN90B",
                "device": {"modelName": "QN90BA", "id": "SAMSN1"}})
        return httpx.Response(404)

    async def go():
        async with httpx.AsyncClient(
                transport=httpx.MockTransport(handler)) as client:
            roku = await discovery.probe_roku("192.0.2.80", 8060, client)
            samsung = await discovery.probe_samsung("192.0.2.81", client)
            missing = await discovery.probe_roku("192.0.2.82", 8060, client)
        return roku, samsung, missing

    roku, samsung, missing = run(go())
    assert roku["name"] == "Bedroom Roku" and roku["serial"] == "YN00ZZ999"
    assert samsung == {"name": "Samsung QN90B", "model": "QN90BA",
                       "serial": "SAMSN1"}
    assert missing is None or missing.get("name") is None


def test_mdns_device_classification():
    d = discovery.mdns_device(
        "Living Room", "192.0.2.90", 8009,
        {"fn": "Living Room TV", "md": "Sony Bravia 4K"},
        "_googlecast._tcp.local.")
    assert d["brand"] == "sony" and d["protocol"] == "androidtv"
    assert d["name"] == "Living Room TV"

    d2 = discovery.mdns_device(
        "Chromecast", "192.0.2.91", 8009,
        {"fn": "Den Chromecast", "md": "Chromecast"},
        "_googlecast._tcp.local.")
    assert d2["brand"] == "google_tv" and d2["protocol"] == "androidtv"

    d3 = discovery.mdns_device(
        "Fire TV", "192.0.2.92", 0, {}, "_amzn-wplay._tcp.local.")
    assert d3["brand"] == "firetv" and d3["protocol"] == "firetv"
