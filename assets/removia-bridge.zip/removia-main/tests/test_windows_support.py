"""Windows bridge support: launchers, token announcement, home-dir
resolution, and the LAN-address helper.

The launchers themselves can only run on Windows (no Windows machine
in CI), so they are checked as files: they must exist, use CRLF line
endings, and contain the steps that mirror start.sh. Everything they
call into the bridge package is tested for real.
"""

from pathlib import Path

import pytest

from bridge import lanip
from bridge.config import ConfigStore, announce_token

REPO = Path(__file__).resolve().parent.parent


# ---------------------------------------------------------- launchers

def _read(name):
    return (REPO / name).read_bytes()


def test_start_bat_exists_with_crlf_and_key_steps():
    raw = _read("start.bat")
    assert b"\r\n" in raw  # cmd.exe wants CRLF batch files
    text = raw.decode("ascii")
    assert "py -3" in text                      # python.org launcher first
    assert "python" in text                     # PATH fallback
    assert "-m venv .venv" in text              # same venv flow as start.sh
    assert ".venv\\Scripts\\python.exe" in text  # Windows venv layout
    assert "pip install -r requirements.txt" in text
    assert "-m bridge.config" in text           # first-run token print
    assert "-m bridge.lanip" in text            # LAN address line
    assert "tailscale ip -4" in text            # Tailscale address line
    assert "uvicorn bridge.app:app" in text
    assert "--port 8765" in text
    assert "python.org" in text                 # missing-Python guidance


def test_double_click_launcher_calls_start_bat():
    raw = _read("Start-RemoVia.bat")
    assert b"\r\n" in raw
    text = raw.decode("ascii")
    assert "%~dp0" in text  # runs from its own folder, like the .command
    assert "call start.bat" in text


# ---------------------------------------------------- token announcer

def test_announce_token_prints_once_with_startsh_wording(tmp_path, capsys):
    store = ConfigStore(root=tmp_path)
    assert announce_token(store) is True
    out = capsys.readouterr().out
    token, _ = store.access_token()
    assert "First run: your RemoVia bridge access token is:" in out
    assert token in out
    assert "Enter it once in the RemoVia page, under Settings." in out
    assert "Anyone with this token can control your TVs. Keep it private." in out
    assert str(store.path) in out
    # Second run: the token exists, so nothing prints.
    assert announce_token(store) is False
    assert capsys.readouterr().out == ""


# ------------------------------------------- home directory resolution

def test_default_home_is_dot_tv_remote_under_user_home(tmp_path, monkeypatch):
    monkeypatch.delenv("TV_REMOTE_HOME", raising=False)
    monkeypatch.setenv("HOME", str(tmp_path))
    if hasattr(Path, "home"):
        # Path.home() reads HOME on POSIX and USERPROFILE on Windows;
        # either way it must land on the folder we just set.
        store = ConfigStore()
        assert store.root == Path.home() / ".tv-remote"
        assert store.root.parent == Path.home()


def test_tv_remote_home_override_expands_tilde(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("TV_REMOTE_HOME", "~/elsewhere")
    store = ConfigStore()
    assert store.root == tmp_path / "elsewhere"


# ------------------------------------------------------------ LAN IP

class _FakeSocket:
    def __init__(self, address):
        self._address = address

    def connect(self, _addr):
        pass

    def getsockname(self):
        return (self._address, 54321)

    def close(self):
        pass


def test_primary_lan_ip_from_outbound_interface(monkeypatch):
    monkeypatch.setattr(lanip.socket, "socket",
                        lambda *a, **k: _FakeSocket("192.0.2.77"))
    assert lanip.primary_lan_ip() == "192.0.2.77"


def test_primary_lan_ip_none_without_route(monkeypatch):
    class Dead(_FakeSocket):
        def connect(self, _addr):
            raise OSError("no route")

    monkeypatch.setattr(lanip.socket, "socket", lambda *a, **k: Dead(""))
    assert lanip.primary_lan_ip() is None


def test_primary_lan_ip_none_for_unspecified(monkeypatch):
    monkeypatch.setattr(lanip.socket, "socket",
                        lambda *a, **k: _FakeSocket("0.0.0.0"))
    assert lanip.primary_lan_ip() is None
