"""End-to-end proof against a simulated Roku.

A real local HTTP server speaks ECP. The test runs the real
discovery identification pipeline (SSDP prelim -> UPnP description ->
classify -> ECP probe) and then drives the real RokuDriver over real
HTTP: key presses, typed text, app list, app launch, power. The
simulator records every request; the test asserts the exact wire
traffic. No real TV is involved.
"""

import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import httpx
import pytest

from bridge import discovery
from bridge.drivers.roku import RokuDriver
from conftest import make_record, run

DEVICE_INFO = """<?xml version="1.0" encoding="UTF-8" ?>
<device-info>
  <serial-number>E2ESERIAL001</serial-number>
  <model-name>Roku TV</model-name>
  <friendly-device-name>Simulated Roku TV</friendly-device-name>
  <user-device-name>Sim Roku</user-device-name>
  <power-mode>PowerOn</power-mode>
</device-info>
"""

DESCRIPTION = """<?xml version="1.0"?>
<root xmlns="urn:schemas-upnp-org:device-1-0">
  <device>
    <friendlyName>Simulated Roku TV</friendlyName>
    <manufacturer>Roku</manufacturer>
    <modelName>Roku TV</modelName>
    <serialNumber>E2ESERIAL001</serialNumber>
  </device>
</root>
"""

APPS = """<?xml version="1.0" encoding="UTF-8" ?>
<apps>
  <app id="12" type="appl" version="5.1.4">Netflix</app>
  <app id="837" type="appl" version="2.0.1">YouTube</app>
</apps>
"""


class SimRokuHandler(BaseHTTPRequestHandler):
    recorded = []

    def log_message(self, *args):  # keep the test output clean
        pass

    def _send(self, body, content_type="text/xml"):
        data = body.encode()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        type(self).recorded.append(("GET", self.path))
        if self.path == "/query/device-info":
            self._send(DEVICE_INFO)
        elif self.path == "/query/apps":
            self._send(APPS)
        elif self.path == "/description.xml":
            self._send(DESCRIPTION)
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        type(self).recorded.append(("POST", self.path))
        self.send_response(200)
        self.send_header("Content-Length", "0")
        self.end_headers()


@pytest.fixture()
def sim_roku():
    SimRokuHandler.recorded = []
    server = ThreadingHTTPServer(("127.0.0.1", 0), SimRokuHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield server.server_address[1]
    server.shutdown()


def recorded_posts():
    return [p for m, p in SimRokuHandler.recorded if m == "POST"]


def test_discovery_to_keypress_end_to_end(sim_roku, store):
    port = sim_roku

    async def go():
        # 1. Discovery: an SSDP prelim points at the sim's description.
        prelim = {
            "host": "127.0.0.1",
            "location": f"http://127.0.0.1:{port}/description.xml",
            "st": "roku:ecp",
            "server": "Roku UPnP/1.0",
            "usn": "uuid:roku",
        }
        async with httpx.AsyncClient(timeout=3.0, trust_env=False) as client:
            device = await discovery.enrich_device(prelim, client)

        # 2. Identification is complete and correct.
        assert device["brand"] == "roku"
        assert device["protocol"] == "roku"
        assert device["driver_built"] is True
        assert device["name"] == "Sim Roku"
        assert device["model"] == "Roku TV"
        assert device["serial"] == "E2ESERIAL001"
        assert device["id"] == "roku-e2eserial001"

        # 3. Drive it with the real driver over real HTTP.
        record = make_record(
            tv_id=device["id"], brand="roku", protocol="roku",
            host="127.0.0.1", port=port)
        driver = RokuDriver(record, store)
        await driver.send_key("home")
        await driver.send_key("select")
        await driver.send_key("5")
        await driver.send_text("Hi")
        apps = await driver.list_apps()
        await driver.launch_app("12")
        await driver.send_key("power")  # sim reports PowerOn -> PowerOff
        await driver.close()
        return apps

    apps = run(go())
    assert apps == [{"id": "12", "name": "Netflix"},
                    {"id": "837", "name": "YouTube"}]
    posts = recorded_posts()
    assert posts == [
        "/keypress/Home",
        "/keypress/Select",
        "/keypress/Lit_5",
        "/keypress/Lit_H",
        "/keypress/Lit_i",
        "/launch/12",
        "/keypress/PowerOff",
    ]
