import threading
from pathlib import Path

import pytest

from bridge.drivers.base import NotPairedError, TVUnreachableError, UnknownKeyError
from bridge.drivers.samsung import SamsungDriver
from conftest import make_record, run


class FakeSamsungClient:
    """Mimics samsungtvws: open() blocks until the 'user' accepts on
    the TV (accepted event), then writes the token file."""

    def __init__(self, token_file):
        self.token_file = Path(token_file)
        self.accepted = threading.Event()
        self.opened = False
        self.keys = []
        self.texts = []
        self.runs = []

    def _has_token(self):
        return self.token_file.exists() and bool(
            self.token_file.read_text().strip())

    def open(self):
        if not self._has_token():
            if not self.accepted.wait(timeout=5):
                raise TimeoutError("user did not accept")
            self.token_file.write_text("token-abc-123")
        self.opened = True

    def close(self):
        self.opened = False

    def send_key(self, key):
        assert self.opened
        self.keys.append(key)

    def send_text(self, text):
        self.texts.append(text)

    def app_list(self):
        return [
            {"appId": "11101200001", "name": "Netflix"},
            {"appId": "3201907018807", "name": "YouTube"},
            {"appId": "3201807016597"},  # name missing on some sets
        ]

    def run_app(self, app_id):
        self.runs.append(app_id)


def make_driver(store):
    fake = FakeSamsungClient(store.samsung_token_file("samsung-tv-1"))
    seen = {}

    def factory(host, port, token_file, name):
        seen.update(host=host, port=port, token_file=token_file, name=name)
        return fake

    driver = SamsungDriver(
        make_record(tv_id="samsung-tv-1", brand="samsung",
                    protocol="samsung", port=None),
        store, client_factory=factory)
    return driver, fake, seen


def pair(driver, fake):
    fake.accepted.set()
    assert run(driver.start_pairing()) == "awaiting_user"
    assert run(driver.complete_pairing()) == "paired"


def test_factory_gets_secure_port_and_token_path(store):
    driver, fake, seen = make_driver(store)
    pair(driver, fake)
    assert seen["port"] == 8002
    assert seen["name"] == "RemoVia"
    assert "tokens" in str(seen["token_file"])


def test_pairing_state_machine(store):
    driver, fake, _ = make_driver(store)
    assert driver.pairing_state() == "not_paired"
    assert "accept the prompt" in driver.pairing_instructions()
    pair(driver, fake)
    assert driver.pairing_state() == "paired"
    # Token persisted by the "TV", so a fresh driver is already paired.
    driver2, _, _ = make_driver(store)
    assert driver2.pairing_state() == "paired"
    assert run(driver2.start_pairing()) == "paired"


def test_pairing_timeout_reports_error(store):
    driver, fake, _ = make_driver(store)
    fake.accepted = threading.Event()  # never set; wait is shortened below
    # Patch the fake's wait so the test does not take 5 s.
    original_wait = fake.accepted.wait
    fake.accepted.wait = lambda timeout=None: original_wait(0.2)
    run(driver.start_pairing())
    with pytest.raises(Exception):
        run(driver.complete_pairing())
    assert driver.pairing_state() == "error"


def test_send_key_before_pairing_is_explained(store):
    driver, _, _ = make_driver(store)
    with pytest.raises(NotPairedError):
        run(driver.send_key("home"))


KEY_NAMES = {
    "power": "KEY_POWER", "home": "KEY_HOME", "back": "KEY_RETURN",
    "menu": "KEY_MENU", "up": "KEY_UP", "down": "KEY_DOWN",
    "left": "KEY_LEFT", "right": "KEY_RIGHT", "select": "KEY_ENTER",
    "vol_up": "KEY_VOLUP", "vol_down": "KEY_VOLDOWN", "mute": "KEY_MUTE",
    "channel_up": "KEY_CHUP", "channel_down": "KEY_CHDOWN",
    "rewind": "KEY_REWIND", "fast_forward": "KEY_FF", "input": "KEY_SOURCE",
    "0": "KEY_0", "7": "KEY_7",
}


def test_key_mapping(store):
    driver, fake, _ = make_driver(store)
    pair(driver, fake)
    for key, wire in KEY_NAMES.items():
        fake.keys.clear()
        run(driver.send_key(key))
        assert fake.keys == [wire], key


def test_play_pause_alternates(store):
    driver, fake, _ = make_driver(store)
    pair(driver, fake)
    run(driver.send_key("play_pause"))
    run(driver.send_key("play_pause"))
    assert fake.keys == ["KEY_PLAY", "KEY_PAUSE"]


def test_text_apps_and_launch(store):
    driver, fake, _ = make_driver(store)
    pair(driver, fake)
    run(driver.send_text("hello"))
    assert fake.texts == ["hello"]
    apps = run(driver.list_apps())
    assert apps[0] == {"id": "11101200001", "name": "Netflix"}
    assert apps[2] == {"id": "3201807016597", "name": "3201807016597"}
    run(driver.launch_app("11101200001"))
    assert fake.runs == ["11101200001"]


def test_unknown_key_rejected(store):
    driver, fake, _ = make_driver(store)
    pair(driver, fake)
    with pytest.raises(UnknownKeyError):
        run(driver.send_key("explode"))


class FlakySamsungClient:
    """A client whose send_key raises ConnectionError a planned number
    of times, then works — mimics the TV dropping the websocket.
    The factory hands out a fresh instance per (re)open, like the real
    library does when the driver reconnects."""

    def __init__(self, failures):
        self.failures_left = failures
        self.opened = False
        self.closed = False
        self.keys = []

    def open(self):
        self.opened = True

    def close(self):
        self.opened = False
        self.closed = True

    def send_key(self, key):
        if self.failures_left > 0:
            self.failures_left -= 1
            raise ConnectionError("websocket closed by the TV")
        assert self.opened
        self.keys.append(key)


def make_flaky_driver(store, failures_plan):
    """Driver with the token already on disk (paired), whose factory
    creates one FlakySamsungClient per open, taking each new client's
    failure count from failures_plan in order (0 once it runs out)."""
    token_file = store.samsung_token_file("samsung-tv-1")
    token_file.parent.mkdir(parents=True, exist_ok=True)
    token_file.write_text("token-abc-123")
    plan = list(failures_plan)
    created = []

    def factory(host, port, token_file_arg, name):
        client = FlakySamsungClient(plan.pop(0) if plan else 0)
        created.append(client)
        return client

    driver = SamsungDriver(
        make_record(tv_id="samsung-tv-1", brand="samsung",
                    protocol="samsung", port=None),
        store, client_factory=factory)
    return driver, created


def test_send_key_reopens_and_retries_when_tv_drops_connection(store):
    # First connection fails its first send (TV closed the websocket);
    # the reopened connection works.
    driver, created = make_flaky_driver(store, failures_plan=[1, 0])
    run(driver.send_key("vol_up"))
    assert len(created) == 2  # factory called again for the reopen
    assert created[0].closed  # the dead client was closed and forgotten
    assert created[1].keys == ["KEY_VOLUP"]  # key delivered on the retry


def test_send_key_always_failing_raises_and_never_reuses_corpse(store):
    # Every connection fails every send: each send_key may open at most
    # twice (initial + exactly one retry) before TVUnreachableError.
    driver, created = make_flaky_driver(store, failures_plan=[9, 9, 9, 9])
    with pytest.raises(TVUnreachableError, match="stopped answering"):
        run(driver.send_key("home"))
    assert len(created) == 2
    # A later call must attempt fresh opens, not reuse a dead client:
    # two more factory clients appear, and it still fails the same way.
    with pytest.raises(TVUnreachableError, match="stopped answering"):
        run(driver.send_key("home"))
    assert len(created) == 4
    assert all(c.closed for c in created)  # no dead client left cached
