"""The bridge access token gate.

The bridge listens on all interfaces (LAN + Tailscale), so every
/api/* call must carry the token the bridge generated on its first
run and stored in ~/.tv-remote/config.json. These tests use the same
fake driver / fake scan as test_api.py, but with clients that are
NOT signed in.
"""

import json

import pytest
from fastapi.testclient import TestClient

from bridge.app import create_app
from bridge.config import ConfigStore
from test_api import fake_factory, fake_scan


@pytest.fixture()
def locked(store):
    """A client with no token header, plus the store's real token."""
    app = create_app(store=store, driver_factory=fake_factory,
                     scan_fn=fake_scan)
    token, _created = store.access_token()
    return TestClient(app), token


def test_token_is_generated_once_and_stored_in_config(store):
    token, created = store.access_token()
    assert created is True
    assert len(token) >= 32
    again, created_again = store.access_token()
    assert again == token and created_again is False
    raw = json.loads(store.path.read_text())
    assert raw["settings"]["access_token"] == token
    # A store re-opened on the same home keeps the same token.
    reopened = ConfigStore(root=store.root)
    assert reopened.access_token()[0] == token


def test_no_token_gets_401(locked):
    client, _token = locked
    for path in ("/api/health", "/api/brands", "/api/tvs"):
        r = client.get(path)
        assert r.status_code == 401, path
        assert "access token" in r.json()["error"]
    r = client.post("/api/discover")
    assert r.status_code == 401


def test_wrong_token_gets_401(locked):
    client, _token = locked
    r = client.get("/api/tvs", headers={"X-RemoVia-Token": "not-the-token"})
    assert r.status_code == 401
    r = client.post("/api/tvs/manual",
                    json={"brand": "roku", "host": "192.0.2.50"},
                    headers={"X-RemoVia-Token": ""})
    assert r.status_code == 401


def test_correct_token_gets_through(locked):
    client, token = locked
    headers = {"X-RemoVia-Token": token}
    assert client.get("/api/health", headers=headers).status_code == 200
    assert client.get("/api/tvs", headers=headers).json() == {"tvs": []}
    r = client.post("/api/tvs/manual",
                    json={"brand": "roku", "host": "192.0.2.51"},
                    headers=headers)
    assert r.status_code == 200
    assert r.json()["tv"]["saved"] is True


def test_page_shell_stays_public(locked):
    # The page itself must load without the token; only its API
    # calls are gated. The token lives in the page's Settings.
    client, _token = locked
    r = client.get("/")
    assert r.status_code == 200
    assert "RemoVia" in r.text


def test_cors_preflight_is_not_blocked(locked):
    # Browsers never send custom headers on a preflight, so OPTIONS
    # must reach the CORS middleware: the hosted page's real calls
    # would otherwise be impossible.
    client, _token = locked
    r = client.options("/api/tvs", headers={
        "Origin": "https://removia.iecincglobal.com",
        "Access-Control-Request-Method": "GET",
        "Access-Control-Request-Headers": "x-removia-token",
    })
    assert r.status_code == 200
    assert r.headers.get("access-control-allow-origin") == \
        "https://removia.iecincglobal.com"
