import pytest

from bridge.drivers.base import NotPairedError, PairingError
from bridge.drivers.firetv import FireTVDriver, escape_adb_text, normalize_apps
from conftest import make_record, run


class FakeFireDevice:
    def __init__(self):
        self.shell = []
        self.launched = []
        self.closed = False

    def adb_shell(self, cmd):
        self.shell.append(cmd)
        return ""

    def get_installed_apps(self):
        return [
            {"app_id": "com.netflix.ninja", "label": "Netflix"},
            ("com.amazon.tv.launcher", "Fire TV Home"),
            "com.hulu.plus",
        ]

    def launch_app(self, app_id):
        self.launched.append(app_id)

    def adb_close(self):
        self.closed = True


class FakeFireFactory:
    """First connect attempts fail until the 'user' authorizes on TV."""

    def __init__(self):
        self.authorized = False
        self.device = FakeFireDevice()
        self.calls = []

    def __call__(self, host, adbkey):
        self.calls.append((host, adbkey))
        if not self.authorized:
            raise Exception("device unauthorized")
        return self.device


def make_driver(store):
    factory = FakeFireFactory()
    driver = FireTVDriver(
        make_record(tv_id="firetv-1", brand="firetv", protocol="firetv"),
        store, device_factory=factory)
    return driver, factory


def pair(driver, factory):
    assert run(driver.start_pairing()) == "awaiting_user"
    factory.authorized = True
    assert run(driver.complete_pairing()) == "paired"


def test_adb_authorize_pairing_flow(store):
    driver, factory = make_driver(store)
    assert driver.pairing_state() == "not_paired"
    assert "authorization" in driver.pairing_instructions()
    pair(driver, factory)
    assert driver.pairing_state() == "paired"
    # The ADB key path is under the config home, never in the repo.
    host, adbkey = factory.calls[0]
    assert host == "192.0.2.10"
    assert "adb" in str(adbkey) and str(adbkey).endswith("adbkey")
    # Marker persisted: a fresh driver reports paired.
    driver2, _ = make_driver(store)
    assert driver2.pairing_state() == "paired"


def test_complete_pairing_before_authorize_fails_plainly(store):
    driver, factory = make_driver(store)
    run(driver.start_pairing())
    with pytest.raises(PairingError):
        run(driver.complete_pairing())
    assert driver.pairing_state() == "awaiting_user"


def test_send_key_before_pairing_is_explained(store):
    driver, _ = make_driver(store)
    with pytest.raises(NotPairedError):
        run(driver.send_key("home"))


KEYEVENT = {
    "power": 26, "home": 3, "back": 4, "menu": 82,
    "up": 19, "down": 20, "left": 21, "right": 22, "select": 23,
    "vol_up": 24, "vol_down": 25, "mute": 164,
    "channel_up": 166, "channel_down": 167,
    "play_pause": 85, "rewind": 89, "fast_forward": 90, "input": 178,
    "0": 7, "3": 10, "9": 16,
}


def test_key_mapping_uses_keyevents(store):
    driver, factory = make_driver(store)
    pair(driver, factory)
    for key, code in KEYEVENT.items():
        factory.device.shell.clear()
        run(driver.send_key(key))
        assert factory.device.shell == [f"input keyevent {code}"], key


def test_text_escaping(store):
    assert escape_adb_text("the news") == "the%snews"
    assert escape_adb_text("it's $5") == "it\\'s%s\\$5"
    driver, factory = make_driver(store)
    pair(driver, factory)
    run(driver.send_text("the news"))
    assert factory.device.shell[-1] == "input text the%snews"


def test_apps_normalization_and_launch(store):
    assert normalize_apps([
        {"app_id": "a.b", "label": "AB"},
        ("c.d", "CD"),
        "e.f",
        {"package": "g.h", "name": "GH"},
        None,
        "",
    ]) == [
        {"id": "a.b", "name": "AB"},
        {"id": "c.d", "name": "CD"},
        {"id": "e.f", "name": "e.f"},
        {"id": "g.h", "name": "GH"},
    ]
    driver, factory = make_driver(store)
    pair(driver, factory)
    apps = run(driver.list_apps())
    assert apps[0] == {"id": "com.netflix.ninja", "name": "Netflix"}
    assert apps[1] == {"id": "com.amazon.tv.launcher", "name": "Fire TV Home"}
    run(driver.launch_app("com.netflix.ninja"))
    assert factory.device.launched == ["com.netflix.ninja"]
