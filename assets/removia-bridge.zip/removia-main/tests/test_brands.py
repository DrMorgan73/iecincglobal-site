from bridge import brands


EXPECTED = {
    "roku": ("roku", "none", True),
    "samsung": ("samsung", "on_tv_accept", True),
    "sony": ("androidtv", "pin", True),
    "tcl": ("androidtv", "pin", True),
    "hisense": ("androidtv", "pin", True),
    "philips": ("androidtv", "pin", True),
    "xiaomi": ("androidtv", "pin", True),
    "shield": ("androidtv", "pin", True),
    "firetv": ("firetv", "adb_authorize", True),
    "lg": ("webos", "on_tv_accept", False),
}


def test_catalog_has_exactly_the_ten_chooser_brands():
    assert {b["id"] for b in brands.BRANDS} == set(EXPECTED)


def test_brand_to_protocol_and_pairing_mapping():
    for brand_id, (protocol, pairing, built) in EXPECTED.items():
        brand = brands.get_brand(brand_id)
        assert brand is not None, brand_id
        assert brand["protocol"] == protocol, brand_id
        assert brand["pairing"] == pairing, brand_id
        assert brand["driver_built"] is built, brand_id


def test_unknown_brand_is_none():
    assert brands.get_brand("vizio") is None
    assert brands.get_brand(None) is None
    assert brands.get_brand("") is None


def test_classify_make_famous_google_tv_makes():
    assert brands.classify_make("Sony Corporation", "BRAVIA XR") == "sony"
    assert brands.classify_make("TCL", None) == "tcl"
    assert brands.classify_make(None, "Hisense U8 TV") == "hisense"
    assert brands.classify_make("TP Vision Europe B.V.", "Philips TV") == "philips"
    assert brands.classify_make("Xiaomi", "Mi TV Stick") == "xiaomi"
    assert brands.classify_make("NVIDIA", "SHIELD Android TV") == "shield"


def test_classify_make_unknown_returns_none():
    assert brands.classify_make("Pioneer", "Plasma Display") is None
    assert brands.classify_make(None, None) is None
    assert brands.classify_make("", "") is None


def test_protocol_tables_cover_every_catalog_protocol():
    protocols = {b["protocol"] for b in brands.BRANDS}
    for protocol in protocols:
        assert protocol in brands.PROTOCOL_DEFAULT_PORTS
        assert protocol in brands.PROTOCOL_PAIRING
        assert protocol in brands.PROTOCOL_DRIVER_BUILT
