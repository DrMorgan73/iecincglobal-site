import json

import pytest

from bridge.config import ConfigStore, check_tv_id, make_tv_id


def test_roundtrip_save_and_load(tmp_path):
    store = ConfigStore(root=tmp_path)
    record = {"id": "roku-abc", "brand": "roku", "protocol": "roku",
              "host": "192.0.2.5", "port": 8060, "name": "Den"}
    store.upsert_tv(record)
    reloaded = ConfigStore(root=tmp_path)
    assert reloaded.get_tv("roku-abc")["name"] == "Den"
    assert len(reloaded.list_tvs()) == 1


def test_upsert_updates_and_remove(tmp_path):
    store = ConfigStore(root=tmp_path)
    store.upsert_tv({"id": "roku-abc", "name": "A", "host": "h", "protocol": "roku"})
    store.upsert_tv({"id": "roku-abc", "name": "B", "host": "h", "protocol": "roku"})
    assert len(store.list_tvs()) == 1
    assert store.get_tv("roku-abc")["name"] == "B"
    assert store.remove_tv("roku-abc") is True
    assert store.remove_tv("roku-abc") is False


def test_secrets_live_outside_config_json(tmp_path):
    store = ConfigStore(root=tmp_path)
    store.samsung_token_file("samsung-1").write_text("the-token")
    store.set_marker("firetv-1", "firetv-paired")
    raw = (tmp_path / "config.json")
    if raw.exists():
        assert "the-token" not in raw.read_text()
    data = json.loads(raw.read_text()) if raw.exists() else {}
    assert "the-token" not in json.dumps(data)
    assert store.has_marker("firetv-1", "firetv-paired")


def test_secret_paths_stay_under_root(tmp_path):
    store = ConfigStore(root=tmp_path)
    cert, key = store.androidtv_cert_paths("sony-1")
    assert str(cert).startswith(str(tmp_path))
    assert str(key).startswith(str(tmp_path))
    assert str(store.firetv_adbkey_path("firetv-1")).startswith(str(tmp_path))


def test_tv_id_safety():
    with pytest.raises(ValueError):
        check_tv_id("../etc/passwd")
    with pytest.raises(ValueError):
        check_tv_id("bad id!")
    assert check_tv_id("roku-abc-123") == "roku-abc-123"


def test_make_tv_id_is_stable_and_path_safe():
    a = make_tv_id("roku", "YN00AB123", "192.0.2.1")
    b = make_tv_id("roku", "YN00AB123", "192.0.2.1")
    assert a == b == "roku-yn00ab123"
    c = make_tv_id("firetv", None, "192.0.2.9")
    assert c == "firetv-192-0-2-9"


def test_default_cors_includes_removia_domain(tmp_path):
    store = ConfigStore(root=tmp_path)
    assert "https://removia.iecincglobal.com" in store.cors_origins()
    assert store.cors_origin_regex()
