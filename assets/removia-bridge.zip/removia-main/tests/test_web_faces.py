"""Remote faces: the Settings picker, the three themes, and the
persisted choice in web/index.html.

The page is one static file; these tests read it as shipped (the same
file the bridge serves and the hosted site publishes) and check the
picker markup, the theme definitions, the localStorage persistence,
and the pre-paint application that avoids a flash of default theme.
"""

import re
from pathlib import Path

WEB = Path(__file__).resolve().parent.parent / "web"
HTML = (WEB / "index.html").read_text()
SW = (WEB / "sw.js").read_text()

FACE_IDS = ["midnight", "daylight", "contrast"]


def _block(selector_pattern):
    match = re.search(selector_pattern + r"\{([^}]*)\}", HTML)
    assert match, f"CSS block not found: {selector_pattern}"
    return match.group(1)


def _var(block, name):
    match = re.search(re.escape(name) + r":\s*([^;]+);", block)
    assert match, f"{name} not set in block"
    return match.group(1).strip()


def test_pre_paint_script_applies_saved_face_before_styles():
    script_at = HTML.index('localStorage.getItem("removia.face")')
    style_at = HTML.index("<style>")
    assert script_at < style_at
    head = HTML[:style_at]
    assert 'setAttribute("data-face"' in head
    for face_id in FACE_IDS:
        assert f'"{face_id}"' in head  # whitelist in the pre-paint script


def test_midnight_is_the_default_root_theme():
    block = _block(r":root")
    assert _var(block, "--bg") == "#0a0e13"  # unchanged original look


def test_each_face_overrides_the_whole_remote():
    blocks = {"midnight": _block(r":root")}
    for face_id in ("daylight", "contrast"):
        blocks[face_id] = _block(r':root\[data-face="' + face_id + r'"\]')
    for name, block in blocks.items():
        for var in ("--bg", "--panel", "--panel2", "--line", "--text",
                    "--muted", "--gold", "--toast-bg"):
            assert var in block, f"{name} theme does not restyle {var}"
    backgrounds = {_var(b, "--bg") for b in blocks.values()}
    panels = {_var(b, "--panel") for b in blocks.values()}
    assert len(backgrounds) == 3 and len(panels) == 3  # clearly distinct


def test_no_hardcoded_panel_colors_left_outside_variables():
    # The spots that used to bypass the variables now use them, so a
    # face really does restyle banners, the power key, and toasts.
    assert "background:var(--banner-bg)" in HTML
    assert "color:var(--power-text)" in HTML
    assert "background:var(--toast-bg)" in HTML
    assert "background:var(--gold-press)" in HTML


def test_picker_lives_in_settings_with_all_faces():
    assert 'id="faceGrid"' in HTML
    assert HTML.index('id="settingsSheet"') < HTML.index('id="faceGrid"')
    for face_id in FACE_IDS:
        assert f'{{id:"{face_id}"' in HTML  # FACES list drives the picker
    assert "Remote face" in HTML


def test_choice_is_persisted_and_applied_on_selection():
    assert 'localStorage.setItem("removia.face"' in HTML
    assert 'get face()' in HTML
    assert "store.face = face.id" in HTML       # selecting writes the key
    assert "applyFace(face.id)" in HTML         # ...and applies at once
    assert "renderFaces()" in HTML              # picker marks the choice


def test_service_worker_cache_bumped_for_the_new_shell():
    assert 'removia-shell-v3' in SW
