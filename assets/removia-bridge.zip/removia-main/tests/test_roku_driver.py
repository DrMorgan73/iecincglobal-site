import httpx
import pytest

from bridge.drivers.base import TVUnreachableError, UnknownKeyError
from bridge.drivers.roku import RokuDriver, parse_apps, parse_device_info
from conftest import make_record, run

DEVICE_INFO = """<?xml version="1.0" encoding="UTF-8" ?>
<device-info>
  <udn>xxxxxxxx</udn>
  <serial-number>YN00AB123456</serial-number>
  <device-id>123456789012</device-id>
  <model-name>Roku TV</model-name>
  <friendly-device-name>Living Room Roku</friendly-device-name>
  <user-device-name>Den TV</user-device-name>
  <power-mode>{power}</power-mode>
</device-info>
"""

APPS = """<?xml version="1.0" encoding="UTF-8" ?>
<apps>
  <app id="12" type="appl" version="5.1.4">Netflix</app>
  <app id="837" type="appl" version="2.0.1">YouTube</app>
</apps>
"""


def make_driver(store, power="PowerOn", fail=False):
    requests = []

    def handler(request: httpx.Request) -> httpx.Response:
        if fail:
            raise httpx.ConnectError("no route", request=request)
        requests.append((request.method, request.url.path))
        path = request.url.path
        if path == "/query/device-info":
            return httpx.Response(200, content=DEVICE_INFO.format(power=power))
        if path == "/query/apps":
            return httpx.Response(200, content=APPS)
        if path.startswith("/keypress/") or path.startswith("/launch/"):
            return httpx.Response(200)
        return httpx.Response(404)

    driver = RokuDriver(
        make_record(port=8060), store,
        transport=httpx.MockTransport(handler),
    )
    return driver, requests


def keypress_paths(requests):
    return [p for m, p in requests if m == "POST" and p.startswith("/keypress/")]


def test_parse_device_info():
    info = parse_device_info(DEVICE_INFO.format(power="PowerOn").encode())
    assert info["name"] == "Den TV"
    assert info["model"] == "Roku TV"
    assert info["serial"] == "YN00AB123456"
    assert info["power_mode"] == "PowerOn"


def test_parse_apps():
    apps = parse_apps(APPS.encode())
    assert apps == [{"id": "12", "name": "Netflix"},
                    {"id": "837", "name": "YouTube"}]


KEY_PATHS = {
    "home": "/keypress/Home",
    "back": "/keypress/Back",
    "menu": "/keypress/Info",
    "up": "/keypress/Up",
    "down": "/keypress/Down",
    "left": "/keypress/Left",
    "right": "/keypress/Right",
    "select": "/keypress/Select",
    "vol_up": "/keypress/VolumeUp",
    "vol_down": "/keypress/VolumeDown",
    "mute": "/keypress/VolumeMute",
    "channel_up": "/keypress/ChannelUp",
    "channel_down": "/keypress/ChannelDown",
    "play_pause": "/keypress/Play",
    "rewind": "/keypress/Rev",
    "fast_forward": "/keypress/Fwd",
    "0": "/keypress/Lit_0",
    "5": "/keypress/Lit_5",
    "9": "/keypress/Lit_9",
}


def test_key_mapping(store):
    driver, requests = make_driver(store)
    for key, path in KEY_PATHS.items():
        requests.clear()
        run(driver.send_key(key))
        assert keypress_paths(requests) == [path], key


def test_power_uses_reported_power_mode(store):
    driver, requests = make_driver(store, power="PowerOn")
    run(driver.send_key("power"))
    assert keypress_paths(requests) == ["/keypress/PowerOff"]

    driver2, requests2 = make_driver(store, power="DisplayOff")
    run(driver2.send_key("power"))
    assert keypress_paths(requests2) == ["/keypress/PowerOn"]


def test_input_cycles_inputs(store):
    driver, requests = make_driver(store)
    run(driver.send_key("input"))
    run(driver.send_key("input"))
    assert keypress_paths(requests) == [
        "/keypress/InputTuner", "/keypress/InputHDMI1"]


def test_text_sends_literal_keys(store):
    driver, requests = make_driver(store)
    run(driver.send_text("A b"))
    # httpx decodes %20 when reading the URL back; on the wire the
    # space goes out percent-encoded as Lit_%20, as ECP expects.
    assert keypress_paths(requests) == [
        "/keypress/Lit_A", "/keypress/Lit_ ", "/keypress/Lit_b"]


def test_apps_and_launch(store):
    driver, requests = make_driver(store)
    apps = run(driver.list_apps())
    assert apps[0] == {"id": "12", "name": "Netflix"}
    run(driver.launch_app("837"))
    assert ("POST", "/launch/837") in requests


def test_unknown_key_rejected(store):
    driver, _ = make_driver(store)
    with pytest.raises(UnknownKeyError):
        run(driver.send_key("explode"))


def test_unreachable_tv_raises_plain_error(store):
    driver, _ = make_driver(store, fail=True)
    with pytest.raises(TVUnreachableError):
        run(driver.send_key("home"))


def test_roku_needs_no_pairing(store):
    driver, _ = make_driver(store)
    assert driver.pairing_state() == "not_required"
    assert driver.capabilities == {
        "text": True, "app_list": True, "app_launch": True}
