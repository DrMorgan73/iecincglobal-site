import pytest
from fastapi.testclient import TestClient

from bridge.app import create_app
from bridge.drivers.base import BaseDriver


class FakeDriver(BaseDriver):
    """Stands in for any built-protocol driver at the API layer."""

    capabilities = {"text": True, "app_list": True, "app_launch": True}
    sent = []

    def __init__(self, record, store):
        super().__init__(record, store)
        self.protocol = record["protocol"]
        from bridge import brands
        self.pairing_method = brands.PROTOCOL_PAIRING[self.protocol]

    def pairing_state(self):
        return "not_required" if self.pairing_method == "none" else "paired"

    async def send_key(self, key):
        from bridge.drivers.base import check_key
        check_key(key)
        FakeDriver.sent.append((self.tv_id, key))

    async def send_text(self, text):
        FakeDriver.sent.append((self.tv_id, "text:" + text))

    async def list_apps(self):
        return [{"id": "12", "name": "Netflix"}]

    async def launch_app(self, app_id):
        FakeDriver.sent.append((self.tv_id, "app:" + app_id))


BUILT = ("roku", "samsung", "androidtv", "firetv")


def fake_factory(record, store):
    if record["protocol"] not in BUILT:
        return None
    return FakeDriver(record, store)


DISCOVERED = [{
    "id": "roku-disc1", "brand": "roku", "protocol": "roku",
    "name": "Found Roku", "model": "Roku TV", "host": "192.0.2.200",
    "port": 8060, "serial": "DISC1", "source": "discovery",
}]


async def fake_scan():
    return [dict(d) for d in DISCOVERED]


@pytest.fixture()
def client(store):
    FakeDriver.sent = []
    app = create_app(store=store, driver_factory=fake_factory,
                     scan_fn=fake_scan)
    client = TestClient(app)
    # The bridge requires its access token on /api/* (test_token_auth.py
    # covers the locked-out cases); this client is signed in, exactly
    # like the web page after the token is entered in Settings.
    token, _created = store.access_token()
    client.headers["X-RemoVia-Token"] = token
    return client


def test_health_and_brands(client):
    health = client.get("/api/health").json()
    assert health["ok"] is True and health["product"] == "RemoVia"
    assert health["owner"] == "International Empire Consultants, Inc."
    brands = client.get("/api/brands").json()["brands"]
    assert len(brands) == 10
    lg = next(b for b in brands if b["id"] == "lg")
    assert lg["driver_built"] is False


def test_manual_add_sony_maps_to_androidtv_pin(client):
    r = client.post("/api/tvs/manual", json={
        "brand": "sony", "host": "192.0.2.40", "name": "Bedroom"})
    assert r.status_code == 200
    tv = r.json()["tv"]
    assert tv["protocol"] == "androidtv"
    assert tv["pairing_method"] == "pin"
    assert tv["saved"] is True
    assert tv["name"] == "Bedroom"


def test_manual_add_requires_brand_and_host(client):
    assert client.post("/api/tvs/manual",
                       json={"brand": "nope", "host": "x"}).status_code == 400
    assert client.post("/api/tvs/manual",
                       json={"brand": "roku", "host": ""}).status_code == 400


def test_lg_is_saved_but_not_controllable(client):
    r = client.post("/api/tvs/manual", json={
        "brand": "lg", "host": "192.0.2.41", "name": "LG Den"})
    tv = r.json()["tv"]
    assert tv["driver_built"] is False
    assert tv["pairing_state"] == "unsupported"
    r2 = client.post(f"/api/tvs/{tv['id']}/key", json={"key": "home"})
    assert r2.status_code == 400
    assert "no driver is built" in r2.json()["error"]


def test_discover_save_and_control_flow(client):
    r = client.post("/api/discover")
    tvs = r.json()["tvs"]
    found = next(t for t in tvs if t["id"] == "roku-disc1")
    assert found["saved"] is False

    r = client.post("/api/tvs/roku-disc1/save", json={"name": "Porch"})
    assert r.json()["tv"]["saved"] is True
    assert r.json()["tv"]["name"] == "Porch"

    r = client.post("/api/tvs/roku-disc1/key", json={"key": "home"})
    assert r.json() == {"ok": True}
    assert FakeDriver.sent == [("roku-disc1", "home")]

    apps = client.get("/api/tvs/roku-disc1/apps").json()
    assert apps == {"apps": [{"id": "12", "name": "Netflix"}]}
    client.post("/api/tvs/roku-disc1/app", json={"app_id": "12"})
    assert FakeDriver.sent[-1] == ("roku-disc1", "app:12")

    pair = client.post("/api/tvs/roku-disc1/pair", json={})
    assert pair.json()["pairing_state"] == "not_required"


def test_bad_key_and_unknown_tv(client):
    client.post("/api/tvs/manual", json={"brand": "roku", "host": "192.0.2.42"})
    tvs = client.get("/api/tvs").json()["tvs"]
    tv_id = tvs[0]["id"]
    r = client.post(f"/api/tvs/{tv_id}/key", json={"key": "explode"})
    assert r.status_code == 400
    assert "Unknown remote key" in r.json()["error"]
    assert client.post("/api/tvs/nope-1/key",
                       json={"key": "home"}).status_code == 404


def test_delete_tv(client):
    client.post("/api/tvs/manual", json={"brand": "roku", "host": "192.0.2.43"})
    tv_id = client.get("/api/tvs").json()["tvs"][0]["id"]
    assert client.delete(f"/api/tvs/{tv_id}").json() == {"ok": True}
    assert client.get("/api/tvs").json()["tvs"] == []


def test_cors_allows_removia_domain(client):
    r = client.get("/api/health",
                   headers={"Origin": "https://removia.iecincglobal.com"})
    assert r.headers.get("access-control-allow-origin") == \
        "https://removia.iecincglobal.com"


def test_ui_is_served_at_root(client):
    r = client.get("/")
    assert r.status_code == 200
    assert "RemoVia" in r.text
    assert "International Empire Consultants, Inc." in r.text
