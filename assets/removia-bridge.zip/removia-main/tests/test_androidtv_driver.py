import pytest
from androidtvremote2 import InvalidAuth

from bridge.drivers.androidtv import AndroidTVDriver
from bridge.drivers.base import (
    NotPairedError,
    PairingError,
    UnsupportedCapabilityError,
)
from conftest import make_record, run

GOOD_PIN = "123456"


class FakeAndroidRemote:
    """Mimics androidtvremote2.AndroidTVRemote."""

    def __init__(self):
        self.paired = False
        self.connected = False
        self.cert_generated = False
        self.pairing_started = False
        self.keys = []
        self.texts = []
        self.launches = []

    async def async_generate_cert_if_missing(self):
        self.cert_generated = True
        return True

    async def async_start_pairing(self):
        self.pairing_started = True

    async def async_finish_pairing(self, code):
        if code != GOOD_PIN:
            raise InvalidAuth("wrong pin")
        self.paired = True

    async def async_connect(self):
        if not self.paired:
            raise InvalidAuth("not paired")
        self.connected = True

    def send_key_command(self, key):
        assert self.connected
        self.keys.append(key)

    def send_text(self, text):
        self.texts.append(text)

    def send_launch_app_command(self, app_id):
        self.launches.append(app_id)

    def disconnect(self):
        self.connected = False


def make_driver(store):
    fake = FakeAndroidRemote()
    seen = {}

    def factory(client_name, certfile, keyfile, host):
        seen.update(client_name=client_name, certfile=certfile,
                    keyfile=keyfile, host=host)
        return fake

    driver = AndroidTVDriver(
        make_record(tv_id="sony-tv-1", brand="sony", protocol="androidtv"),
        store, remote_factory=factory)
    return driver, fake, seen


def pair(driver):
    assert run(driver.start_pairing()) == "awaiting_user"
    assert run(driver.complete_pairing(GOOD_PIN)) == "paired"


def test_pin_pairing_flow(store):
    driver, fake, seen = make_driver(store)
    assert driver.pairing_state() == "not_paired"
    assert "6-digit PIN" in driver.pairing_instructions()
    pair(driver)
    assert fake.cert_generated and fake.pairing_started and fake.connected
    assert seen["client_name"] == "RemoVia"
    assert "certs" in str(seen["certfile"])
    # Marker persisted: a fresh driver for the same TV reports paired.
    driver2, _, _ = make_driver(store)
    assert driver2.pairing_state() == "paired"


def test_wrong_pin_is_a_pairing_error(store):
    driver, _, _ = make_driver(store)
    run(driver.start_pairing())
    with pytest.raises(PairingError):
        run(driver.complete_pairing("000000"))
    assert driver.pairing_state() != "paired"


def test_pin_must_be_six_digits(store):
    driver, _, _ = make_driver(store)
    run(driver.start_pairing())
    with pytest.raises(PairingError):
        run(driver.complete_pairing("123"))
    with pytest.raises(PairingError):
        run(driver.complete_pairing(None))


def test_send_key_before_pairing_is_explained(store):
    driver, _, _ = make_driver(store)
    with pytest.raises(NotPairedError):
        run(driver.send_key("home"))


KEY_NAMES = {
    "power": "POWER", "home": "HOME", "back": "BACK", "menu": "MENU",
    "up": "DPAD_UP", "down": "DPAD_DOWN", "left": "DPAD_LEFT",
    "right": "DPAD_RIGHT", "select": "DPAD_CENTER",
    "vol_up": "VOLUME_UP", "vol_down": "VOLUME_DOWN", "mute": "VOLUME_MUTE",
    "channel_up": "CHANNEL_UP", "channel_down": "CHANNEL_DOWN",
    "play_pause": "MEDIA_PLAY_PAUSE", "rewind": "MEDIA_REWIND",
    "fast_forward": "MEDIA_FAST_FORWARD",
}


def test_key_mapping(store):
    driver, fake, _ = make_driver(store)
    pair(driver)
    for key, wire in KEY_NAMES.items():
        fake.keys.clear()
        run(driver.send_key(key))
        assert fake.keys == [wire], key


def test_digits_and_input_use_raw_keycodes(store):
    driver, fake, _ = make_driver(store)
    pair(driver)
    run(driver.send_key("0"))
    run(driver.send_key("9"))
    run(driver.send_key("input"))
    assert fake.keys == [7, 16, 178]


def test_text_and_launch(store):
    driver, fake, _ = make_driver(store)
    pair(driver)
    run(driver.send_text("news tonight"))
    assert fake.texts == ["news tonight"]
    run(driver.launch_app("com.netflix.ninja"))
    assert fake.launches == ["com.netflix.ninja"]


def test_app_list_is_honestly_unsupported(store):
    driver, _, _ = make_driver(store)
    pair(driver)
    with pytest.raises(UnsupportedCapabilityError) as info:
        run(driver.list_apps())
    assert "cannot list installed apps" in str(info.value)
    assert driver.capabilities["app_list"] is False
    assert driver.capabilities["app_launch"] is True
