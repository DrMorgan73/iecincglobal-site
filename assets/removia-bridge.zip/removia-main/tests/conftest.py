import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest

from bridge.config import ConfigStore


def run(coro):
    """Run a coroutine to completion without pytest-asyncio."""
    return asyncio.run(coro)


@pytest.fixture()
def store(tmp_path):
    return ConfigStore(root=tmp_path / "tv-remote-home")


def make_record(tv_id="test-tv-1", brand="roku", protocol="roku",
                host="192.0.2.10", port=None, name="Test TV"):
    return {
        "id": tv_id,
        "brand": brand,
        "protocol": protocol,
        "host": host,
        "port": port,
        "name": name,
        "model": None,
        "serial": None,
        "source": "manual",
    }
