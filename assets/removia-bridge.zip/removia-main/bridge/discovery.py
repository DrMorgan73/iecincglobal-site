"""Network discovery: find TVs on the LAN and identify the brand.

Two scans run together:

  SSDP/UPnP  - stdlib UDP M-SEARCH. Every smart TV answers. The
               response points at a UPnP description XML that names
               the manufacturer and model. Roku sets are confirmed by
               an ECP device-info call; Samsung sets by their REST
               info endpoint on port 8001.
  mDNS       - Zeroconf browse for Google Cast and Android TV remote
               services. This is how Google TV sets are found even
               when SSDP is quiet, and the advertised model string is
               what classifies the famous makes (Sony, TCL, ...).

Sets RemoVia cannot drive yet (LG webOS, unknown renderers) are still
returned, marked driver_built=False. Nothing is hidden.
"""

from __future__ import annotations

import asyncio
import socket
import xml.etree.ElementTree as ET
from urllib.parse import urlparse

import httpx

from . import brands as brands_mod
from .config import make_tv_id
from .drivers.roku import parse_device_info as parse_roku_info

SSDP_ADDR = ("239.255.255.250", 1900)
MDNS_SERVICES = [
    "_googlecast._tcp.local.",
    "_androidtvremote2._tcp.local.",
    "_amzn-wplay._tcp.local.",
]


# ---------------------------------------------------------------- SSDP

def parse_ssdp_response(raw: str) -> dict:
    headers = {}
    for line in raw.split("\r\n")[1:]:
        if ":" in line:
            name, value = line.split(":", 1)
            headers[name.strip().lower()] = value.strip()
    return headers


def ssdp_prelim(headers: dict) -> dict | None:
    """Cheap first pass over SSDP headers: host + description URL."""
    location = headers.get("location")
    if not location:
        return None
    host = urlparse(location).hostname
    if not host:
        return None
    return {
        "host": host,
        "location": location,
        "st": headers.get("st", ""),
        "server": headers.get("server", ""),
        "usn": headers.get("usn", ""),
    }


def ssdp_scan(timeout: float = 3.0) -> list[dict]:
    """Blocking SSDP scan; run in a thread. Returns prelim dicts."""
    searches = [
        "ssdp:all",
        "roku:ecp",
        "urn:schemas-upnp-org:device:MediaRenderer:1",
        "urn:dial-multiscreen-org:service:dial:1",
    ]
    found: dict[str, dict] = {}
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
    sock.settimeout(timeout)
    try:
        for st in searches:
            request = (
                "M-SEARCH * HTTP/1.1\r\n"
                f"HOST: {SSDP_ADDR[0]}:{SSDP_ADDR[1]}\r\n"
                'MAN: "ssdp:discover"\r\n'
                "MX: 2\r\n"
                f"ST: {st}\r\n\r\n"
            )
            try:
                sock.sendto(request.encode(), SSDP_ADDR)
            except OSError:
                pass
        while True:
            try:
                data, _addr = sock.recvfrom(65535)
            except (socket.timeout, TimeoutError):
                break
            except OSError:
                break
            prelim = ssdp_prelim(parse_ssdp_response(data.decode("utf-8", "replace")))
            if prelim:
                found.setdefault(prelim["location"], prelim)
    finally:
        sock.close()
    return list(found.values())


# ------------------------------------------------------- identification

def parse_description(xml_bytes: bytes) -> dict:
    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError:
        return {}
    ns = {"upnp": "urn:schemas-upnp-org:device-1-0"}
    device = root.find("upnp:device", ns)
    if device is None:
        device = root

    def text(name: str) -> str | None:
        value = device.findtext(f"upnp:{name}", namespaces=ns)
        if value is None:  # tolerate namespace-less documents
            value = device.findtext(name)
        return value.strip() if value else None

    return {
        "manufacturer": text("manufacturer"),
        "model_name": text("modelName"),
        "model_description": text("modelDescription"),
        "friendly_name": text("friendlyName"),
        "serial": text("serialNumber"),
    }


def classify(description: dict, prelim: dict) -> dict:
    """Turn a UPnP description (+ SSDP hints) into a device record."""
    manufacturer = (description.get("manufacturer") or "")
    friendly = description.get("friendly_name")
    model = description.get("model_name")
    haystack = " ".join(
        x for x in [manufacturer, friendly, model, description.get("model_description")] if x
    )
    low = haystack.lower()
    server_low = (prelim.get("server") or "").lower()
    st_low = (prelim.get("st") or "").lower()

    device: dict = {
        "host": prelim["host"],
        "name": friendly,
        "model": model,
        "serial": description.get("serial"),
        "source": "discovery",
    }

    if "roku" in low or "roku" in server_low or st_low.startswith("roku"):
        # The UPnP description lives on the ECP port itself on real sets.
        location_port = urlparse(prelim.get("location") or "").port
        device.update(brand="roku", protocol="roku", port=location_port or 8060)
    elif "samsung" in low:
        device.update(brand="samsung", protocol="samsung", port=8002)
    elif "lg" in low.split() or "lg electronics" in low or "webos" in low:
        device.update(brand="lg", protocol="webos", port=3001)
    elif "amazon" in low or "amazon" in server_low:
        device.update(brand="firetv", protocol="firetv", port=5555)
    else:
        make = brands_mod.classify_make(manufacturer, friendly, model)
        if make:
            device.update(brand=make, protocol="androidtv", port=6466)
        elif any(k in low for k in ("google", "android", "chromecast")):
            device.update(brand="google_tv", protocol="androidtv", port=6466)
        else:
            device.update(brand="unknown", protocol="unknown", port=0)

    brand = brands_mod.get_brand(device["brand"]) or {}
    device["driver_built"] = bool(brand.get("driver_built", False))
    device["id"] = make_tv_id(device["protocol"], device.get("serial"), device["host"])
    if not device.get("name"):
        device["name"] = brand.get("name") or device["host"]
    return device


async def probe_roku(host: str, port: int = 8060, client: httpx.AsyncClient | None = None) -> dict | None:
    """Confirm a Roku and read its real name/model/serial via ECP."""
    own = client is None
    client = client or httpx.AsyncClient(timeout=3.0, trust_env=False)
    try:
        response = await client.get(f"http://{host}:{port}/query/device-info")
        if response.status_code != 200:
            return None
        info = parse_roku_info(response.content)
    except (httpx.HTTPError, ET.ParseError):
        return None
    finally:
        if own:
            await client.aclose()
    return info


async def probe_samsung(host: str, client: httpx.AsyncClient | None = None) -> dict | None:
    """Read a Samsung TV's name/model from its REST info endpoint."""
    own = client is None
    client = client or httpx.AsyncClient(timeout=3.0, trust_env=False)
    try:
        response = await client.get(f"http://{host}:8001/api/v2/")
        if response.status_code != 200:
            return None
        data = response.json()
    except (httpx.HTTPError, ValueError):
        return None
    finally:
        if own:
            await client.aclose()
    device = data.get("device") or {}
    return {
        "name": data.get("name") or device.get("name"),
        "model": device.get("modelName") or device.get("model"),
        "serial": device.get("id") or device.get("serialNumber"),
    }


async def enrich_device(prelim: dict, client: httpx.AsyncClient) -> dict:
    """Full identification for one SSDP prelim: description, classify,
    then a brand probe to confirm and fill in real name/model/serial."""
    description: dict = {}
    try:
        response = await client.get(prelim["location"])
        if response.status_code == 200:
            description = parse_description(response.content)
    except httpx.HTTPError:
        description = {}
    device = classify(description, prelim)
    if device["protocol"] == "roku":
        info = await probe_roku(device["host"], device.get("port", 8060), client)
        if info:
            device.update({k: v for k, v in info.items() if v})
            device["serial"] = info.get("serial") or device.get("serial")
            device["id"] = make_tv_id("roku", device.get("serial"), device["host"])
    elif device["protocol"] == "samsung":
        info = await probe_samsung(device["host"], client)
        if info:
            for key in ("name", "model"):
                if info.get(key):
                    device[key] = info[key]
    return device


# ---------------------------------------------------------------- mDNS

def mdns_device(name: str, host: str, port: int, properties: dict, service_type: str) -> dict:
    """Build a device record from one mDNS advertisement."""
    props = {k.lower(): (v.decode() if isinstance(v, bytes) else v)
             for k, v in (properties or {}).items()}
    model = props.get("md") or props.get("model")
    friendly = props.get("fn") or name
    device: dict = {
        "host": host,
        "name": friendly,
        "model": model,
        "serial": props.get("id"),
        "source": "discovery",
    }
    if service_type.startswith("_amzn"):
        device.update(brand="firetv", protocol="firetv", port=5555)
    else:
        make = brands_mod.classify_make(friendly, model)
        if make:
            device.update(brand=make, protocol="androidtv", port=6466)
        else:
            device.update(brand="google_tv", protocol="androidtv", port=6466)
    device["driver_built"] = True
    device["id"] = make_tv_id(device["protocol"], device.get("serial"), host)
    return device


def mdns_scan(timeout: float = 3.0) -> list[dict]:
    """Blocking Zeroconf browse; run in a thread."""
    from zeroconf import ServiceBrowser, Zeroconf

    found: dict[str, dict] = {}

    class Listener:
        def add_service(self, zc, service_type, name):
            info = zc.get_service_info(service_type, name)
            if info is None:
                return
            addresses = info.parsed_scoped_addresses()
            if not addresses:
                return
            device = mdns_device(
                name, addresses[0], info.port, info.properties or {}, service_type
            )
            found.setdefault(device["host"] + device["protocol"], device)

        def update_service(self, zc, service_type, name):
            self.add_service(zc, service_type, name)

        def remove_service(self, zc, service_type, name):
            pass

    zc = Zeroconf()
    try:
        browsers = [ServiceBrowser(zc, st, Listener()) for st in MDNS_SERVICES]
        import time

        time.sleep(timeout)
        for browser in browsers:
            browser.cancel()
    finally:
        zc.close()
    return list(found.values())


# ---------------------------------------------------------------- scan

async def scan(timeout: float = 3.5) -> list[dict]:
    """Full LAN scan: SSDP + mDNS together, deduplicated."""
    prelims, mdns_devices = await asyncio.gather(
        asyncio.to_thread(ssdp_scan, timeout),
        asyncio.to_thread(mdns_scan, timeout),
    )
    devices: dict[str, dict] = {}
    async with httpx.AsyncClient(timeout=3.0, trust_env=False) as client:
        enriched = await asyncio.gather(
            *(enrich_device(p, client) for p in prelims),
            return_exceptions=True,
        )
    for device in enriched:
        if isinstance(device, dict):
            devices.setdefault(device["host"] + device["protocol"], device)
    for device in mdns_devices:
        key = device["host"] + device["protocol"]
        if key in devices:
            # SSDP record wins for name/model, but keep the mDNS brand
            # classification when SSDP could not classify the make.
            existing = devices[key]
            if existing["protocol"] == "androidtv" and existing["brand"] in (
                "google_tv", "android_tv", "unknown",
            ):
                existing["brand"] = device["brand"]
        else:
            devices[key] = device
    return sorted(devices.values(), key=lambda d: (d.get("name") or "", d["host"]))
