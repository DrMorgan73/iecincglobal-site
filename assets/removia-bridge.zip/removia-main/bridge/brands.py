"""Brand catalog for RemoVia.

One place maps a TV brand the user picks (or discovery classifies) to:
  - the wire protocol the bridge uses to talk to the set,
  - the pairing flow the user will see,
  - whether a full driver is built for that protocol.

Adding a brand later = one entry here plus, for a new protocol, one
driver module. LG webOS is detection-only: it is listed so a set can be
saved and shown, but no driver is built for it yet.
"""

from __future__ import annotations

# Pairing methods (values are part of the API the web UI renders):
#   none          - no pairing step (Roku ECP is open on the LAN)
#   on_tv_accept  - the TV shows an accept prompt; user accepts once
#   pin           - the TV shows a 6-digit PIN; user types it in RemoVia
#   adb_authorize - the TV shows an ADB authorization prompt; user allows it

BRANDS: list[dict] = [
    {"id": "roku",    "name": "Roku",           "protocol": "roku",      "pairing": "none",          "driver_built": True},
    {"id": "samsung", "name": "Samsung",        "protocol": "samsung",   "pairing": "on_tv_accept",  "driver_built": True},
    {"id": "sony",    "name": "Sony",           "protocol": "androidtv", "pairing": "pin",           "driver_built": True},
    {"id": "tcl",     "name": "TCL",            "protocol": "androidtv", "pairing": "pin",           "driver_built": True},
    {"id": "hisense", "name": "Hisense",        "protocol": "androidtv", "pairing": "pin",           "driver_built": True},
    {"id": "philips", "name": "Philips",        "protocol": "androidtv", "pairing": "pin",           "driver_built": True},
    {"id": "xiaomi",  "name": "Xiaomi",         "protocol": "androidtv", "pairing": "pin",           "driver_built": True},
    {"id": "shield",  "name": "NVIDIA Shield",  "protocol": "androidtv", "pairing": "pin",           "driver_built": True},
    {"id": "firetv",  "name": "Amazon Fire TV", "protocol": "firetv",    "pairing": "adb_authorize", "driver_built": True},
    {"id": "lg",      "name": "LG",             "protocol": "webos",     "pairing": "on_tv_accept",  "driver_built": False},
]

# Generic fallbacks used by discovery when a set is identified by system
# but not by a famous make.
GENERIC_BRANDS: dict[str, dict] = {
    "google_tv": {"id": "google_tv", "name": "Google TV", "protocol": "androidtv", "pairing": "pin", "driver_built": True},
    "android_tv": {"id": "android_tv", "name": "Android TV", "protocol": "androidtv", "pairing": "pin", "driver_built": True},
    "unknown": {"id": "unknown", "name": "Unknown TV", "protocol": "unknown", "pairing": "none", "driver_built": False},
}

_BY_ID = {b["id"]: b for b in BRANDS}
_BY_ID.update(GENERIC_BRANDS)

PROTOCOL_DEFAULT_PORTS = {
    "roku": 8060,
    "samsung": 8002,
    "androidtv": 6466,
    "firetv": 5555,
    "webos": 3001,
    "unknown": 0,
}

PROTOCOL_PAIRING = {
    "roku": "none",
    "samsung": "on_tv_accept",
    "androidtv": "pin",
    "firetv": "adb_authorize",
    "webos": "on_tv_accept",
    "unknown": "none",
}

PROTOCOL_DRIVER_BUILT = {
    "roku": True,
    "samsung": True,
    "androidtv": True,
    "firetv": True,
    "webos": False,
    "unknown": False,
}


def get_brand(brand_id: str | None) -> dict | None:
    if not brand_id:
        return None
    return _BY_ID.get(brand_id.lower())


def brand_for_protocol(protocol: str) -> dict:
    """Best generic brand record for a bare protocol (discovery fallback)."""
    for brand in BRANDS:
        if brand["protocol"] == protocol:
            return brand
    return GENERIC_BRANDS.get("google_tv" if protocol == "androidtv" else "unknown")


# Keywords that identify a famous Google TV / Android TV make from SSDP
# description fields or mDNS names. Order matters: first hit wins.
_MAKE_KEYWORDS: list[tuple[str, str]] = [
    ("sony", "sony"),
    ("bravia", "sony"),
    ("tcl", "tcl"),
    ("hisense", "hisense"),
    ("philips", "philips"),
    ("tp vision", "philips"),
    ("tpvision", "philips"),
    ("xiaomi", "xiaomi"),
    ("mi tv", "xiaomi"),
    ("mitv", "xiaomi"),
    ("nvidia", "shield"),
    ("shield", "shield"),
]


def classify_make(*texts: str | None) -> str | None:
    """Return a famous-make brand id if any text names one, else None."""
    haystack = " ".join(t for t in texts if t).lower()
    if not haystack:
        return None
    for keyword, brand_id in _MAKE_KEYWORDS:
        if keyword in haystack:
            return brand_id
    return None
