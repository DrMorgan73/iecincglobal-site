"""RemoVia bridge service.

RemoVia is an asset of International Empire Consultants, Inc.
"""

__product__ = "RemoVia"
__version__ = "0.1.0"
__author__ = "International Empire Consultants, Inc."
