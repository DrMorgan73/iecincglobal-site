"""RemoVia bridge configuration.

Everything the bridge must remember lives OUTSIDE the repo, in one
directory (default ``~/.tv-remote``, override with ``TV_REMOTE_HOME``):

    config.json          saved TVs + bridge settings + access token
    tokens/<tv-id>.txt   Samsung pairing token (written by samsungtvws)
    certs/<tv-id>.*.pem  Android TV pairing certificate + key
    adb/<tv-id>/adbkey   Fire TV ADB key pair
    markers/<tv-id>.*    small "pairing completed" marker files

config.json holds exactly one secret: the bridge's own access token
(see ConfigStore.access_token). It never holds a TV pairing token,
certificate, or key — those live in the subfolders above. Everything
stays on the bridge computer (Mac or Windows PC); nothing secret ever
enters the repo.
"""

from __future__ import annotations

import json
import os
import re
import secrets
from pathlib import Path

_SAFE_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")

DEFAULT_CORS_ORIGINS = [
    "https://removia.iecincglobal.com",
    "http://localhost:8765",
    "http://127.0.0.1:8765",
    "http://localhost:5173",
    "http://127.0.0.1:5173",
]
# Any future preview/production deployment of the RemoVia page on Vercel.
DEFAULT_CORS_ORIGIN_REGEX = r"https://([a-z0-9-]+\.)*vercel\.app"


def make_tv_id(protocol: str, serial: str | None = None, host: str | None = None) -> str:
    """Stable, path-safe id for a TV."""
    basis = (serial or host or "").strip().lower()
    slug = re.sub(r"[^a-z0-9]+", "-", basis).strip("-")[:40]
    if slug:
        return f"{protocol}-{slug}"
    return f"{protocol}-{secrets.token_hex(3)}"


def check_tv_id(tv_id: str) -> str:
    if not _SAFE_ID.match(tv_id or ""):
        raise ValueError(f"Unsafe TV id: {tv_id!r}")
    return tv_id


class ConfigStore:
    def __init__(self, root: Path | None = None) -> None:
        if root is None:
            env = os.environ.get("TV_REMOTE_HOME")
            root = Path(env).expanduser() if env else Path.home() / ".tv-remote"
        self.root = Path(root)
        self.path = self.root / "config.json"
        self._data: dict = {}
        self.load()

    # -- file ---------------------------------------------------------
    def load(self) -> dict:
        if self.path.exists():
            try:
                self._data = json.loads(self.path.read_text())
            except (ValueError, OSError):
                self._data = {}
        if not isinstance(self._data, dict):
            self._data = {}
        self._data.setdefault("version", 1)
        self._data.setdefault("tvs", [])
        return self._data

    def save(self) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(self._data, indent=2))
        tmp.replace(self.path)

    # -- settings -----------------------------------------------------
    @property
    def settings(self) -> dict:
        return self._data.setdefault("settings", {})

    def cors_origins(self) -> list[str]:
        return list(self.settings.get("cors_origins", DEFAULT_CORS_ORIGINS))

    def cors_origin_regex(self) -> str | None:
        return self.settings.get("cors_origin_regex", DEFAULT_CORS_ORIGIN_REGEX)

    def access_token(self) -> tuple[str, bool]:
        """The token the web page must send as ``X-RemoVia-Token``.

        Generated once on first use and stored under settings in
        config.json — on the bridge computer only, never in the repo.
        Returns (token, created): created is True only on the run
        that generates it, so the launcher can print it once.
        """
        token = self.settings.get("access_token")
        if token:
            return token, False
        token = secrets.token_urlsafe(32)
        self.settings["access_token"] = token
        self.save()
        return token, True

    # -- TVs ----------------------------------------------------------
    def list_tvs(self) -> list[dict]:
        return list(self._data.get("tvs", []))

    def get_tv(self, tv_id: str) -> dict | None:
        for tv in self._data.get("tvs", []):
            if tv.get("id") == tv_id:
                return tv
        return None

    def upsert_tv(self, record: dict) -> dict:
        check_tv_id(record["id"])
        tvs = self._data.setdefault("tvs", [])
        for i, tv in enumerate(tvs):
            if tv.get("id") == record["id"]:
                tvs[i] = {**tv, **record}
                self.save()
                return tvs[i]
        tvs.append(record)
        self.save()
        return record

    def remove_tv(self, tv_id: str) -> bool:
        tvs = self._data.get("tvs", [])
        kept = [t for t in tvs if t.get("id") != tv_id]
        if len(kept) == len(tvs):
            return False
        self._data["tvs"] = kept
        self.save()
        return True

    # -- secret + marker paths (contents never enter config.json) -----
    def _subdir(self, name: str) -> Path:
        path = self.root / name
        path.mkdir(parents=True, exist_ok=True)
        return path

    def samsung_token_file(self, tv_id: str) -> Path:
        return self._subdir("tokens") / f"{check_tv_id(tv_id)}.txt"

    def androidtv_cert_paths(self, tv_id: str) -> tuple[Path, Path]:
        check_tv_id(tv_id)
        certs = self._subdir("certs")
        return certs / f"{tv_id}.cert.pem", certs / f"{tv_id}.key.pem"

    def firetv_adbkey_path(self, tv_id: str) -> Path:
        folder = self._subdir("adb") / check_tv_id(tv_id)
        folder.mkdir(parents=True, exist_ok=True)
        return folder / "adbkey"

    def marker_path(self, tv_id: str, kind: str) -> Path:
        return self._subdir("markers") / f"{check_tv_id(tv_id)}.{kind}"

    def set_marker(self, tv_id: str, kind: str) -> None:
        self.marker_path(tv_id, kind).write_text("ok\n")

    def has_marker(self, tv_id: str, kind: str) -> bool:
        return self.marker_path(tv_id, kind).exists()


def announce_token(store: ConfigStore | None = None) -> bool:
    """Print the bridge access token once — on the run that creates it.

    The Windows launcher calls this on every start
    (``python -m bridge.config``); the Mac launcher prints the same
    words from start.sh. Prints nothing when the token already
    exists. Returns True when it printed.
    """
    store = store or ConfigStore()
    token, created = store.access_token()
    if not created:
        return False
    print("")
    print("First run: your RemoVia bridge access token is:")
    print("  " + token)
    print("Enter it once in the RemoVia page, under Settings.")
    print("Anyone with this token can control your TVs. Keep it private.")
    print(f"It is stored in {store.path}")
    print("")
    return True


if __name__ == "__main__":
    announce_token()
