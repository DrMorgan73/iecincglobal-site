"""The bridge machine's primary LAN IPv4 address.

Used by the launchers to print the address the phone page needs.
Stdlib only, and the same trick on macOS, Windows, and Linux: a UDP
"connect" toward a public address makes the OS pick the outbound
interface, and getsockname() reports its address. No packet is sent.

Run directly (``python -m bridge.lanip``) it prints the address, or
nothing when the machine has no LAN route.
"""

from __future__ import annotations

import socket


def primary_lan_ip() -> str | None:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
    except OSError:
        return None
    finally:
        sock.close()
    if not ip or ip == "0.0.0.0":
        return None
    return ip


if __name__ == "__main__":
    found = primary_lan_ip()
    if found:
        print(found)
