"""Google TV / Android TV driver — androidtvremote2 protocol.

Used by Sony, TCL, Hisense, Philips, Xiaomi, NVIDIA Shield, and any
other set running Google TV or Android TV.

Pairing: RemoVia asks the TV to start pairing; the TV shows a 6-digit
PIN; the user types the PIN into RemoVia; the protocol finishes
pairing. The pairing is bound to a per-TV certificate + key stored
outside the repo. A small marker file records that pairing completed,
so listing TVs never needs a network call.
"""

from __future__ import annotations

from pathlib import Path

from .base import (
    BaseDriver,
    NotPairedError,
    PairingError,
    TVUnreachableError,
    UnsupportedCapabilityError,
    check_key,
)

KEY_MAP = {
    "power": "POWER",
    "home": "HOME",
    "back": "BACK",
    "menu": "MENU",
    "up": "DPAD_UP",
    "down": "DPAD_DOWN",
    "left": "DPAD_LEFT",
    "right": "DPAD_RIGHT",
    "select": "DPAD_CENTER",
    "vol_up": "VOLUME_UP",
    "vol_down": "VOLUME_DOWN",
    "mute": "VOLUME_MUTE",
    "channel_up": "CHANNEL_UP",
    "channel_down": "CHANNEL_DOWN",
    "play_pause": "MEDIA_PLAY_PAUSE",
    "rewind": "MEDIA_REWIND",
    "fast_forward": "MEDIA_FAST_FORWARD",
}

# Keys sent as raw Android keycodes (ints) because the protocol enum
# names for digits are KEYCODE_0..KEYCODE_9 (7..16) and TV input is 178.
DIGIT_KEYCODES = {str(d): 7 + d for d in range(10)}
INPUT_KEYCODE = 178  # KEYCODE_TV_INPUT

MARKER_KIND = "androidtv-paired"


def default_remote_factory(client_name: str, certfile: Path, keyfile: Path, host: str):
    from androidtvremote2 import AndroidTVRemote

    return AndroidTVRemote(client_name, str(certfile), str(keyfile), host)


class AndroidTVDriver(BaseDriver):
    protocol = "androidtv"
    pairing_method = "pin"
    capabilities = {"text": True, "app_list": False, "app_launch": True}

    def __init__(self, record: dict, store, remote_factory=None) -> None:
        super().__init__(record, store)
        self.port = self.port or 6466
        self._factory = remote_factory or default_remote_factory
        self._certfile, self._keyfile = store.androidtv_cert_paths(self.tv_id)
        self._remote = None
        self._connected = False
        self._awaiting_pin = False
        self._pair_error: str | None = None

    # -- pairing -------------------------------------------------------
    def _is_paired(self) -> bool:
        return self.store.has_marker(self.tv_id, MARKER_KIND)

    def pairing_state(self) -> str:
        if self._awaiting_pin:
            return "awaiting_user"
        if self._is_paired():
            return "paired"
        if self._pair_error:
            return "error"
        return "not_paired"

    def pairing_instructions(self) -> str:
        state = self.pairing_state()
        if state == "awaiting_user":
            return (
                "Your TV is showing a 6-digit PIN. Type the PIN here, "
                "then tap Pair."
            )
        if state == "error":
            return f"Pairing did not finish. {self._pair_error}"
        return (
            "Tap Start pairing. Your TV shows a 6-digit PIN. "
            "Type the PIN here to finish."
        )

    def _get_remote(self):
        if self._remote is None:
            self._remote = self._factory(
                "RemoVia", self._certfile, self._keyfile, self.host
            )
        return self._remote

    async def start_pairing(self) -> str:
        if self._is_paired():
            return "paired"
        remote = self._get_remote()
        self._pair_error = None
        try:
            await remote.async_generate_cert_if_missing()
            await remote.async_start_pairing()
        except Exception as exc:
            self._pair_error = (
                "The TV did not answer. Check that it is on and on the "
                f"same Wi-Fi. ({type(exc).__name__})"
            )
            raise PairingError(self._pair_error) from exc
        self._awaiting_pin = True
        return "awaiting_user"

    async def complete_pairing(self, code: str | None = None) -> str:
        if not code or len(code.strip()) != 6 or not code.strip().isdigit():
            raise PairingError("Enter the 6-digit PIN shown on the TV.")
        remote = self._get_remote()
        try:
            await remote.async_finish_pairing(code.strip())
        except Exception as exc:
            self._pair_error = (
                "The TV refused that PIN. Check the digits and try again."
            )
            raise PairingError(self._pair_error) from exc
        self._awaiting_pin = False
        # Prove the pairing works and remember it.
        try:
            await remote.async_connect()
            self._connected = True
        except Exception as exc:
            self._pair_error = (
                "Pairing finished, but the first connection failed. "
                f"Try again. ({type(exc).__name__})"
            )
            raise PairingError(self._pair_error) from exc
        self.store.set_marker(self.tv_id, MARKER_KIND)
        self._pair_error = None
        return "paired"

    # -- commands ------------------------------------------------------
    async def _ensure_connected(self):
        remote = self._get_remote()
        if self._connected:
            return remote
        if not self._is_paired():
            raise NotPairedError(
                "This TV is not paired yet. Pair it once from RemoVia setup."
            )
        try:
            await remote.async_generate_cert_if_missing()
            await remote.async_connect()
        except Exception as exc:
            # InvalidAuth here means the TV forgot our certificate.
            from androidtvremote2 import InvalidAuth

            if isinstance(exc, InvalidAuth):
                raise NotPairedError(
                    "The TV no longer accepts RemoVia's pairing. "
                    "Pair it again from RemoVia setup."
                ) from exc
            raise TVUnreachableError(
                f"The TV at {self.host} did not answer. "
                "Check that it is on and on the same Wi-Fi."
            ) from exc
        self._connected = True
        return remote

    async def send_key(self, key: str) -> None:
        check_key(key)
        remote = await self._ensure_connected()
        try:
            if key in DIGIT_KEYCODES:
                remote.send_key_command(DIGIT_KEYCODES[key])
            elif key == "input":
                remote.send_key_command(INPUT_KEYCODE)
            else:
                remote.send_key_command(KEY_MAP[key])
        except Exception as exc:
            self._connected = False
            raise TVUnreachableError(
                f"The TV at {self.host} stopped answering. "
                "Check that it is on and on the same Wi-Fi."
            ) from exc

    async def send_text(self, text: str) -> None:
        remote = await self._ensure_connected()
        try:
            remote.send_text(text)
        except Exception as exc:
            raise TVUnreachableError(
                "Typed text did not reach the TV. Open a search or text "
                "field on the TV first, then send again."
            ) from exc

    async def list_apps(self) -> list[dict]:
        raise UnsupportedCapabilityError(
            "The Google TV remote protocol cannot list installed apps. "
            "You can still launch an app by its package name."
        )

    async def launch_app(self, app_id: str) -> None:
        if not app_id:
            raise UnsupportedCapabilityError("No app package name was given.")
        remote = await self._ensure_connected()
        try:
            remote.send_launch_app_command(app_id)
        except Exception as exc:
            raise TVUnreachableError(
                f"The TV at {self.host} stopped answering."
            ) from exc

    async def close(self) -> None:
        if self._remote is not None:
            try:
                self._remote.disconnect()
            except Exception:
                pass
            self._remote = None
            self._connected = False
