"""Samsung driver — Tizen websocket remote via the samsungtvws library.

Pairing: the first websocket connection without a token makes the TV
show an accept prompt. The user accepts once with the TV's own remote.
The library then writes the token to our token file (outside the repo),
and every later connection is silent. Commands run on the library's
sync client inside worker threads so the bridge stays async.
"""

from __future__ import annotations

import asyncio
import threading
from pathlib import Path

from .base import (
    BaseDriver,
    NotPairedError,
    PairingError,
    TVUnreachableError,
    UnsupportedCapabilityError,
    check_key,
)

KEY_MAP = {
    "power": "KEY_POWER",
    "home": "KEY_HOME",
    "back": "KEY_RETURN",
    "menu": "KEY_MENU",
    "up": "KEY_UP",
    "down": "KEY_DOWN",
    "left": "KEY_LEFT",
    "right": "KEY_RIGHT",
    "select": "KEY_ENTER",
    "vol_up": "KEY_VOLUP",
    "vol_down": "KEY_VOLDOWN",
    "mute": "KEY_MUTE",
    "channel_up": "KEY_CHUP",
    "channel_down": "KEY_CHDOWN",
    "rewind": "KEY_REWIND",
    "fast_forward": "KEY_FF",
    "input": "KEY_SOURCE",  # Samsung cycles sources natively
}
DIGIT_PREFIX = "KEY_"


def default_client_factory(host: str, port: int, token_file: Path, name: str):
    from samsungtvws import SamsungTVWS

    return SamsungTVWS(
        host=host,
        port=port,
        token_file=str(token_file),
        name=name,
        # 30s, not 8: pairing waits on a human pressing Allow on the TV,
        # and an 8s socket timeout kills the handshake before they can
        # (SocketTimeoutException, seen live 2026-10-21 on the 6-series).
        timeout=30.0,
        key_press_delay=0.25,
    )


class SamsungDriver(BaseDriver):
    protocol = "samsung"
    pairing_method = "on_tv_accept"
    capabilities = {"text": True, "app_list": True, "app_launch": True}

    def __init__(self, record: dict, store, client_factory=None) -> None:
        super().__init__(record, store)
        self.port = self.port or 8002
        self._factory = client_factory or default_client_factory
        self._token_file: Path = store.samsung_token_file(self.tv_id)
        self._client = None
        self._opened = False
        self._pair_thread: threading.Thread | None = None
        self._pair_error: str | None = None
        self._play_next = True  # play_pause alternates KEY_PLAY / KEY_PAUSE

    # -- pairing -------------------------------------------------------
    def _has_token(self) -> bool:
        try:
            return self._token_file.exists() and bool(self._token_file.read_text().strip())
        except OSError:
            return False

    def pairing_state(self) -> str:
        if self._pair_thread is not None and self._pair_thread.is_alive():
            return "awaiting_user"
        if self._has_token():
            return "paired"
        if self._pair_error:
            return "error"
        return "not_paired"

    def pairing_instructions(self) -> str:
        state = self.pairing_state()
        if state == "awaiting_user":
            return (
                "Look at your TV now and accept the pairing prompt with the "
                "TV's own remote. Then tap Done."
            )
        if state == "error":
            return f"Pairing did not finish. {self._pair_error}"
        return (
            "Tap Start pairing, then look at your TV and accept the prompt "
            "with the TV's own remote. You only do this once."
        )

    def _open_blocking(self) -> None:
        client = self._factory(self.host, self.port, self._token_file, "RemoVia")
        client.open()
        self._client = client
        self._opened = True

    async def start_pairing(self) -> str:
        if self._has_token():
            return "paired"
        if self._pair_thread is not None and self._pair_thread.is_alive():
            return "awaiting_user"
        self._pair_error = None

        def run() -> None:
            try:
                self._open_blocking()
            except Exception as exc:  # library raises several exception types
                self._pair_error = (
                    "The TV did not accept in time, or it is off. "
                    f"({type(exc).__name__})"
                )

        self._pair_thread = threading.Thread(target=run, daemon=True)
        self._pair_thread.start()
        return "awaiting_user"

    async def complete_pairing(self, code: str | None = None) -> str:
        thread = self._pair_thread
        if thread is not None:
            await asyncio.to_thread(thread.join, 6.0)
        if self._has_token():
            return "paired"
        if thread is not None and thread.is_alive():
            return "awaiting_user"
        if self._pair_error:
            raise PairingError(self._pair_error)
        return self.pairing_state()

    # -- commands ------------------------------------------------------
    async def _ensure_client(self):
        if self._opened and self._client is not None:
            return self._client
        if not self._has_token():
            raise NotPairedError(
                "This Samsung TV is not paired yet. Pair it once from RemoVia setup."
            )
        try:
            await asyncio.to_thread(self._open_blocking)
        except Exception as exc:
            from samsungtvws.exceptions import UnauthorizedError

            if isinstance(exc, UnauthorizedError):
                # The TV forgot our token. Drop it so pairing can rerun.
                try:
                    self._token_file.unlink(missing_ok=True)
                except OSError:
                    pass
                raise NotPairedError(
                    "The TV no longer accepts RemoVia's pairing. "
                    "Pair it again from RemoVia setup."
                ) from exc
            raise TVUnreachableError(
                f"The Samsung TV at {self.host} did not answer. "
                "Check that it is on and on the same Wi-Fi."
            ) from exc
        return self._client

    async def _drop_client(self) -> None:
        """Forget the cached client, closing it quietly.

        Samsung sets close the websocket underneath us (idle timeout,
        input change, sleep), and the cached client then fails every
        send forever. Dropping it makes the next command reopen.
        """
        client, self._client = self._client, None
        self._opened = False
        if client is not None:
            try:
                await asyncio.to_thread(client.close)
            except Exception:
                pass

    async def _call(self, fn, *args):
        client = await self._ensure_client()
        try:
            return await asyncio.to_thread(fn, client, *args)
        except NotPairedError:
            raise
        except Exception:
            pass  # fall through: reopen once and retry below

        # The send failed — most likely the TV dropped the connection.
        # Forget the dead client, reopen, and retry exactly once. If the
        # reopen itself fails, _ensure_client raises the right error
        # (NotPairedError on a forgotten token, TVUnreachableError when
        # the TV does not answer at all).
        await self._drop_client()
        client = await self._ensure_client()
        try:
            return await asyncio.to_thread(fn, client, *args)
        except NotPairedError:
            raise
        except Exception as exc:
            # This connection just failed a send too — it is dead by
            # the same evidence. Drop it so the next command starts
            # with a fresh open instead of a cached corpse.
            await self._drop_client()
            raise TVUnreachableError(
                f"The Samsung TV at {self.host} stopped answering. "
                "Check that it is on and on the same Wi-Fi."
            ) from exc

    async def send_key(self, key: str) -> None:
        check_key(key)
        if key == "play_pause":
            wire = "KEY_PLAY" if self._play_next else "KEY_PAUSE"
            self._play_next = not self._play_next
        elif len(key) == 1 and key.isdigit():
            wire = f"{DIGIT_PREFIX}{key}"
        else:
            wire = KEY_MAP[key]
        await self._call(lambda c, w: c.send_key(w), wire)

    async def send_text(self, text: str) -> None:
        # Samsung accepts typed text while a text field is focused on the TV.
        await self._call(lambda c, t: c.send_text(t), text)

    async def list_apps(self) -> list[dict]:
        raw = await self._call(lambda c: c.app_list())
        apps = []
        for item in raw or []:
            if isinstance(item, dict):
                app_id = item.get("appId") or item.get("app_id") or item.get("id")
                name = item.get("name") or app_id
            else:  # pragma: no cover - defensive
                app_id, name = str(item), str(item)
            if app_id:
                apps.append({"id": str(app_id), "name": str(name)})
        return apps

    async def launch_app(self, app_id: str) -> None:
        if not app_id:
            raise UnsupportedCapabilityError("No app was chosen.")
        await self._call(lambda c, a: c.run_app(a), app_id)

    async def close(self) -> None:
        await self._drop_client()
