"""Amazon Fire TV driver — network ADB via the `androidtv` library.

Fire TV speaks ADB on port 5555. The first connection makes the TV
show an authorization prompt ("Allow network debugging?"). The user
allows it once; the TV then trusts RemoVia's ADB key, which is stored
outside the repo. All commands are Android keyevents sent with
`input keyevent`, which keeps key behavior identical across Fire TV
models. The sync library runs in worker threads.
"""

from __future__ import annotations

import asyncio
from pathlib import Path

from .base import (
    BaseDriver,
    NotPairedError,
    PairingError,
    TVUnreachableError,
    UnsupportedCapabilityError,
    check_key,
)

# Android keyevent codes.
KEY_CODES = {
    "power": 26,
    "home": 3,
    "back": 4,
    "menu": 82,
    "up": 19,
    "down": 20,
    "left": 21,
    "right": 22,
    "select": 23,
    "vol_up": 24,
    "vol_down": 25,
    "mute": 164,
    "channel_up": 166,
    "channel_down": 167,
    "play_pause": 85,
    "rewind": 89,
    "fast_forward": 90,
    "input": 178,
}
DIGIT_KEYCODES = {str(d): 7 + d for d in range(10)}
KEY_CODES.update(DIGIT_KEYCODES)

MARKER_KIND = "firetv-paired"


def escape_adb_text(text: str) -> str:
    """Escape text for `adb shell input text` (spaces become %s)."""
    out = []
    for char in text:
        if char == " ":
            out.append("%s")
        elif char in "'\"\\$`&;|<>()":
            out.append("\\" + char)
        else:
            out.append(char)
    return "".join(out)


def default_device_factory(host: str, adbkey: Path):
    from androidtv import setup

    return setup(
        host,
        port=5555,
        adbkey=str(adbkey),
        device_class="firetv",
        auth_timeout_s=15.0,
        log_errors=False,
    )


def normalize_apps(raw) -> list[dict]:
    apps = []
    for item in raw or []:
        if not item:
            continue
        if isinstance(item, dict):
            app_id = item.get("app_id") or item.get("package") or item.get("id")
            name = item.get("label") or item.get("name") or app_id
        elif isinstance(item, (list, tuple)) and item:
            app_id = item[0]
            name = item[1] if len(item) > 1 else item[0]
        else:
            app_id, name = str(item), str(item)
        if app_id:
            apps.append({"id": str(app_id), "name": str(name)})
    return apps


class FireTVDriver(BaseDriver):
    protocol = "firetv"
    pairing_method = "adb_authorize"
    capabilities = {"text": True, "app_list": True, "app_launch": True}

    def __init__(self, record: dict, store, device_factory=None) -> None:
        super().__init__(record, store)
        self.port = self.port or 5555
        self._factory = device_factory or default_device_factory
        self._adbkey: Path = store.firetv_adbkey_path(self.tv_id)
        self._device = None
        self._awaiting = False
        self._pair_error: str | None = None
        self._lock = asyncio.Lock()

    # -- pairing -------------------------------------------------------
    def _is_paired(self) -> bool:
        return self.store.has_marker(self.tv_id, MARKER_KIND)

    def pairing_state(self) -> str:
        if self._awaiting:
            return "awaiting_user"
        if self._is_paired():
            return "paired"
        if self._pair_error:
            return "error"
        return "not_paired"

    def pairing_instructions(self) -> str:
        state = self.pairing_state()
        if state == "awaiting_user":
            return (
                "Look at your Fire TV and allow the network debugging "
                "prompt. Tick 'Always allow' if shown. Then tap Done."
            )
        if state == "error":
            return f"Pairing did not finish. {self._pair_error}"
        return (
            "Tap Start pairing. Your Fire TV shows an authorization "
            "prompt. Allow it once and RemoVia can connect from then on."
        )

    def _connect_blocking(self):
        return self._factory(self.host, self._adbkey)

    async def _try_connect(self) -> bool:
        try:
            self._device = await asyncio.to_thread(self._connect_blocking)
            return True
        except Exception:
            self._device = None
            return False

    async def start_pairing(self) -> str:
        if self._is_paired():
            return "paired"
        self._pair_error = None
        if await self._try_connect():
            self.store.set_marker(self.tv_id, MARKER_KIND)
            self._awaiting = False
            return "paired"
        # A failed first connect is expected: the TV is now showing
        # the authorization prompt (or is off). Report awaiting_user.
        self._awaiting = True
        return "awaiting_user"

    async def complete_pairing(self, code: str | None = None) -> str:
        if await self._try_connect():
            self.store.set_marker(self.tv_id, MARKER_KIND)
            self._awaiting = False
            self._pair_error = None
            return "paired"
        self._pair_error = (
            "The Fire TV has not authorized RemoVia yet, or it is off. "
            "Allow the prompt on the TV, then tap Done again."
        )
        raise PairingError(self._pair_error)

    # -- commands ------------------------------------------------------
    async def _ensure_device(self):
        if self._device is not None:
            return self._device
        if not self._is_paired():
            raise NotPairedError(
                "This Fire TV is not paired yet. Pair it once from RemoVia setup."
            )
        if not await self._try_connect():
            raise TVUnreachableError(
                f"The Fire TV at {self.host} did not answer. "
                "Check that it is on and on the same Wi-Fi."
            )
        return self._device

    async def _shell(self, command: str) -> str:
        device = await self._ensure_device()
        async with self._lock:
            try:
                return await asyncio.to_thread(device.adb_shell, command)
            except Exception as exc:
                self._device = None
                raise TVUnreachableError(
                    f"The Fire TV at {self.host} stopped answering. "
                    "Check that it is on and on the same Wi-Fi."
                ) from exc

    async def send_key(self, key: str) -> None:
        check_key(key)
        await self._shell(f"input keyevent {KEY_CODES[key]}")

    async def send_text(self, text: str) -> None:
        await self._shell(f"input text {escape_adb_text(text)}")

    async def list_apps(self) -> list[dict]:
        device = await self._ensure_device()
        async with self._lock:
            try:
                raw = await asyncio.to_thread(device.get_installed_apps)
            except Exception as exc:
                raise TVUnreachableError(
                    f"The Fire TV at {self.host} stopped answering."
                ) from exc
        return normalize_apps(raw)

    async def launch_app(self, app_id: str) -> None:
        if not app_id:
            raise UnsupportedCapabilityError("No app was chosen.")
        device = await self._ensure_device()
        async with self._lock:
            try:
                await asyncio.to_thread(device.launch_app, app_id)
            except Exception as exc:
                raise TVUnreachableError(
                    f"The Fire TV at {self.host} stopped answering."
                ) from exc

    async def close(self) -> None:
        if self._device is not None:
            try:
                await asyncio.to_thread(self._device.adb_close)
            except Exception:
                pass
            self._device = None
