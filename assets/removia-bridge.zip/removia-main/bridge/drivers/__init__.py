"""Driver factory: one place turns a TV record into a driver."""

from __future__ import annotations

from .androidtv import AndroidTVDriver
from .base import BaseDriver
from .firetv import FireTVDriver
from .roku import RokuDriver
from .samsung import SamsungDriver

DRIVER_CLASSES = {
    "roku": RokuDriver,
    "samsung": SamsungDriver,
    "androidtv": AndroidTVDriver,
    "firetv": FireTVDriver,
    # "webos" is detection-only in this build: no driver class.
}


def create_driver(record: dict, store) -> BaseDriver | None:
    """Return a driver for the record's protocol, or None if the
    protocol has no built driver (LG webOS, unknown sets)."""
    cls = DRIVER_CLASSES.get(record.get("protocol", "unknown"))
    if cls is None:
        return None
    return cls(record, store)
