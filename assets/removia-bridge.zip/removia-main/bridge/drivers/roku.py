"""Roku driver — External Control Protocol (ECP) over plain HTTP.

ECP is documented by Roku and needs no pairing: any device on the LAN
may POST key presses to http://<tv>:8060/keypress/<Key>. The bridge
implements ECP directly on httpx (six endpoints, no session state)
instead of pulling in rokuecp's aiohttp state machinery; this also lets
the test suite assert the exact requests against a simulated Roku.

Endpoints used:
    GET  /query/device-info   name, model, serial, power-mode
    GET  /query/apps          installed channels (XML)
    POST /keypress/<Key>      one key (digits and text use Lit_<char>)
    POST /launch/<app-id>     launch a channel
"""

from __future__ import annotations

import xml.etree.ElementTree as ET
from urllib.parse import quote

import httpx

from .base import (
    BaseDriver,
    TVUnreachableError,
    UnsupportedCapabilityError,
    check_key,
)

KEY_MAP = {
    "home": "Home",
    "back": "Back",
    "menu": "Info",  # Roku's * / options button
    "up": "Up",
    "down": "Down",
    "left": "Left",
    "right": "Right",
    "select": "Select",
    "vol_up": "VolumeUp",
    "vol_down": "VolumeDown",
    "mute": "VolumeMute",
    "channel_up": "ChannelUp",
    "channel_down": "ChannelDown",
    "play_pause": "Play",
    "rewind": "Rev",
    "fast_forward": "Fwd",
}

# ECP has no "next input" key; input cycles these in order.
INPUT_SEQUENCE = [
    "InputTuner", "InputHDMI1", "InputHDMI2", "InputHDMI3", "InputHDMI4", "InputAV1",
]


def parse_device_info(xml_bytes: bytes) -> dict:
    root = ET.fromstring(xml_bytes)

    def text(*names: str) -> str | None:
        for name in names:
            value = root.findtext(name)
            if value:
                return value.strip()
        return None

    return {
        "name": text("user-device-name", "friendly-device-name", "device-name"),
        "model": text("friendly-model-name", "model-name"),
        "serial": text("serial-number", "device-id"),
        "power_mode": text("power-mode"),
    }


def parse_apps(xml_bytes: bytes) -> list[dict]:
    root = ET.fromstring(xml_bytes)
    apps = []
    for app in root.iter("app"):
        app_id = app.get("id")
        if app_id:
            apps.append({"id": app_id, "name": (app.text or app_id).strip()})
    return apps


class RokuDriver(BaseDriver):
    protocol = "roku"
    pairing_method = "none"
    capabilities = {"text": True, "app_list": True, "app_launch": True}

    def __init__(self, record: dict, store, transport: httpx.BaseTransport | None = None) -> None:
        super().__init__(record, store)
        self.port = self.port or 8060
        self._transport = transport
        self._client: httpx.AsyncClient | None = None
        self._input_index = 0

    # -- plumbing ------------------------------------------------------
    def _http(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=f"http://{self.host}:{self.port}",
                timeout=5.0,
                transport=self._transport,
                # TV traffic is LAN-direct; never honor proxy env vars.
                trust_env=False,
            )
        return self._client

    async def _request(self, method: str, path: str) -> httpx.Response:
        try:
            response = await self._http().request(method, path)
        except httpx.HTTPError as exc:
            raise TVUnreachableError(
                f"The Roku at {self.host} did not answer. "
                "Check that it is on and on the same Wi-Fi."
            ) from exc
        if response.status_code >= 400:
            raise TVUnreachableError(
                f"The Roku at {self.host} answered with an error ({response.status_code})."
            )
        return response

    async def device_info(self) -> dict:
        response = await self._request("GET", "/query/device-info")
        return parse_device_info(response.content)

    # -- commands ------------------------------------------------------
    async def send_key(self, key: str) -> None:
        check_key(key)
        if key == "power":
            info = await self.device_info()
            target = "PowerOff" if (info.get("power_mode") or "") == "PowerOn" else "PowerOn"
            await self._request("POST", f"/keypress/{target}")
            return
        if key == "input":
            name = INPUT_SEQUENCE[self._input_index % len(INPUT_SEQUENCE)]
            self._input_index += 1
            await self._request("POST", f"/keypress/{name}")
            return
        if len(key) == 1 and key.isdigit():
            await self._request("POST", f"/keypress/Lit_{key}")
            return
        await self._request("POST", f"/keypress/{KEY_MAP[key]}")

    async def send_text(self, text: str) -> None:
        for char in text:
            await self._request("POST", f"/keypress/Lit_{quote(char, safe='')}")

    async def list_apps(self) -> list[dict]:
        response = await self._request("GET", "/query/apps")
        return parse_apps(response.content)

    async def launch_app(self, app_id: str) -> None:
        if not app_id:
            raise UnsupportedCapabilityError("No app was chosen.")
        await self._request("POST", f"/launch/{quote(app_id, safe='')}")

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None
