"""One driver interface for every TV protocol.

The bridge and the web UI only ever see this interface and the unified
key set below. Each protocol (Roku ECP, Samsung Tizen, Android TV,
Fire TV ADB) maps the unified keys onto its own wire format.

Pairing is a small state machine, identical across drivers:

    not_required   protocol needs no pairing (Roku)
    not_paired     pairing exists but has not completed
    awaiting_user  the TV is showing a prompt / PIN right now
    paired         commands may be sent
    error          the last pairing attempt failed (see instructions)

Drivers never raise raw library exceptions across this boundary; they
raise the RemoVia errors below, which the API turns into plain-language
JSON for the UI. No button in the UI is ever silently dead: every call
either works or returns one of these errors with an explanation.
"""

from __future__ import annotations

DIGITS = [str(i) for i in range(10)]

UNIFIED_KEYS = [
    "power", "home", "back", "menu",
    "up", "down", "left", "right", "select",
    "vol_up", "vol_down", "mute",
    "channel_up", "channel_down",
    "play_pause", "rewind", "fast_forward",
    "input",
] + DIGITS


class RemoViaError(Exception):
    """Base class for all driver errors surfaced to the UI."""


class UnknownKeyError(RemoViaError):
    pass


class UnsupportedCapabilityError(RemoViaError):
    """The brand's API genuinely cannot do this (e.g. list apps)."""


class NotPairedError(RemoViaError):
    pass


class PairingError(RemoViaError):
    pass


class TVUnreachableError(RemoViaError):
    """The TV did not answer: off, asleep, or on another network."""


def check_key(key: str) -> str:
    if key not in UNIFIED_KEYS:
        raise UnknownKeyError(
            f"Unknown remote key {key!r}. Valid keys: {', '.join(UNIFIED_KEYS)}"
        )
    return key


class BaseDriver:
    """Async interface. `record` is the TV dict from config/discovery."""

    protocol: str = "unknown"
    pairing_method: str = "none"
    capabilities: dict = {"text": False, "app_list": False, "app_launch": False}

    def __init__(self, record: dict, store) -> None:
        self.record = record
        self.store = store
        self.tv_id: str = record["id"]
        self.host: str = record["host"]
        self.port: int = int(record.get("port") or 0)

    # -- pairing ------------------------------------------------------
    def pairing_state(self) -> str:
        """Must be cheap and network-free (used when listing TVs)."""
        return "not_required" if self.pairing_method == "none" else "not_paired"

    def pairing_instructions(self) -> str:
        return ""

    async def start_pairing(self) -> str:
        return self.pairing_state()

    async def complete_pairing(self, code: str | None = None) -> str:
        return self.pairing_state()

    # -- commands -----------------------------------------------------
    async def send_key(self, key: str) -> None:
        raise UnsupportedCapabilityError("This TV system has no RemoVia driver yet.")

    async def send_text(self, text: str) -> None:
        raise UnsupportedCapabilityError(
            "This TV system does not accept typed text from RemoVia."
        )

    async def list_apps(self) -> list[dict]:
        raise UnsupportedCapabilityError(
            "This TV system cannot list its installed apps for RemoVia."
        )

    async def launch_app(self, app_id: str) -> None:
        raise UnsupportedCapabilityError(
            "This TV system cannot launch apps from RemoVia."
        )

    async def close(self) -> None:
        pass
