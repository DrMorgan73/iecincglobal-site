"""RemoVia bridge — FastAPI application.

FastAPI was chosen over a stdlib server because the bridge is a small
JSON API with real request validation, and FastAPI + uvicorn are
mature, pip-installable, and documented. The bridge:

  - discovers TVs on the LAN (SSDP + mDNS) and identifies the brand,
  - keeps one driver per TV behind a single REST API,
  - serves the RemoVia web remote (the same static files that are
    hosted at https://removia.iecincglobal.com) as a local fallback,
  - allows the hosted page to call it cross-origin (CORS), because
    page and bridge live on different origins by design.
"""

from __future__ import annotations

import secrets
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from . import __product__, __version__, brands as brands_mod, discovery
from .config import ConfigStore, make_tv_id
from .drivers import create_driver
from .drivers.base import (
    BaseDriver,
    NotPairedError,
    PairingError,
    RemoViaError,
    TVUnreachableError,
    UnknownKeyError,
    UnsupportedCapabilityError,
)

WEB_DIR = Path(__file__).resolve().parent.parent / "web"


def error_response(status: int, message: str, **extra) -> JSONResponse:
    return JSONResponse(status_code=status, content={"error": message, **extra})


class Bridge:
    """Holds bridge state: config store, last scan, live drivers."""

    def __init__(self, store: ConfigStore, driver_factory=None, scan_fn=None) -> None:
        self.store = store
        self.driver_factory = driver_factory or create_driver
        self.scan_fn = scan_fn or discovery.scan
        self.last_scan: list[dict] = []
        self._drivers: dict[str, BaseDriver | None] = {}

    # -- TV records ----------------------------------------------------
    def merged_tvs(self) -> list[dict]:
        saved = {tv["id"]: tv for tv in self.store.list_tvs()}
        merged: list[dict] = []
        seen_hosts: set[tuple[str, str]] = set()
        for tv in self.store.list_tvs():
            merged.append({**tv, "saved": True})
            seen_hosts.add((tv["host"], tv["protocol"]))
        for device in self.last_scan:
            if device["id"] in saved:
                continue
            if (device["host"], device["protocol"]) in seen_hosts:
                continue
            merged.append({**device, "saved": False})
        return merged

    def find_tv(self, tv_id: str) -> dict | None:
        for tv in self.merged_tvs():
            if tv["id"] == tv_id:
                return tv
        return None

    def driver_for(self, record: dict) -> BaseDriver | None:
        key = f"{record['id']}|{record['host']}|{record['protocol']}"
        if key not in self._drivers:
            self._drivers[key] = self.driver_factory(record, self.store)
        return self._drivers[key]

    def drop_driver(self, tv_id: str) -> None:
        for key in [k for k in self._drivers if k.startswith(tv_id + "|")]:
            self._drivers.pop(key, None)

    # -- Views -----------------------------------------------------------
    def tv_view(self, record: dict) -> dict:
        brand = brands_mod.get_brand(record.get("brand")) or {}
        driver = self.driver_for(record)
        driver_built = record.get("protocol") in (
            "roku", "samsung", "androidtv", "firetv",
        )
        view = {
            "id": record["id"],
            "brand": record.get("brand", "unknown"),
            "brand_name": brand.get("name", record.get("brand", "Unknown")),
            "protocol": record.get("protocol", "unknown"),
            "name": record.get("name") or record["host"],
            "model": record.get("model"),
            "host": record["host"],
            "port": record.get("port"),
            "saved": bool(record.get("saved")),
            "source": record.get("source", "discovery"),
            "driver_built": driver_built,
            "pairing_method": brands_mod.PROTOCOL_PAIRING.get(
                record.get("protocol", "unknown"), "none"
            ),
            "pairing_state": "unsupported",
            "pairing_instructions": "",
            "capabilities": {"text": False, "app_list": False, "app_launch": False},
        }
        if driver is not None:
            view["pairing_state"] = driver.pairing_state()
            view["pairing_instructions"] = driver.pairing_instructions()
            view["capabilities"] = dict(driver.capabilities)
        elif not driver_built:
            view["pairing_instructions"] = (
                "RemoVia found this TV, but no driver is built for its "
                "system yet. It is saved here so it is not lost."
            )
        return view


def create_app(store: ConfigStore | None = None, driver_factory=None,
               scan_fn=None, web_dir: Path | None = None) -> FastAPI:
    store = store or ConfigStore()
    bridge = Bridge(store, driver_factory=driver_factory, scan_fn=scan_fn)

    app = FastAPI(title=f"{__product__} bridge", version=__version__)
    app.state.bridge = bridge

    access_token, _token_created = store.access_token()

    @app.middleware("http")
    async def require_access_token(request: Request, call_next):
        # Every /api/* call must carry the bridge access token: the
        # bridge listens on the LAN and on Tailscale, and anyone who
        # can reach the port must not be able to drive the TVs without
        # it. OPTIONS is exempt — CORS preflights never carry custom
        # headers; the real request that follows is checked.
        if request.url.path.startswith("/api/") \
                and request.method != "OPTIONS":
            sent = request.headers.get("x-removia-token") or ""
            if not secrets.compare_digest(sent, access_token):
                return error_response(
                    401,
                    "This bridge is locked. Enter its access token in "
                    "RemoVia Settings. The token was printed by "
                    "start.sh on its first run and is stored in "
                    "~/.tv-remote/config.json.")
        return await call_next(request)

    # CORS is added after the token middleware so it wraps it:
    # preflights are answered by CORS, and error responses (401
    # included) still carry the CORS headers the page needs to read
    # them.
    app.add_middleware(
        CORSMiddleware,
        allow_origins=store.cors_origins(),
        allow_origin_regex=store.cors_origin_regex(),
        allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
        allow_headers=["*"],
    )

    # ------------------------------------------------------------ meta
    @app.get("/api/health")
    async def health():
        return {
            "ok": True,
            "product": __product__,
            "version": __version__,
            "owner": "International Empire Consultants, Inc.",
        }

    @app.get("/api/brands")
    async def list_brands():
        return {"brands": brands_mod.BRANDS}

    # ------------------------------------------------------------ TVs
    @app.get("/api/tvs")
    async def list_tvs():
        return {"tvs": [bridge.tv_view(tv) for tv in bridge.merged_tvs()]}

    @app.post("/api/discover")
    async def run_discover():
        bridge.last_scan = await bridge.scan_fn()
        return {"tvs": [bridge.tv_view(tv) for tv in bridge.merged_tvs()]}

    @app.post("/api/tvs/{tv_id}/discover")
    async def run_discover_for_tv(tv_id: str):
        # A rescan is global by nature (one LAN broadcast); the per-TV
        # route exists so the UI can rescan from a TV's setup screen.
        bridge.last_scan = await bridge.scan_fn()
        return {"tvs": [bridge.tv_view(tv) for tv in bridge.merged_tvs()]}

    @app.post("/api/tvs/manual")
    async def manual_add(request: Request):
        body = await request.json()
        brand = brands_mod.get_brand((body.get("brand") or "").lower())
        host = (body.get("host") or "").strip()
        if brand is None:
            return error_response(400, "Pick a brand from the list first.")
        if not host:
            return error_response(400, "Enter the TV's IP address.")
        protocol = brand["protocol"]
        port = int(body.get("port") or brands_mod.PROTOCOL_DEFAULT_PORTS[protocol])
        existing = next(
            (t for t in bridge.store.list_tvs()
             if t["host"] == host and t["protocol"] == protocol),
            None,
        )
        record = existing or {
            "id": make_tv_id(protocol, None, host),
            "brand": brand["id"],
            "protocol": protocol,
            "host": host,
            "port": port,
            "model": None,
            "serial": None,
            "source": "manual",
        }
        record["name"] = (body.get("name") or "").strip() or record.get("name") \
            or f"{brand['name']} TV"
        bridge.store.upsert_tv(record)
        bridge.drop_driver(record["id"])
        saved = {**bridge.store.get_tv(record["id"]), "saved": True}
        return {"tv": bridge.tv_view(saved)}

    @app.post("/api/tvs/{tv_id}/save")
    async def save_tv(tv_id: str, request: Request):
        record = bridge.find_tv(tv_id)
        if record is None:
            return error_response(404, "That TV is no longer on the list. Rescan.")
        body = {}
        try:
            body = await request.json()
        except Exception:
            body = {}
        name = (body.get("name") or "").strip()
        if name:
            record["name"] = name
        record = {k: v for k, v in record.items() if k != "saved"}
        bridge.store.upsert_tv(record)
        bridge.drop_driver(tv_id)
        saved = {**bridge.store.get_tv(record["id"]), "saved": True}
        return {"tv": bridge.tv_view(saved)}

    @app.delete("/api/tvs/{tv_id}")
    async def delete_tv(tv_id: str):
        bridge.drop_driver(tv_id)
        if bridge.store.remove_tv(tv_id):
            return {"ok": True}
        return error_response(404, "That TV is not saved.")

    # ------------------------------------------------------- pairing
    @app.post("/api/tvs/{tv_id}/pair")
    async def pair_tv(tv_id: str, request: Request):
        record = bridge.find_tv(tv_id)
        if record is None:
            return error_response(404, "That TV is no longer on the list. Rescan.")
        driver = bridge.driver_for(record)
        if driver is None:
            return error_response(
                400, "RemoVia has no driver for this TV system yet.")
        body = {}
        try:
            body = await request.json()
        except Exception:
            body = {}
        pin = (body or {}).get("pin")
        try:
            if pin:
                state = await driver.complete_pairing(str(pin))
            elif driver.pairing_state() in ("not_paired", "error"):
                state = await driver.start_pairing()
            elif driver.pairing_state() == "awaiting_user":
                state = await driver.complete_pairing(None)
            else:
                state = driver.pairing_state()
        except PairingError as exc:
            return error_response(
                400, str(exc), pairing_state=driver.pairing_state(),
                pairing_instructions=driver.pairing_instructions())
        return {
            "pairing_state": state,
            "pairing_instructions": driver.pairing_instructions(),
        }

    # ------------------------------------------------------- commands
    def _driver_or_error(tv_id: str):
        record = bridge.find_tv(tv_id)
        if record is None:
            return None, error_response(
                404, "That TV is no longer on the list. Rescan.")
        driver = bridge.driver_for(record)
        if driver is None:
            return None, error_response(
                400,
                "RemoVia found this TV, but no driver is built for its "
                "system yet, so it cannot be controlled.")
        return driver, None

    async def _run(tv_id: str, action):
        driver, err = _driver_or_error(tv_id)
        if err is not None:
            return err
        try:
            result = await action(driver)
        except UnknownKeyError as exc:
            return error_response(400, str(exc))
        except UnsupportedCapabilityError as exc:
            return error_response(400, str(exc))
        except NotPairedError as exc:
            return error_response(
                409, str(exc), pairing_state=driver.pairing_state(),
                pairing_instructions=driver.pairing_instructions())
        except TVUnreachableError as exc:
            return error_response(502, str(exc))
        except RemoViaError as exc:
            return error_response(400, str(exc))
        return result

    @app.post("/api/tvs/{tv_id}/key")
    async def send_key(tv_id: str, request: Request):
        body = await request.json()
        key = (body or {}).get("key", "")
        return await _run(tv_id, lambda d: _ok(d.send_key(key)))

    @app.post("/api/tvs/{tv_id}/text")
    async def send_text(tv_id: str, request: Request):
        body = await request.json()
        text = (body or {}).get("text", "")
        return await _run(tv_id, lambda d: _ok(d.send_text(text)))

    @app.get("/api/tvs/{tv_id}/apps")
    async def list_apps(tv_id: str):
        async def action(driver):
            return {"apps": await driver.list_apps()}
        return await _run(tv_id, action)

    @app.post("/api/tvs/{tv_id}/app")
    async def launch_app(tv_id: str, request: Request):
        body = await request.json()
        app_id = (body or {}).get("app_id", "")
        return await _run(tv_id, lambda d: _ok(d.launch_app(app_id)))

    async def _ok(awaitable):
        await awaitable
        return {"ok": True}

    # ---------------------------------------------------------- static
    web_root = Path(web_dir) if web_dir is not None else WEB_DIR
    if web_root.exists():
        app.mount("/", StaticFiles(directory=str(web_root), html=True),
                  name="web")
    else:  # pragma: no cover - repo always ships web/
        @app.get("/")
        async def root():
            return {"product": __product__, "api": "/api/health"}

    return app


app = create_app()
