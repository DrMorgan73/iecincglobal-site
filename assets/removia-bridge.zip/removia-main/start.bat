@echo off
rem RemoVia bridge launcher (Windows).
rem First run: creates a Python venv and installs the pinned packages.
rem Every run: starts the bridge on port 8765, on all interfaces,
rem so the phone can reach it on the LAN and over Tailscale.
setlocal
cd /d "%~dp0"

rem --- Find Python: prefer the python.org "py" launcher, then python.
set "PYLAUNCHER="
where py >nul 2>nul
if not errorlevel 1 set "PYLAUNCHER=py -3"
if not defined PYLAUNCHER (
  where python >nul 2>nul
  if not errorlevel 1 set "PYLAUNCHER=python"
)
if not defined PYLAUNCHER (
  echo Python was not found on this PC.
  echo Install Python 3.11 or newer from https://www.python.org/downloads/
  echo and tick "Add python.exe to PATH" on the first setup screen.
  echo Then run start.bat again.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo First run: creating the Python environment...
  %PYLAUNCHER% -m venv .venv
  if errorlevel 1 (
    echo Could not create the Python environment.
    pause
    exit /b 1
  )
  .venv\Scripts\python.exe -m pip install --upgrade pip
  .venv\Scripts\python.exe -m pip install -r requirements.txt
  if errorlevel 1 (
    echo Installing the RemoVia packages failed. Check the network and run start.bat again.
    pause
    exit /b 1
  )
)

rem First run only: create the bridge access token and print it once.
.venv\Scripts\python.exe -m bridge.config

echo RemoVia bridge is starting on port 8765.
echo Open the remote on this machine at http://localhost:8765
set "LAN_IP="
for /f %%i in ('.venv\Scripts\python.exe -m bridge.lanip') do set "LAN_IP=%%i"
if defined LAN_IP echo On the hosted page (removia.iecincglobal.com), set the bridge address to: http://%LAN_IP%:8765
set "TS_IP="
for /f %%i in ('tailscale ip -4 2^>nul') do set "TS_IP=%%i"
if defined TS_IP echo Over Tailscale, set the bridge address to: http://%TS_IP%:8765

.venv\Scripts\python.exe -m uvicorn bridge.app:app --host 0.0.0.0 --port 8765
endlocal
