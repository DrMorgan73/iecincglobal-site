#!/bin/sh
# RemoVia bridge launcher.
# First run: creates a Python venv and installs the pinned packages.
# Every run: starts the bridge on port 8765, on all interfaces,
# so the phone can reach it on the LAN and over Tailscale.
set -e
cd "$(dirname "$0")"

if [ ! -d .venv ]; then
  echo "First run: creating the Python environment..."
  python3 -m venv .venv
  .venv/bin/pip install --upgrade pip
  .venv/bin/pip install -r requirements.txt
fi

# First run only: create the bridge access token and print it once.
.venv/bin/python - <<'PYEOF'
from bridge.config import ConfigStore

token, created = ConfigStore().access_token()
if created:
    print("")
    print("First run: your RemoVia bridge access token is:")
    print("  " + token)
    print("Enter it once in the RemoVia page, under Settings.")
    print("Anyone with this token can control your TVs. Keep it private.")
    print("It is stored in ~/.tv-remote/config.json")
    print("")
PYEOF

echo "RemoVia bridge is starting on port 8765."
echo "Open the remote on this machine at http://localhost:8765"
LAN_IP=$(ipconfig getifaddr en0 2>/dev/null || true)
if [ -n "$LAN_IP" ]; then
  echo "On the hosted page (removia.iecincglobal.com), set the bridge address to: http://$LAN_IP:8765"
fi
TS_IP=$(tailscale ip -4 2>/dev/null | head -n 1 || true)
if [ -n "$TS_IP" ]; then
  echo "Over Tailscale, set the bridge address to: http://$TS_IP:8765"
fi
exec .venv/bin/uvicorn bridge.app:app --host 0.0.0.0 --port 8765
