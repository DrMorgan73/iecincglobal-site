@echo off
rem RemoVia one-click launcher (Windows) - double-click to start the bridge.
rem First run builds its Python environment, prints your access token and
rem the bridge address lines, then serves until this window is closed.
cd /d "%~dp0"
call start.bat
echo.
echo The RemoVia bridge has stopped.
pause
