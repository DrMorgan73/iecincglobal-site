# RemoVia

RemoVia is a universal TV remote. It is an asset of
**International Empire Consultants, Inc.** — © 2026 International
Empire Consultants, Inc. · iecincglobal.com

RemoVia has two parts:

1. A **bridge**. It runs on a Mac or a Windows PC in the home. It
   finds the TVs on the network. It talks to each TV in its own
   protocol.
2. A **web remote**. It is one mobile web page. The hosted copy lives
   at **https://removia.iecincglobal.com**. The bridge also serves the
   same page on the home network, as a fallback.

How the parts fit:

```
Phone ──► removia.iecincglobal.com   (page, hosted on the NEXUS Vercel team)
  │         The page is only files. It holds no data.
  │
  └────► Bridge on Mac or PC ──► TVs on the home Wi-Fi
         Reached over Tailscale.     Roku · Samsung · Google TV ·
         http://100.x.x.x:8765       Android TV · Fire TV
```

The NEXUS team is only the hosting place. The owner is IEC, Inc.
The page cannot reach the home network by itself. The bridge is the
door. Tailscale is the safe path between the phone and the bridge.

## Supported TVs

| Brand (chooser) | System | Pairing |
|---|---|---|
| Roku | Roku ECP (HTTP) | None |
| Samsung | Tizen websocket | Accept once on the TV |
| Sony, TCL, Hisense, Philips, Xiaomi, NVIDIA Shield | Google TV / Android TV | Type the 6-digit PIN shown on the TV |
| Amazon Fire TV | ADB | Allow the prompt once on the TV |
| LG | webOS | Found and saved. No driver yet. |

Auto-discovery is the main path. It uses SSDP and mDNS. It names the
famous Google TV brands (Sony, TCL, Hisense, Philips, Xiaomi, Shield)
when the network data allows it. It falls back to "Google TV".
The brand chooser is the manual path: pick the brand, type the IP
address. Use it when discovery misses a set, or to correct a set.

## What is proven, and what is not

Proven by the test suite in this repo (88 tests):

- Every driver's key map, with fake devices for Samsung, Google TV,
  and Fire TV.
- A simulated Roku on a local HTTP server: discovery identifies it,
  and the driver sends keys, text, app list, and app launch to it.
  The test checks the exact requests.
- The pairing state machines (accept prompt, PIN, ADB allow).
- The full bridge API, brand-to-protocol mapping, and CORS.
- The access token gate: no token gets 401, a wrong token gets 401,
  the right token passes, CORS preflights still work, and the page
  shell itself stays public.

Proven on real hardware (2026-10-21):

- A real Roku TV was controlled end to end from a phone: hosted page
  at removia.iecincglobal.com → Tailscale → Mac bridge → Roku, from
  outside the home network.
- A real Samsung TV (TU700D) was paired from the phone (Allow on the
  TV, pairing token saved) and controlled end to end the same way.
- The hosted page talking to the bridge over Tailscale, and the
  NEXUS deployment with DNS for removia.iecincglobal.com, are live.

Not proven yet:

- The Windows bridge is built and covered by tests, but it has not
  been run on a real Windows machine yet.
- Google TV and Fire TV control are proven against fakes only; no
  real set has been paired yet.
- LG webOS sets are detection-only: the bridge finds and saves them,
  but cannot control them yet.
- Discovery on other home networks (only one real network tested).

## Design choices

- **FastAPI for the bridge.** The bridge is a small JSON API.
  FastAPI gives clean routes and request checks. Uvicorn serves it.
  Both are mature and install with pip.
- **Roku ECP is written directly on httpx.** ECP is six documented
  HTTP calls. The rokuecp library adds a session and state layer the
  bridge does not need. Direct code also lets the tests check the
  exact requests.
- **Samsung uses samsungtvws.** The Tizen websocket handshake and the
  token flow are fiddly. The library is the standard tool for it.
- **Google TV uses androidtvremote2.** It is the reference library
  for the Android TV remote protocol, with PIN pairing built in.
- **Fire TV uses the androidtv library over adb-shell.** Pure Python
  ADB. No Android SDK install is needed on the bridge computer.
- **Secrets never enter this repo.** The bridge has one access
  token. It is generated on its first start. It is stored in
  `~/.tv-remote/config.json`, on the bridge computer only, and every
  API call must carry it. TV pairing tokens, certificates, and ADB
  keys live in subfolders of `~/.tv-remote/`, never in `config.json`.
  (On Windows the same folder is `%USERPROFILE%\.tv-remote\`.)
- **Remote faces.** The page ships three looks — **Midnight** (the
  original dark theme, and the default), **Daylight** (light), and
  **High contrast**. Pick one in Settings under **Remote face**. The
  choice is stored on the device and applied before the page paints,
  so there is no flash of the wrong theme. Appearance only — every
  control behaves exactly as before.

## Install on the Mac

You need: the Mac on the same Wi-Fi as the TVs, and Python 3.11+.

1. Copy this folder to the Mac. Put it at `~/tv-remote`.
2. Open Terminal. Go to the folder: `cd ~/tv-remote`
3. Start the bridge: `./start.sh`
   - The first run builds a Python environment. It takes a few
     minutes. Later runs start at once.
   - The bridge listens on port 8765.
   - On the first start only, it prints the **bridge access token**.
     Keep it. Each device types it into the page once. It is stored
     in `~/.tv-remote/config.json` if you need it again.
4. On the Mac, open http://localhost:8765 — the remote page loads.
   - Tap the gear (top right). Type the access token in **Bridge
     access token**. Tap **Save bridge address**. The page remembers
     the token on this device.
5. On the phone, open http://<mac-ip>:8765 on the same Wi-Fi.
   - Find the Mac IP in System Settings → Wi-Fi → Details.
   - Do the same token step here: gear → **Bridge access token** →
     **Save bridge address**.
6. Add each TV:
   1. Tap **+ TV**, then **Scan the network**.
   2. Tap **Add** on each TV found. Give it a room name.
   3. If a TV is missed: pick its brand, type its IP address, tap
      **Add this TV**.
7. Pair each TV that asks:
   - **Roku:** no pairing. It works at once.
   - **Samsung:** tap **Start pairing**. Look at the TV. Accept the
     prompt with the TV's own remote. Tap **Done**. Once only.
     - If the TV never shows a prompt: on the TV, open Settings →
       General → External Device Manager → Device Connect Manager,
       and allow the phone connection. (Menu names vary by model.)
     - The TV must have "remote access" on: Settings → General →
       Network → Expert Settings → "Power with Mobile" / network
       remote. (Names vary by model.)
   - **Sony / TCL / Hisense / Philips / Xiaomi / Shield:** tap
     **Start pairing**. The TV shows a 6-digit PIN. Type the PIN in
     RemoVia. Tap **Pair with this PIN**.
     - The TV must have the Android TV Remote Service on. It is on
       by default on Google TV sets.
   - **Fire TV:** first turn on ADB debugging: Settings → My Fire TV
     → Developer Options → ADB Debugging → On. Then tap **Start
     pairing**. Allow the prompt on the TV. Tick "Always allow" if
     shown. Tap **Done**.

## Install on Windows

You need: the PC on the same Wi-Fi as the TVs, and Python 3.11+.

1. Install Python from https://www.python.org/downloads/ — on the
   first setup screen, tick **Add python.exe to PATH**. (start.bat
   prefers the `py` launcher that the python.org installer provides,
   and falls back to `python` on PATH.)
2. Copy this folder to the PC. Put it at `%USERPROFILE%\tv-remote`.
3. Open the folder and double-click **Start-RemoVia.bat**. (Or open a
   Command Prompt in the folder and run `start.bat` — same thing.)
   - The first run builds a Python environment in `.venv`. It takes
     a few minutes. Later runs start at once.
   - The bridge listens on port 8765.
   - On the first start only, the window prints the **bridge access
     token**, with the words "First run: your RemoVia bridge access
     token is:". Keep it. Each device types it into the page once.
     It is stored in `%USERPROFILE%\.tv-remote\config.json` if you
     need it again.
   - The window also prints the PC's LAN address and, when Tailscale
     is installed, its Tailscale address — the same lines the Mac
     version prints.
4. **Windows Firewall:** on the first run, Windows asks whether
   Python may accept incoming connections. Tick **Private networks**
   and click **Allow**. Without this, the phone cannot reach the
   bridge — the prompt is the whole step, do not skip it.
5. On the PC, open http://localhost:8765 — the remote page loads.
   Tap the gear (top right). Type the access token in **Bridge
   access token**. Tap **Save bridge address**.
6. On the phone, open the address start.bat printed (the PC's LAN
   address on the same Wi-Fi, or its Tailscale address from
   anywhere). Do the same token step. Then add and pair each TV
   exactly as in steps 6–7 of the Mac install above — the page and
   the pairing flows are identical.

Config, pairing tokens, certificates, and ADB keys live in
`%USERPROFILE%\.tv-remote\` on Windows — the same layout as
`~/.tv-remote/` on the Mac. The code resolves the user's home
folder on both systems; nothing Windows-specific is stored in the
repo.

**Start at sign-in (the Windows counterpart of the launchd setup
below):** press Win+R, type `shell:startup`, press Enter, and put a
shortcut to **Start-RemoVia.bat** in the folder that opens. The
bridge then starts each time you sign in. Close its window to stop
it.

## Let the phone reach the bridge from anywhere (Tailscale)

1. Install Tailscale on the bridge computer (Mac or Windows PC) and
   on the phone. Sign both in to the same account.
2. Find the bridge computer's Tailscale address. It is a 100.x.x.x
   IP, or a name like `your-mac.tail-xxxx.ts.net`.
3. Open RemoVia on the phone. Tap the gear (top right).
4. Type the bridge address: `http://100.x.x.x:8765` — use the real
   address.
5. Type the access token in **Bridge access token** (the same token
   as on the home network). Tap **Save bridge address**.
6. The dot in the header turns green when the phone reaches the
   bridge.

## Publish the hosted page (install time)

1. Deploy the `web/` folder as a static site on the **NEXUS** Vercel
   team. The folder is the whole site. It needs no build step.
2. In IONOS DNS, add a CNAME: `removia` → the Vercel target for the
   project. Add `removia.iecincglobal.com` as the project domain in
   Vercel.
3. The bridge already allows this origin (CORS). The allowed origins
   are in `~/.tv-remote/config.json` under `settings.cors_origins`.
   Any `*.vercel.app` origin is also allowed by pattern.

## Keep the bridge running (launchd)

1. Edit `launchd/com.iecincglobal.removia.plist`. Replace
   `/Users/you/tv-remote` with the real folder path (two places).
2. Copy it: `cp launchd/com.iecincglobal.removia.plist ~/Library/LaunchAgents/`
3. Load it: `launchctl load ~/Library/LaunchAgents/com.iecincglobal.removia.plist`
4. The bridge now starts at login and restarts if it stops.
   Logs go to `/tmp/removia-bridge.log`.
5. To stop it: `launchctl unload ~/Library/LaunchAgents/com.iecincglobal.removia.plist`

## macOS firewall note

1. macOS may ask: allow Python / uvicorn to accept incoming
   connections? Click **Allow**.
2. No prompt, but the phone cannot connect? Open System Settings →
   Network → Firewall → Options. Allow incoming connections for
   Python. Or turn the firewall off on the home network only.

## Add a TV later

1. Open RemoVia. Tap **+ TV**. Tap **Scan the network**.
2. Or add it by brand + IP. Then pair it if it asks (see step 7 of
   the install).

## Bridge API

Base: `http://<bridge>:8765`. All bodies are JSON. Every call must
carry the header `X-RemoVia-Token: <token>`. A call without it, or
with a wrong token, gets `401`. (CORS preflights are exempt, and the
page files at `/` are public — only the API is gated.)

| Call | Purpose |
|---|---|
| `GET /api/health` | Bridge alive check |
| `GET /api/brands` | The brand chooser list |
| `GET /api/tvs` | Saved + found TVs, with pairing state |
| `POST /api/discover` | Rescan the network |
| `POST /api/tvs/{id}/discover` | Rescan (from a TV screen) |
| `POST /api/tvs/manual` | Add by `{brand, host, name?}` |
| `POST /api/tvs/{id}/save` | Save a found TV, or rename `{name}` |
| `DELETE /api/tvs/{id}` | Remove a saved TV |
| `POST /api/tvs/{id}/pair` | Start pairing; `{pin}` completes PIN pairing |
| `POST /api/tvs/{id}/key` | `{key}` — one unified key |
| `POST /api/tvs/{id}/text` | `{text}` — type on the TV |
| `GET /api/tvs/{id}/apps` | Installed apps, where the system allows |
| `POST /api/tvs/{id}/app` | `{app_id}` — launch an app |

Unified keys: `power home back menu up down left right select
vol_up vol_down mute channel_up channel_down play_pause rewind
fast_forward input 0–9`.

Errors always come back as `{"error": "plain words"}`. The page shows
them. No button fails in silence.

## Honest gaps (by design)

- The Google TV remote protocol cannot list installed apps. RemoVia
  says so in the app drawer and offers launch by package name.
- Samsung typed text works only while a text field is open on the TV.
- LG webOS sets are found and saved. They cannot be controlled yet.
  The driver slot for webOS exists in `bridge/drivers/`.

## Run the tests

```
python3 -m venv .venv
.venv/bin/pip install -r requirements-dev.txt
.venv/bin/python -m pytest
```

On Windows the same suite runs with the Windows venv layout:

```
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.venv\Scripts\python.exe -m pytest
```
