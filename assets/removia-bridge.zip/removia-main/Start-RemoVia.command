#!/bin/bash
# RemoVia one-click launcher (macOS) — double-click to start the bridge.
# First run builds its Python environment, prints your access token and
# the bridge address lines, then serves until this window is closed.
cd "$(dirname "$0")"
./start.sh
