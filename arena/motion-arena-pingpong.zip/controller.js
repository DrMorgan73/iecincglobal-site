/* Motion Arena — Ping Pong: phone controller (relay build 1.3.3).
   1.3.3: SWING CALIBRATION FIX — the tilt centre now refreshes
   itself at every serve (the natural pause, phone back at rest)
   from the smoothed tilt, because a match of hard swings drifts
   the player's grip and a once-captured centre quietly goes
   wrong (bat resting off-centre, one edge over-tilted); the
   manual Centre capture also skips the tap transient. Plus the
   phone doubles as a full TV REMOTE — Start / Next Game /
   Restart / End / Sound over the same link.
   1.3.2: FULL bat control from the phone — the pad stream carries
   DEPTH (z) as well as x: in TOUCH MODE the track is a 2-axis pad
   (sideways = across the table, up = step in over the table toward
   the net); in SWING MODE a forward tilt (deviceorientation beta,
   measured against the same deliberate centre capture) steps in.
   A SMASH button (touch mode: arms the host-side smash; swing
   mode: a full-power swing) and a quick up-flick on the track put
   away high balls.
   Joins the TV host by room code over TWO transports carrying the
   same protocol: WebRTC (PeerJS cloud) first with a bounded ~6 s
   wait, then a relay fallback (MQTT over secure WebSocket, relay.js)
   for hosts whose browser never completes a WebRTC data connection
   (the Samsung TV case). Two control modes: SWING MODE — tilt
   (deviceorientation gamma, low-pass filtered, ±1.5° dead-zone,
   ±24° span) moves the bat, a physical swing (devicemotion peak)
   strikes the ball; TOUCH MODE — horizontal drag moves the bat and
   the host auto-contacts (automatic fallback when no motion sensor
   answers within 1.5 s). Bat position streams at ~30 Hz while it is
   changing. Swings are TIMESTAMPED: the phone measures its clock
   offset against the host at join (ping/pong, median of samples)
   and stamps each swing with its true host-time moment, so the
   host's grade windows judge the swing itself, not the transit.
   Tilt centre is a deliberate capture (average over ~0.5 s after
   the "Centre" tap) — never a silent first sample; once set, it
   refreshes silently at each serve from the smoothed tilt while
   the phone is near-still (range guard 10°), so grip drift never
   accumulates across a match.
   Reconnect reclaims the same player slot by token (the host holds
   it ~60 s) — no reload, no side steal. */
(function () {
  'use strict';
  var S = window.PPShared;
  var $ = function (id) { return document.getElementById(id); };

  var chosenColor = S.COLORS[0].hex;
  var chosenGender = 'male';
  var token = '';
  try { token = window.localStorage.getItem('pp-token') || ''; } catch (e) {}
  if (!token) {
    token = 'tok-' + Math.random().toString(36).slice(2, 10);
    try { window.localStorage.setItem('pp-token', token); } catch (e) {}
  }
  try {
    var savedName = window.localStorage.getItem('pp-name');
    if (savedName) $('nameInput').value = savedName;
    var savedColor = window.localStorage.getItem('pp-color');
    if (savedColor) chosenColor = savedColor;
    var savedCode = window.localStorage.getItem('pp-code');
    if (savedCode) $('codeInput').value = savedCode;
    var savedGender = window.localStorage.getItem('pp-gender');
    if (savedGender === 'male' || savedGender === 'female') chosenGender = savedGender;
  } catch (e) {}

  /* avatar variant choice (Male / Female), next to name + colour */
  function refreshGenderPick() {
    var gm = $('btnGenderMale'), gf = $('btnGenderFemale');
    if (gm) gm.classList.toggle('sel', chosenGender === 'male');
    if (gf) gf.classList.toggle('sel', chosenGender === 'female');
  }
  function pickGender(g) {
    chosenGender = g;
    try { window.localStorage.setItem('pp-gender', g); } catch (e) {}
    refreshGenderPick();
  }
  if ($('btnGenderMale')) $('btnGenderMale').addEventListener('click', function () { pickGender('male'); });
  if ($('btnGenderFemale')) $('btnGenderFemale').addEventListener('click', function () { pickGender('female'); });
  refreshGenderPick();

  /* colour swatches */
  var sw = $('swatches');
  S.COLORS.forEach(function (c) {
    var b = document.createElement('button');
    b.className = 'swatch' + (c.hex === chosenColor ? ' sel' : '');
    b.style.background = c.hex;
    b.title = c.name;
    b.setAttribute('aria-label', c.name);
    b.addEventListener('click', function () {
      chosenColor = c.hex;
      try { window.localStorage.setItem('pp-color', c.hex); } catch (e) {}
      var all = sw.querySelectorAll('.swatch');
      for (var i = 0; i < all.length; i++) all[i].classList.remove('sel');
      b.classList.add('sel');
    });
    sw.appendChild(b);
  });

  var peer = null, relayPeerObj = null, conn = null, joined = false;
  var transport = '';                    // 'webrtc' | 'relay' once a link is live
  var linkStage = '';                    // 'rtc' | 'relay' while connecting
  var stageTimer = null;
  var player = -1;                       // 0 or 1 (identity, follows ends switches)
  var myName = 'Player', myColor = chosenColor;
  var controlMode = 'touch';             // 'touch' | 'swing'
  var pos01 = 0.5, lastSent = -1;
  var depth01 = 0, lastSentZ = -1;       // bat depth: 0 = home plane, 1 = at the net (1.3.2)
  var sens = 1.0;
  var gammaCenter = null, lastGamma = null, sensorSeenAt = 0, sensorsLive = false;
  var betaCenter = null, betaSmooth = null;
  var tiltSmooth = null, calibrated = false, calCapture = null;
  var autoCapture = null, lastPhase = '', recentres = 0;   // serve re-centre (1.3.3)
  var clockOffset = null, pingT0 = {}, syncSamples = [];
  var motionPeak = 0, lastSwingAt = 0, lastPower = 0;
  var lastCode = '', lastGradeKey = '';
  var connectDeadline = null, reconnectTimer = null, reconnectTries = 0;
  var hostState = null;

  function show(id) {
    ['joinPanel', 'padPanel', 'errPanel'].forEach(function (p) {
      $(p).classList.toggle('hidden', p !== id);
    });
  }
  function fail(msg) {
    clearTimeout(connectDeadline);
    clearTimeout(stageTimer);
    $('errMsg').textContent = msg;
    show('errPanel');
  }

  /* ---------------- clock sync (swing timing honesty) ----------
     A few ping/pong exchanges against the host; each pong carries
     the host's wall-clock stamp, and the offset sample assumes the
     stamp sits at the round-trip midpoint. The MEDIAN sample is
     the offset (host − phone). Swings are then stamped in host
     time at detection, so the host grades the swing's true moment
     against the ball's plane crossing — detection lag and transit
     no longer eat the PERFECT window. */
  function startClockSync() {
    syncSamples = [];
    pingT0 = {};
    var i = 0;
    var step = function () {
      if (!joined || i >= 5) {
        if (syncSamples.length) {
          var sorted = syncSamples.slice().sort(function (a, b) { return a - b; });
          clockOffset = sorted[Math.floor(sorted.length / 2)];
        }
        return;
      }
      var id = i++;
      pingT0[id] = Date.now();
      send({ t: 'ping', id: id, t0: pingT0[id] });
      setTimeout(step, 120);
    };
    step();
  }
  function joinMsg(txt, isErr) {
    var m = $('joinMsg');
    m.textContent = txt;
    m.className = 'msg' + (isErr ? ' err' : '');
  }
  function padStatus(txt) { $('padStatus').textContent = txt; }
  function send(msg) {
    if (conn && conn.open) { try { conn.send(msg); return true; } catch (e) {} }
    return false;
  }

  /* ---------------- connection: WebRTC first, relay fallback ----
     Phase 1 tries the direct WebRTC link for a bounded wait
     (?rtcWait, default 6 s; 3.5 s on reconnect). Any failure —
     timeout, broker error, a room the cloud cannot see — moves to
     phase 2, the relay, under the same protocol. A room missing on
     BOTH clouds is the "not found" error; a room that never answers
     on either is the "could not reach in time" error. */
  function join() {
    var code = $('codeInput').value.trim().toUpperCase();
    if (code.length !== 4) { joinMsg('Enter the 4-letter room code from the TV.', true); return; }
    var name = $('nameInput').value.trim() || 'Player';
    myName = name;
    myColor = chosenColor;
    lastCode = code;
    reconnectTries = 0;
    try {
      window.localStorage.setItem('pp-name', name);
      window.localStorage.setItem('pp-code', code);
    } catch (e) {}
    openConnection(code, false);
  }
  function openConnection(code, isReconnect) {
    joinMsg(isReconnect ? 'Reconnecting…' : 'Connecting…');
    connectingReconnect = !!isReconnect;
    teardown(false);
    transport = '';
    startWebRTC(code, isReconnect);
  }
  function armStage(ms, fn) {
    clearTimeout(stageTimer);
    stageTimer = setTimeout(function () { stageTimer = null; fn(); }, ms);
  }
  var connectingReconnect = false;
  function failConnect(kind, code, detail) {
    clearTimeout(stageTimer);
    if (connectingReconnect && reconnectTries < 6) { scheduleReconnect(); return; }
    if (kind === 'notfound') {
      fail('Room "' + code + '" was not found. Check the code on the TV — the TV must be on the Ping Pong screen.');
    } else if (kind === 'lib') {
      fail('The controller library could not load, so phone play is unavailable. You can still play on the TV screen.');
    } else if (kind === 'problem') {
      fail('Connection problem (' + (detail || 'unknown') + '). Phone play needs internet — check Wi-Fi or mobile data, then try again.');
    } else {
      fail('Could not reach the room in time. Phone play needs an internet connection (the phone and TV meet through a cloud link). Check your connection and the room code, then try again.');
    }
    teardown(true);
  }
  function wireConn(c, code, isReconnect) {
    conn = c;
    c.on('open', function () {
      clearTimeout(stageTimer);
      transport = c.transport || (linkStage === 'relay' ? 'relay' : 'webrtc');
      c.send({ t: 'join', name: myName, color: myColor, token: token, mode: controlMode, gender: chosenGender });
    });
    c.on('data', onHostData);
    c.on('close', function () { onConnLost(); });
    c.on('error', function (err) {
      if (joined) return;
      if (err && err.type === 'peer-unavailable') {
        if (linkStage === 'relay') failConnect('notfound', code);
        else startRelay(code, isReconnect);
      }
      /* anything else surfaces via the stage timeout / close */
    });
  }
  function startWebRTC(code, isReconnect) {
    linkStage = 'rtc';
    if (typeof window.Peer === 'undefined') { startRelay(code, isReconnect); return; }
    var myPeer;
    try {
      myPeer = new window.Peer(undefined, S.brokerOptions());
    } catch (e) {
      startRelay(code, isReconnect);
      return;
    }
    peer = myPeer;
    var wait = isReconnect ? Math.min(3500, S.paramInt('rtcWait', 6000)) : S.paramInt('rtcWait', 6000);
    armStage(wait, function () { startRelay(code, isReconnect); });
    myPeer.on('open', function () {
      if (peer !== myPeer) return;
      var c = myPeer.connect(S.peerIdFor(code), { reliable: true });
      wireConn(c, code, isReconnect);
    });
    myPeer.on('error', function (err) {
      if (peer !== myPeer || joined) return;
      /* the direct cloud cannot see / reach this room — the relay
         gets its chance (it has its own presence check) */
      startRelay(code, isReconnect);
    });
  }
  function startRelay(code, isReconnect) {
    if (linkStage === 'relay' && relayPeerObj) return;
    linkStage = 'relay';
    clearTimeout(stageTimer);
    try { if (conn) conn.close(); } catch (e) {}
    try { if (peer) peer.destroy(); } catch (e) {}
    conn = null; peer = null;
    if (!S.relayEnabled()) {
      /* relay deliberately disabled (test config): the direct
         path was the only route, and it did not complete */
      failConnect('timeout', code);
      return;
    }
    if (typeof window.RelayPeer === 'undefined') {
      failConnect('lib', code);
      return;
    }
    var rp;
    try {
      rp = new window.RelayPeer(undefined, { roomCode: code });
    } catch (e) {
      failConnect('problem', code, 'relay-start');
      return;
    }
    relayPeerObj = rp;
    armStage(S.paramInt('relayWait', 15000), function () { failConnect('timeout', code); });
    rp.on('open', function () {
      if (relayPeerObj !== rp) return;
      var c = rp.connect(S.peerIdFor(code));
      wireConn(c, code, isReconnect);
    });
    rp.on('error', function (err) {
      if (relayPeerObj !== rp || joined) return;
      var type = err && err.type ? err.type : '';
      if (type === 'peer-unavailable') failConnect('notfound', code);
      else failConnect('problem', code, type || 'relay');
    });
  }
  function scheduleReconnect() {
    reconnectTries++;
    padStatus('Connection lost — reconnecting (try ' + reconnectTries + ' of 6)… your player is held for you.');
    $('phaseLine').textContent = '🔄 Reconnecting…';
    clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(function () {
      if (!joined && lastCode) openConnection(lastCode, true);
    }, 1200 * reconnectTries);
  }
  function onConnLost() {
    if (!joined) return;
    joined = false;
    conn = null;
    scheduleReconnect();
  }
  function teardown(full) {
    clearTimeout(connectDeadline);
    clearTimeout(stageTimer);
    if (full) clearTimeout(reconnectTimer);
    try { if (conn) conn.close(); } catch (e) {}
    try { if (peer) peer.destroy(); } catch (e) {}
    try { if (relayPeerObj) relayPeerObj.destroy(); } catch (e) {}
    conn = null; peer = null; relayPeerObj = null;
    linkStage = '';
    if (full) { player = -1; transport = ''; }
  }

  /* ---------------- host state -> screen ---------------- */
  function onHostData(data) {
    if (!data || typeof data !== 'object') return;
    if (data.t === 'welcome') {
      joined = true;
      reconnectTries = 0;
      clearTimeout(connectDeadline);
      clearTimeout(stageTimer);
      clearTimeout(reconnectTimer);
      player = (data.player != null ? data.player : data.side);
      if (data.transport) transport = data.transport;
      $('trackBat').style.background = myColor;
      show('padPanel');
      applyMode(controlMode, false);
      requestWake();
      startClockSync();
      padStatus('Connected — you are P' + (player + 1) +
        (transport === 'relay' ? ' · via relay link' : ' · via direct link') + '.');
    } else if (data.t === 'pong') {
      var t1 = Date.now();
      var pt0 = pingT0[data.id];
      if (pt0 != null && typeof data.th === 'number') {
        syncSamples.push(data.th - (pt0 + t1) / 2);
      }
    } else if (data.t === 'full') {
      joined = true;
      clearTimeout(connectDeadline);
      fail('That room already has two players. You can watch on the TV, or start a game on the TV screen.');
    } else if (data.t === 'state') {
      hostState = data;
      renderState(data);
    }
  }
  function renderState(d) {
    /* 1.3.3: a fresh serve is the re-centring moment — the phone
       is back at rest between points (see maybeAutoRecentre) */
    if (!d.paused && d.phase === 'serve' && lastPhase !== 'serve') maybeAutoRecentre();
    lastPhase = d.paused ? 'paused' : d.phase;
    if (typeof d.sound === 'boolean') {
      $('btnRemoteSound').textContent = d.sound ? '🔊 Sound: On' : '🔇 Sound: Off';
    }
    $('sbLeft').textContent = 'P1 ' + (d.names[0] || '—');
    $('sbRight').textContent = 'P2 ' + (d.names[1] || '—');
    $('sbScore').textContent = d.scores[0] + ' : ' + d.scores[1];
    if (player >= 0) {
      $('youLine').textContent = 'You are P' + (player + 1) + ' · ' + (d.names[player] || myName) +
        (d.yourEnd ? ' · ' + d.yourEnd + ' end' : '') + ' · games ' + d.games[0] + '—' + d.games[1];
      $('youLine').style.color = d.colors[player] || myColor;
    }
    var phase = d.paused ? 'paused' : d.phase;
    var txt = '';
    if (phase === 'paused') txt = '⏸ Paused on the TV';
    else if (phase === 'lobby') txt = 'In the lobby — the game starts from the TV';
    else if (phase === 'serve') txt = d.yourServe ? '🏓 YOUR SERVE — swing the phone, or tap SERVE' : (d.names[d.server] || 'The other player') + ' to serve';
    else if (phase === 'rally') txt = '🏓 Rally — get ready…';
    else if (phase === 'point') txt = 'Point!';
    else if (phase === 'over') txt = 'Game over — see the TV';
    $('phaseLine').textContent = txt;
    var serve = $('serveBtn');
    if (d.yourServe) serve.classList.remove('hidden'); else serve.classList.add('hidden');
    if (d.grade && d.grade.player === player) {
      var key = d.grade.grade + ':' + d.scores[0] + ':' + d.scores[1];
      if (key !== lastGradeKey) {
        lastGradeKey = key;
        var gl = $('gradeLine');
        gl.textContent = d.grade.grade + '!';
        gl.style.color = d.grade.grade === 'SMASH' ? '#e74c3c' : d.grade.grade === 'PERFECT' ? '#2ecc71' : d.grade.grade === 'GOOD' ? '#e0b93a' : '#e67e22';
        setTimeout(function () { if (gl.textContent === d.grade.grade + '!') gl.textContent = ''; }, 1600);
      }
    }
  }

  /* ------------- bat stream: ~30 Hz while changing -------------
     Send-on-change still applies (a still bat sends nothing), but
     the tick is 33 ms so a moving bat streams at ~30 Hz; the host
     interpolates/extrapolates between packets from the last two. */
  setInterval(function () {
    if (!joined || !conn || !conn.open || player < 0) return;
    var xCh = Math.abs(pos01 - lastSent) >= 0.0012 || lastSent < 0;
    var zCh = Math.abs(depth01 - lastSentZ) >= 0.01 || lastSentZ < 0;
    if (!xCh && !zCh) return;
    lastSent = pos01;
    lastSentZ = depth01;
    send({ t: 'pad', x: Math.round(pos01 * 1000) / 1000, z: Math.round(depth01 * 1000) / 1000 });
  }, 33);
  function setPos(v) {
    pos01 = S.clamp(v, 0, 1);
    $('trackBat').style.left = (pos01 * 100) + '%';
  }
  function setDepth(v) {
    depth01 = S.clamp(v, 0, 1);
    $('trackBat').style.top = (74 - depth01 * 48) + '%';
  }
  /* SMASH: in touch mode arm the host-side smash (connect while a
     ball sits high); in swing mode fire a full-power swing, which
     the host grades as a smash on a high ball. */
  function sendSmash() {
    if (controlMode === 'swing') { doSwing(1); return; }
    if (send({ t: 'smash' })) padStatus('💥 SMASH armed — meet a high ball!');
  }

  /* ---------------- touch drag (2-axis track, 1.3.2) ----------------
     The track is a 2-axis pad: sideways moves the bat across the
     table; vertical moves its DEPTH — drag up to step in over the
     table toward the net, down to retreat. A quick up-flick arms
     the smash. */
  var track = $('track');
  function trackMove(clientX, clientY) {
    var r = track.getBoundingClientRect();
    setPos((clientX - r.left) / r.width);
    if (clientY !== null && clientY !== undefined) setDepth(1 - (clientY - r.top) / r.height);
  }
  var trackTouch = { y: 0, t: 0 };
  track.addEventListener('touchstart', function (e) {
    e.preventDefault();
    trackTouch = { y: e.touches[0].clientY, t: performance.now() };
    trackMove(e.touches[0].clientX, e.touches[0].clientY);
  }, { passive: false });
  track.addEventListener('touchmove', function (e) {
    e.preventDefault();
    var nowT = performance.now();
    var vy = (trackTouch.y - e.touches[0].clientY) / Math.max(1, nowT - trackTouch.t);
    if (vy > 1.3) sendSmash();                 // quick up-flick = smash
    trackTouch = { y: e.touches[0].clientY, t: nowT };
    trackMove(e.touches[0].clientX, e.touches[0].clientY);
  }, { passive: false });
  track.addEventListener('mousedown', function (e) { trackMove(e.clientX, e.clientY); });
  track.addEventListener('mousemove', function (e) { if (e.buttons) trackMove(e.clientX, e.clientY); });

  /* ---------------- swing mode ----------------
     Tilt path: raw gamma → exponential low-pass (α 0.35) → minus
     the deliberately captured centre → ±1.5° dead-zone → ±24°
     span. Hand tremor is smoothed instead of amplified, and the
     centre is an average over ~0.5 s after the player's tap —
     never a silent first sample. */
  /* Serve re-centre (1.3.3): the deliberate capture ARMS the
     swing and sets the first centre, but it used to be the ONLY
     capture — a match is dozens of hard swings, the grip drifts,
     and the frozen centre went quietly wrong (the reported "TV
     calibration not accurate": bat resting off-centre, one edge
     needing over-tilt). At every serve the phone is back at rest,
     so the centre refreshes from the SMOOTHED tilt averaged over
     ~0.45 s — but only when the phone stayed near-still (range
     <= 10°); a phone being waved around keeps the old centre.
     The bat keeps tracking with the old centre during the window. */
  function maybeAutoRecentre() {
    if (controlMode !== 'swing' || !calibrated || !sensorsLive) return;
    if (calCapture || autoCapture || tiltSmooth === null) return;
    autoCapture = { sum: 0, n: 0, sumB: 0, nB: 0, min: Infinity, max: -Infinity,
                    until: performance.now() + 450 };
    setTimeout(finishAutoCapture, 520);
  }
  function finishAutoCapture() {
    if (!autoCapture) return;
    var cap = autoCapture;
    autoCapture = null;
    if (cap.n < 3 || (cap.max - cap.min) > 10) return;   // phone was moving — old centre stands
    var g = cap.sum / cap.n;
    var changed = gammaCenter === null || Math.abs(g - gammaCenter) >= 0.5;
    gammaCenter = g;
    if (cap.nB > 0) betaCenter = cap.sumB / cap.nB;
    recentres++;
    if (changed) {
      $('calReadout').textContent = 'Centre refreshed at ' + Math.round(g) +
        '° for this serve — your rest pose is the new centre. Tilt to move.';
    }
  }
  function finishCalCapture() {
    if (!calCapture) return;
    var cap = calCapture;
    calCapture = null;
    if (cap.n > 0) {
      gammaCenter = cap.sum / cap.n;
      if (cap.nB > 0) betaCenter = cap.sumB / cap.nB;
      calibrated = true;
      $('calReadout').textContent = 'Centre set at ' + Math.round(gammaCenter) +
        '° (averaged over ' + cap.n + ' readings). Tilt to move; your swing is armed.';
      padStatus('Centre set — swing armed. Tilt to move your bat.');
    } else {
      $('calReadout').textContent = 'No tilt readings arrived — hold the phone upright, move it slightly, then tap again.';
    }
  }
  function onOrient(e) {
    if (e.gamma === null || e.gamma === undefined) return;
    sensorSeenAt = performance.now();
    sensorsLive = true;
    lastGamma = e.gamma;
    if (tiltSmooth === null) tiltSmooth = e.gamma;
    else tiltSmooth += (e.gamma - tiltSmooth) * 0.35;
    var hasBeta = typeof e.beta === 'number';
    if (hasBeta) {
      if (betaSmooth === null) betaSmooth = e.beta;
      else betaSmooth += (e.beta - betaSmooth) * 0.3;
    }
    if (autoCapture) {
      autoCapture.sum += tiltSmooth;
      autoCapture.n++;
      if (tiltSmooth < autoCapture.min) autoCapture.min = tiltSmooth;
      if (tiltSmooth > autoCapture.max) autoCapture.max = tiltSmooth;
      if (betaSmooth !== null) { autoCapture.sumB += betaSmooth; autoCapture.nB++; }
      if (performance.now() >= autoCapture.until) finishAutoCapture();
    }
    if (calCapture) {
      /* samples before startAt are the tap transient — the finger
         jolt and the hand still settling never enter the centre */
      if (performance.now() >= calCapture.startAt) {
        calCapture.sum += e.gamma;
        calCapture.n++;
        if (hasBeta) { calCapture.sumB += e.beta; calCapture.nB++; }
      }
      if (performance.now() >= calCapture.until) finishCalCapture();
      return;
    }
    if (controlMode !== 'swing') return;
    if (gammaCenter === null) {
      $('calReadout').textContent = 'Hold the phone upright and tap "Centre" — your swing arms once the centre is set.';
      return;
    }
    var d = tiltSmooth - gammaCenter;
    if (Math.abs(d) < 1.5) d = 0;
    setPos(0.5 + d / 48);
    /* depth (1.3.2): lean the phone FORWARD from the upright centre
       (beta falls) to step in over the table; lean back to retreat */
    if (betaCenter !== null && betaSmooth !== null) {
      var bd = betaCenter - betaSmooth;
      if (Math.abs(bd) < 3) bd = 0;
      setDepth(S.clamp(bd / 30, 0, 1));
    }
    $('calReadout').textContent = 'Tilt ' + Math.round(d) + '° · bat ' +
      (pos01 < 0.4 ? 'left' : pos01 > 0.6 ? 'right' : 'centre') +
      (lastPower > 0 ? ' · last swing power ' + Math.round(lastPower * 100) + '%' : '');
  }
  function onMotion(e) {
    var a = e.accelerationIncludingGravity;
    if (!a || a.x === null) return;
    sensorSeenAt = performance.now();
    sensorsLive = true;
    if (controlMode !== 'swing') return;
    var r = Math.sqrt(a.x * a.x + a.y * a.y + a.z * a.z);
    if (r > motionPeak) motionPeak = r;
    var now = performance.now();
    var threshold = S.SWING_THRESHOLD / sens;
    if (motionPeak >= threshold && now - lastSwingAt > S.SWING_REFRACTORY_MS) {
      var power = S.clamp((motionPeak - 9.8) / 26, 0.15, 1);
      motionPeak = 0;
      doSwing(power, true);
    }
    if (motionPeak > 0 && now - lastSwingAt > 700) motionPeak = Math.max(0, motionPeak - 3);
  }
  function doSwing(power, viaSensor) {
    /* physical swings stay disarmed until the player deliberately
       sets the upright centre (manual/test taps are deliberate by
       definition and always send) */
    if (viaSensor && controlMode === 'swing' && !calibrated) {
      lastSwingAt = performance.now();
      padStatus('Swing not armed yet — hold the phone upright and tap "Centre" first.');
      return;
    }
    lastSwingAt = performance.now();
    lastPower = power;
    if (navigator.vibrate) { try { navigator.vibrate(25); } catch (e) {} }
    /* stamped at DETECTION in host time (measured offset applied):
       the host grades this moment, not the message's arrival */
    var tsHost = Date.now() + (clockOffset || 0);
    send({ t: 'swing', power: Math.round(power * 100) / 100, ts: tsHost });
    $('calReadout').textContent = 'Swing sent — power ' + Math.round(power * 100) + '%. Watch the TV for your grade.';
  }
  function applyMode(m, notify) {
    controlMode = m;
    $('btnModeSwing').classList.toggle('btn-gold', m === 'swing');
    $('btnModeSwing').classList.toggle('btn-outline', m !== 'swing');
    $('btnModeTouch').classList.toggle('btn-gold', m === 'touch');
    $('btnModeTouch').classList.toggle('btn-outline', m !== 'touch');
    $('swingPanel').classList.toggle('hidden', m !== 'swing');
    $('trackHint').textContent = m === 'swing'
      ? 'Touch fallback: drag here any time — up = step in over the table.'
      : 'Drag: sideways moves the bat · UP steps in over the table · flick up = SMASH.';
    if (notify !== false) send({ t: 'ctrl', mode: m });
  }
  function enableSwing() {
    /* iOS: motion permission must be asked from a user tap, for both
       event families; then attach and wait for the sensors to answer. */
    sensorsLive = false;
    sensorSeenAt = 0;
    var attach = function () {
      window.addEventListener('deviceorientation', onOrient);
      window.addEventListener('devicemotion', onMotion);
      gammaCenter = null;
      calibrated = false;
      calCapture = null;
      autoCapture = null;
      tiltSmooth = null;
      betaCenter = null;
      betaSmooth = null;
      applyMode('swing', true);
      padStatus('Swing mode: checking your motion sensors…');
      setTimeout(function () {
        if (controlMode === 'swing' && !sensorsLive) {
          applyMode('touch', true);
          padStatus('No motion sensor answered — Touch Mode instead (drag works). Tilt can be retried from SWING MODE.');
        } else if (controlMode === 'swing' && !calibrated) {
          padStatus('Swing mode on — hold the phone upright and tap "Centre" to arm your swing.');
        }
      }, 1500);
    };
    var askMotion = function () {
      if (typeof window.DeviceMotionEvent !== 'undefined' &&
          typeof window.DeviceMotionEvent.requestPermission === 'function') {
        window.DeviceMotionEvent.requestPermission().then(function (res) {
          if (res === 'granted') askOrient();
          else padStatus('Motion permission was not granted — Touch Mode (drag) still works.');
        }).catch(function () {
          padStatus('Motion is unavailable on this phone — Touch Mode (drag) still works.');
        });
      } else {
        askOrient();
      }
    };
    var askOrient = function () {
      if (typeof window.DeviceOrientationEvent !== 'undefined' &&
          typeof window.DeviceOrientationEvent.requestPermission === 'function') {
        window.DeviceOrientationEvent.requestPermission().then(function (res) {
          if (res === 'granted') attach();
          else padStatus('Tilt permission was not granted — Touch Mode (drag) still works.');
        }).catch(function () { attach(); });
      } else {
        attach();
      }
    };
    if (!('DeviceMotionEvent' in window) && !('DeviceOrientationEvent' in window)) {
      padStatus('This phone exposes no motion sensors — Touch Mode (drag) it is.');
      return;
    }
    askMotion();
  }
  $('btnModeSwing').addEventListener('click', enableSwing);
  $('btnModeTouch').addEventListener('click', function () { applyMode('touch', true); padStatus('Touch Mode: drag on the track — sideways + up/down for depth; the TV bats for you at contact.'); });
  $('btnSwingNow').addEventListener('click', function () { doSwing(0.7); });
  $('sensRange').addEventListener('input', function () {
    sens = parseFloat($('sensRange').value) || 1;
    $('sensVal').textContent = sens.toFixed(1) + '×';
  });
  $('btnCalibrate').addEventListener('click', function () {
    if (lastGamma === null) {
      $('calReadout').textContent = 'No tilt reading yet — hold the phone upright and move it slightly, then tap again.';
      return;
    }
    /* deliberate capture: average the tilt over ~0.5 s while the
       player holds the phone still and upright; the first 120 ms
       after the tap are discarded (tap transient, 1.3.3) */
    calCapture = { sum: 0, n: 0, sumB: 0, nB: 0,
                   startAt: performance.now() + 120, until: performance.now() + 620 };
    $('calReadout').textContent = 'Hold the phone upright and still — capturing your centre…';
    setTimeout(finishCalCapture, 720);
  });
  /* ---------------- TV remote (1.3.3) ----------------
     The phone doubles as the TV remote: one command per tap over
     the same link as the bat stream; the host runs the SAME
     action its own Enter / Esc / on-screen buttons run, and the
     TV shows the result (its sound button flips, and the new
     sound state rides the broadcast back to this phone). */
  function sendRemote(cmd) {
    if (send({ t: 'remote', cmd: cmd })) {
      if (cmd === 'start') padStatus('▶ Start sent — watch the TV.');
      else if (cmd === 'next') padStatus('⏭ Next Game sent — watch the TV.');
      else if (cmd === 'restart') padStatus('↻ Restart sent — the match starts over on the TV.');
      else if (cmd === 'end') padStatus('⏹ End sent — the TV returns to the lobby.');
      else if (cmd === 'sound') padStatus('🔊 Sound toggle sent — the TV sound button shows the new state.');
    } else {
      padStatus('Not connected — the remote rides the game link; join the room first.');
    }
  }
  $('btnRemoteStart').addEventListener('click', function () { sendRemote('start'); });
  $('btnRemoteNext').addEventListener('click', function () { sendRemote('next'); });
  $('btnRemoteRestart').addEventListener('click', function () { sendRemote('restart'); });
  $('btnRemoteEnd').addEventListener('click', function () { sendRemote('end'); });
  $('btnRemoteSound').addEventListener('click', function () { sendRemote('sound'); });
  $('serveBtn').addEventListener('click', function () { send({ t: 'serve' }); });
  $('btnSmash').addEventListener('click', function () { sendSmash(); });
  $('btnJoin').addEventListener('click', join);
  $('btnRetry').addEventListener('click', function () { teardown(true); show('joinPanel'); });
  $('btnLeave').addEventListener('click', function () {
    teardown(true);
    joined = false;
    show('joinPanel');
    joinMsg('');
  });
  $('codeInput').addEventListener('keydown', function (e) { if (e.key === 'Enter') join(); });

  function requestWake() {
    try {
      if (navigator.wakeLock && navigator.wakeLock.request) {
        navigator.wakeLock.request('screen').catch(function () {});
      }
    } catch (e) {}
  }

  /* debug / test hooks (used by the check scripts) */
  window.PPC = {
    version: '1.3.3',
    getState: function () {
      return { joined: joined, player: player, side: player, pos01: pos01, depth01: depth01,
               targetY: pos01, mode: controlMode, sens: sens,
               sensorsLive: sensorsLive, lastPower: lastPower,
               reconnectTries: reconnectTries,
               transport: transport, gender: chosenGender,
               clockOffset: clockOffset, calibrated: calibrated,
               gammaCenter: gammaCenter, betaCenter: betaCenter, recentres: recentres,
               tiltSmooth: tiltSmooth,
               panel: !$('padPanel').classList.contains('hidden') ? 'pad'
                    : !$('joinPanel').classList.contains('hidden') ? 'join' : 'err',
               phaseLine: $('phaseLine').textContent,
               youLine: $('youLine').textContent,
               statusLine: $('padStatus').textContent,
               serveVisible: !$('serveBtn').classList.contains('hidden') };
    },
    join: join,
    setPos: function (v) { setPos(v); },
    setDepth: function (v) { setDepth(v); },
    smash: function () { sendSmash(); },
    setTarget: function (v) { setPos(v); },
    setMode: function (m) { applyMode(m === 'swing' ? 'swing' : 'touch', false); },
    swing: function (power) { doSwing(power == null ? 0.7 : power, false); },
    remote: function (cmd) { sendRemote(cmd); },
    debugDrop: function () { onConnLost(); },
    peerId: function () { return peer ? peer.id : null; },
    injectData: function (msg) { onHostData(msg); },
    debugOrient: function (g) { onOrient({ gamma: g }); },
    debugCalibrate: function () {
      if (lastGamma !== null) { gammaCenter = tiltSmooth !== null ? tiltSmooth : lastGamma; calibrated = true; }
      betaCenter = betaSmooth;
    },
    debugSetClockOffset: function (ms) { clockOffset = ms; }
  };
  if (typeof window.__ppBootDone === 'function') window.__ppBootDone();
})();
