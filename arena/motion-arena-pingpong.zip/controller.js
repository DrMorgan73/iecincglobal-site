/* Motion Arena — Ping Pong: phone controller (broadcast build 1.3.0).
   Joins the TV host by room code (PeerJS cloud). Two control modes:
   SWING MODE — tilt (deviceorientation gamma) moves the bat, a
   physical swing (devicemotion resultant-acceleration peak, DESIGN.md
   threshold ~22 m/s² at 1.0×, 300 ms refractory) strikes the ball and
   is graded by the host; TOUCH MODE — horizontal drag moves the bat,
   the host auto-contacts (always available, and the automatic
   fallback when no motion sensor answers within 1.5 s). Streams bat
   position at 15 Hz; swing/serve travel as immediate events.
   Reconnect reclaims the same player slot by token (the host holds
   it ~60 s) — no reload, no side steal. */
(function () {
  'use strict';
  var S = window.PPShared;
  var $ = function (id) { return document.getElementById(id); };

  var chosenColor = S.COLORS[0].hex;
  var token = '';
  try { token = window.localStorage.getItem('pp-token') || ''; } catch (e) {}
  if (!token) {
    token = 'tok-' + Math.random().toString(36).slice(2, 10);
    try { window.localStorage.setItem('pp-token', token); } catch (e) {}
  }
  try {
    var savedName = window.localStorage.getItem('pp-name');
    if (savedName) $('nameInput').value = savedName;
    var savedColor = window.localStorage.getItem('pp-color');
    if (savedColor) chosenColor = savedColor;
    var savedCode = window.localStorage.getItem('pp-code');
    if (savedCode) $('codeInput').value = savedCode;
  } catch (e) {}

  /* colour swatches */
  var sw = $('swatches');
  S.COLORS.forEach(function (c) {
    var b = document.createElement('button');
    b.className = 'swatch' + (c.hex === chosenColor ? ' sel' : '');
    b.style.background = c.hex;
    b.title = c.name;
    b.setAttribute('aria-label', c.name);
    b.addEventListener('click', function () {
      chosenColor = c.hex;
      try { window.localStorage.setItem('pp-color', c.hex); } catch (e) {}
      var all = sw.querySelectorAll('.swatch');
      for (var i = 0; i < all.length; i++) all[i].classList.remove('sel');
      b.classList.add('sel');
    });
    sw.appendChild(b);
  });

  var peer = null, conn = null, joined = false;
  var player = -1;                       // 0 or 1 (identity, follows ends switches)
  var myName = 'Player', myColor = chosenColor;
  var controlMode = 'touch';             // 'touch' | 'swing'
  var pos01 = 0.5, lastSent = -1;
  var sens = 1.0;
  var gammaCenter = null, lastGamma = null, sensorSeenAt = 0, sensorsLive = false;
  var motionPeak = 0, lastSwingAt = 0, lastPower = 0;
  var lastCode = '', lastGradeKey = '';
  var connectDeadline = null, reconnectTimer = null, reconnectTries = 0;
  var hostState = null;

  function show(id) {
    ['joinPanel', 'padPanel', 'errPanel'].forEach(function (p) {
      $(p).classList.toggle('hidden', p !== id);
    });
  }
  function fail(msg) {
    clearTimeout(connectDeadline);
    $('errMsg').textContent = msg;
    show('errPanel');
  }
  function joinMsg(txt, isErr) {
    var m = $('joinMsg');
    m.textContent = txt;
    m.className = 'msg' + (isErr ? ' err' : '');
  }
  function padStatus(txt) { $('padStatus').textContent = txt; }
  function send(msg) {
    if (conn && conn.open) { try { conn.send(msg); return true; } catch (e) {} }
    return false;
  }

  /* ---------------- connection ---------------- */
  function join() {
    var code = $('codeInput').value.trim().toUpperCase();
    if (code.length !== 4) { joinMsg('Enter the 4-letter room code from the TV.', true); return; }
    var name = $('nameInput').value.trim() || 'Player';
    myName = name;
    myColor = chosenColor;
    lastCode = code;
    reconnectTries = 0;
    try {
      window.localStorage.setItem('pp-name', name);
      window.localStorage.setItem('pp-code', code);
    } catch (e) {}
    openConnection(code, false);
  }
  function openConnection(code, isReconnect) {
    joinMsg(isReconnect ? 'Reconnecting…' : 'Connecting…');
    if (typeof window.Peer === 'undefined') {
      fail('The controller library could not load, so phone play is unavailable. You can still play on the TV screen.');
      return;
    }
    teardown(false);
    var myPeer;
    try {
      myPeer = new window.Peer(undefined, S.brokerOptions());
    } catch (e) {
      fail('Could not start the connection. Phone play needs internet — check Wi-Fi or mobile data, then try again.');
      return;
    }
    peer = myPeer;
    clearTimeout(connectDeadline);
    connectDeadline = setTimeout(function () {
      if (!joined) {
        if (isReconnect && reconnectTries < 6) { scheduleReconnect(); return; }
        fail('Could not reach the room in time. Phone play needs an internet connection (the phone and TV meet through the PeerJS cloud). Check your connection and the room code, then try again.');
        teardown(true);
      }
    }, 12000);
    myPeer.on('open', function () {
      var c = myPeer.connect(S.peerIdFor(code), { reliable: true });
      conn = c;
      c.on('open', function () {
        c.send({ t: 'join', name: myName, color: myColor, token: token, mode: controlMode });
      });
      c.on('data', onHostData);
      c.on('close', function () { onConnLost(); });
      c.on('error', function () { /* surfaced via timeout / close */ });
    });
    myPeer.on('error', function (err) {
      var type = err && err.type ? err.type : '';
      if (joined) return;
      if (isReconnect && reconnectTries < 6) { scheduleReconnect(); return; }
      if (type === 'peer-unavailable') {
        fail('Room "' + code + '" was not found. Check the code on the TV — the TV must be on the Ping Pong screen.');
      } else {
        fail('Connection problem (' + (type || 'unknown') + '). Phone play needs internet — check Wi-Fi or mobile data, then try again.');
      }
      teardown(true);
    });
  }
  function scheduleReconnect() {
    reconnectTries++;
    padStatus('Connection lost — reconnecting (try ' + reconnectTries + ' of 6)… your player is held for you.');
    $('phaseLine').textContent = '🔄 Reconnecting…';
    clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(function () {
      if (!joined && lastCode) openConnection(lastCode, true);
    }, 1200 * reconnectTries);
  }
  function onConnLost() {
    if (!joined) return;
    joined = false;
    conn = null;
    scheduleReconnect();
  }
  function teardown(full) {
    clearTimeout(connectDeadline);
    if (full) clearTimeout(reconnectTimer);
    try { if (conn) conn.close(); } catch (e) {}
    try { if (peer) peer.destroy(); } catch (e) {}
    conn = null; peer = null;
    if (full) { player = -1; }
  }

  /* ---------------- host state -> screen ---------------- */
  function onHostData(data) {
    if (!data || typeof data !== 'object') return;
    if (data.t === 'welcome') {
      joined = true;
      reconnectTries = 0;
      clearTimeout(connectDeadline);
      clearTimeout(reconnectTimer);
      player = (data.player != null ? data.player : data.side);
      $('trackBat').style.background = myColor;
      show('padPanel');
      applyMode(controlMode, false);
      requestWake();
      padStatus('Connected — you are P' + (player + 1) + '.');
    } else if (data.t === 'full') {
      joined = true;
      clearTimeout(connectDeadline);
      fail('That room already has two players. You can watch on the TV, or start a game on the TV screen.');
    } else if (data.t === 'state') {
      hostState = data;
      renderState(data);
    }
  }
  function renderState(d) {
    $('sbLeft').textContent = 'P1 ' + (d.names[0] || '—');
    $('sbRight').textContent = 'P2 ' + (d.names[1] || '—');
    $('sbScore').textContent = d.scores[0] + ' : ' + d.scores[1];
    if (player >= 0) {
      $('youLine').textContent = 'You are P' + (player + 1) + ' · ' + (d.names[player] || myName) +
        (d.yourEnd ? ' · ' + d.yourEnd + ' end' : '') + ' · games ' + d.games[0] + '—' + d.games[1];
      $('youLine').style.color = d.colors[player] || myColor;
    }
    var phase = d.paused ? 'paused' : d.phase;
    var txt = '';
    if (phase === 'paused') txt = '⏸ Paused on the TV';
    else if (phase === 'lobby') txt = 'In the lobby — the game starts from the TV';
    else if (phase === 'serve') txt = d.yourServe ? '🏓 YOUR SERVE — swing the phone, or tap SERVE' : (d.names[d.server] || 'The other player') + ' to serve';
    else if (phase === 'rally') txt = '🏓 Rally — get ready…';
    else if (phase === 'point') txt = 'Point!';
    else if (phase === 'over') txt = 'Game over — see the TV';
    $('phaseLine').textContent = txt;
    var serve = $('serveBtn');
    if (d.yourServe) serve.classList.remove('hidden'); else serve.classList.add('hidden');
    if (d.grade && d.grade.player === player) {
      var key = d.grade.grade + ':' + d.scores[0] + ':' + d.scores[1];
      if (key !== lastGradeKey) {
        lastGradeKey = key;
        var gl = $('gradeLine');
        gl.textContent = d.grade.grade + '!';
        gl.style.color = d.grade.grade === 'PERFECT' ? '#2ecc71' : d.grade.grade === 'GOOD' ? '#e0b93a' : '#e67e22';
        setTimeout(function () { if (gl.textContent === d.grade.grade + '!') gl.textContent = ''; }, 1600);
      }
    }
  }

  /* ---------------- 15 Hz bat stream (DESIGN.md) ---------------- */
  setInterval(function () {
    if (!joined || !conn || !conn.open || player < 0) return;
    if (Math.abs(pos01 - lastSent) < 0.0015 && lastSent >= 0) return;
    lastSent = pos01;
    send({ t: 'pad', x: Math.round(pos01 * 1000) / 1000 });
  }, 66);
  function setPos(v) {
    pos01 = S.clamp(v, 0, 1);
    $('trackBat').style.left = (pos01 * 100) + '%';
  }

  /* ---------------- touch drag (horizontal track) ---------------- */
  var track = $('track');
  function trackMove(clientX) {
    var r = track.getBoundingClientRect();
    setPos((clientX - r.left) / r.width);
  }
  track.addEventListener('touchstart', function (e) { e.preventDefault(); trackMove(e.touches[0].clientX); }, { passive: false });
  track.addEventListener('touchmove', function (e) { e.preventDefault(); trackMove(e.touches[0].clientX); }, { passive: false });
  track.addEventListener('mousedown', function (e) { trackMove(e.clientX); });
  track.addEventListener('mousemove', function (e) { if (e.buttons) trackMove(e.clientX); });

  /* ---------------- swing mode ---------------- */
  function onOrient(e) {
    if (e.gamma === null || e.gamma === undefined) return;
    sensorSeenAt = performance.now();
    sensorsLive = true;
    lastGamma = e.gamma;
    if (controlMode !== 'swing') return;
    if (gammaCenter === null) gammaCenter = e.gamma;
    setPos(0.5 + (e.gamma - gammaCenter) / 38);
    $('calReadout').textContent = 'Tilt ' + Math.round(e.gamma - gammaCenter) + '° · bat ' +
      (pos01 < 0.4 ? 'left' : pos01 > 0.6 ? 'right' : 'centre') +
      (lastPower > 0 ? ' · last swing power ' + Math.round(lastPower * 100) + '%' : '');
  }
  function onMotion(e) {
    var a = e.accelerationIncludingGravity;
    if (!a || a.x === null) return;
    sensorSeenAt = performance.now();
    sensorsLive = true;
    if (controlMode !== 'swing') return;
    var r = Math.sqrt(a.x * a.x + a.y * a.y + a.z * a.z);
    if (r > motionPeak) motionPeak = r;
    var now = performance.now();
    var threshold = S.SWING_THRESHOLD / sens;
    if (motionPeak >= threshold && now - lastSwingAt > S.SWING_REFRACTORY_MS) {
      var power = S.clamp((motionPeak - 9.8) / 26, 0.15, 1);
      motionPeak = 0;
      doSwing(power);
    }
    if (motionPeak > 0 && now - lastSwingAt > 700) motionPeak = Math.max(0, motionPeak - 3);
  }
  function doSwing(power) {
    lastSwingAt = performance.now();
    lastPower = power;
    if (navigator.vibrate) { try { navigator.vibrate(25); } catch (e) {} }
    send({ t: 'swing', power: Math.round(power * 100) / 100 });
    $('calReadout').textContent = 'Swing sent — power ' + Math.round(power * 100) + '%. Watch the TV for your grade.';
  }
  function applyMode(m, notify) {
    controlMode = m;
    $('btnModeSwing').classList.toggle('btn-gold', m === 'swing');
    $('btnModeSwing').classList.toggle('btn-outline', m !== 'swing');
    $('btnModeTouch').classList.toggle('btn-gold', m === 'touch');
    $('btnModeTouch').classList.toggle('btn-outline', m !== 'touch');
    $('swingPanel').classList.toggle('hidden', m !== 'swing');
    $('trackHint').textContent = m === 'swing'
      ? 'Touch fallback: drag here any time — last input wins.'
      : 'Drag left / right to move your bat.';
    if (notify !== false) send({ t: 'ctrl', mode: m });
  }
  function enableSwing() {
    /* iOS: motion permission must be asked from a user tap, for both
       event families; then attach and wait for the sensors to answer. */
    sensorsLive = false;
    sensorSeenAt = 0;
    var attach = function () {
      window.addEventListener('deviceorientation', onOrient);
      window.addEventListener('devicemotion', onMotion);
      gammaCenter = null;
      applyMode('swing', true);
      padStatus('Swing mode: checking your motion sensors…');
      setTimeout(function () {
        if (controlMode === 'swing' && !sensorsLive) {
          applyMode('touch', true);
          padStatus('No motion sensor answered — Touch Mode instead (drag works). Tilt can be retried from SWING MODE.');
        }
      }, 1500);
    };
    var askMotion = function () {
      if (typeof window.DeviceMotionEvent !== 'undefined' &&
          typeof window.DeviceMotionEvent.requestPermission === 'function') {
        window.DeviceMotionEvent.requestPermission().then(function (res) {
          if (res === 'granted') askOrient();
          else padStatus('Motion permission was not granted — Touch Mode (drag) still works.');
        }).catch(function () {
          padStatus('Motion is unavailable on this phone — Touch Mode (drag) still works.');
        });
      } else {
        askOrient();
      }
    };
    var askOrient = function () {
      if (typeof window.DeviceOrientationEvent !== 'undefined' &&
          typeof window.DeviceOrientationEvent.requestPermission === 'function') {
        window.DeviceOrientationEvent.requestPermission().then(function (res) {
          if (res === 'granted') attach();
          else padStatus('Tilt permission was not granted — Touch Mode (drag) still works.');
        }).catch(function () { attach(); });
      } else {
        attach();
      }
    };
    if (!('DeviceMotionEvent' in window) && !('DeviceOrientationEvent' in window)) {
      padStatus('This phone exposes no motion sensors — Touch Mode (drag) it is.');
      return;
    }
    askMotion();
  }
  $('btnModeSwing').addEventListener('click', enableSwing);
  $('btnModeTouch').addEventListener('click', function () { applyMode('touch', true); padStatus('Touch Mode: drag on the track — the TV bats for you at contact.'); });
  $('btnSwingNow').addEventListener('click', function () { doSwing(0.7); });
  $('sensRange').addEventListener('input', function () {
    sens = parseFloat($('sensRange').value) || 1;
    $('sensVal').textContent = sens.toFixed(1) + '×';
  });
  $('btnCalibrate').addEventListener('click', function () {
    gammaCenter = lastGamma;
    $('calReadout').textContent = lastGamma === null
      ? 'No tilt reading yet — hold the phone upright and move it slightly, then tap again.'
      : 'Centre set at ' + Math.round(lastGamma) + '°. Tilt left/right from here; swing once to test.';
  });
  $('serveBtn').addEventListener('click', function () { send({ t: 'serve' }); });
  $('btnJoin').addEventListener('click', join);
  $('btnRetry').addEventListener('click', function () { teardown(true); show('joinPanel'); });
  $('btnLeave').addEventListener('click', function () {
    teardown(true);
    joined = false;
    show('joinPanel');
    joinMsg('');
  });
  $('codeInput').addEventListener('keydown', function (e) { if (e.key === 'Enter') join(); });

  function requestWake() {
    try {
      if (navigator.wakeLock && navigator.wakeLock.request) {
        navigator.wakeLock.request('screen').catch(function () {});
      }
    } catch (e) {}
  }

  /* debug / test hooks (used by the check scripts) */
  window.PPC = {
    version: '1.3.0',
    getState: function () {
      return { joined: joined, player: player, side: player, pos01: pos01,
               targetY: pos01, mode: controlMode, sens: sens,
               sensorsLive: sensorsLive, lastPower: lastPower,
               reconnectTries: reconnectTries,
               panel: !$('padPanel').classList.contains('hidden') ? 'pad'
                    : !$('joinPanel').classList.contains('hidden') ? 'join' : 'err',
               phaseLine: $('phaseLine').textContent,
               youLine: $('youLine').textContent,
               serveVisible: !$('serveBtn').classList.contains('hidden') };
    },
    join: join,
    setPos: function (v) { setPos(v); },
    setTarget: function (v) { setPos(v); },
    setMode: function (m) { applyMode(m === 'swing' ? 'swing' : 'touch', false); },
    swing: function (power) { doSwing(power == null ? 0.7 : power); },
    debugDrop: function () { onConnLost(); },
    peerId: function () { return peer ? peer.id : null; },
    injectData: function (msg) { onHostData(msg); }
  };
  if (typeof window.__ppBootDone === 'function') window.__ppBootDone();
})();
