/* Motion Arena — Ping Pong: shared constants + wire protocol.
   Used by host.js (TV) and controller.js (phone). Classic script, no
   modules, so the game also runs from file:// (USB stick, offline).

   Build relay-1.3.1: the game is BROADCAST table tennis —
   the TV camera sits behind the near end of a 3D table. World space:
     x  across the table   (-1 .. +1 is the table surface)
     z  along the table    (-1 = near end / side 0, +1 = far end / side 1)
     h  height above the table surface (the ball arcs under gravity)
   Side 0 plays the near end (bottom of the TV picture), side 1 the
   far end (the avatar the TV draws standing at the far end). */
(function (global) {
  'use strict';

  var PP = {};

  /* Canvas (internal resolution, per DESIGN.md). */
  PP.W = 1920;
  PP.H = 1080;

  /* Broadcast table-tennis world constants. */
  PP.TABLE = {
    halfW: 1.0,          // table half-width in world units (x)
    halfL: 1.0,          // table half-length (z): ends at z = -1 / +1
    netH: 0.17,          // net height above the surface
    planeZ: 1.07,        // hitting plane just behind each end line
    gravity: 3.4,        // world units / s^2 on the ball's arc
    rest: 0.82,          // bounce restitution off the table
    reach: 0.37,         // bat contact reach (world x units)
    batMin: -1.18,       // bat travel limits (slightly past the edges)
    batMax: 1.18,
    batSpeed: 2.7        // local bat speed, world units / s
  };

  /* Official table-tennis rules (ITTF shape): a game to 11, win by
     2; serves change every 2 points, every 1 at deuce (10-10); ends
     switch after each game and at 5 points in the deciding game;
     a match is best of 5 games (first to 3). */
  PP.WIN_SCORE = 11;
  PP.WIN_LEAD = 2;
  PP.MATCH_GAMES_TO_WIN = 3;
  PP.MATCH_MAX_GAMES = 5;

  /* Computer difficulty (broadcast buildout). pace = flight time of
     the Computer's returns (lower = faster ball), err = bat aim error
     when tracking the ball, aimErr = spread on its return targets. */
  PP.DIFFICULTY = {
    easy:   { label: 'Easy',   speed: 1.15, err: 0.30, pace: 1.04, aimErr: 0.30 },
    normal: { label: 'Normal', speed: 1.70, err: 0.17, pace: 0.88, aimErr: 0.18 },
    pro:    { label: 'Pro',    speed: 2.35, err: 0.08, pace: 0.72, aimErr: 0.09 }
  };
  PP.DIFFICULTY_ORDER = ['easy', 'normal', 'pro'];

  /* Swing grades (DESIGN.md Swing windows, ms vs ideal contact). */
  PP.GRADE_WINDOWS = { perfect: 90, good: 200, graze: 320 };
  /* Swing detection on the phone (DESIGN.md): resultant-acceleration
     peak at 1.0x sensitivity, 300 ms refractory. */
  PP.SWING_THRESHOLD = 22;
  PP.SWING_REFRACTORY_MS = 300;

  /* PeerJS: room peer id = prefix + 4-char code. Default broker is the
     PeerJS cloud (per DESIGN.md). A different broker can be selected with
     URL params (?broker=local or ?brokerHost=..&brokerPort=..&brokerPath=..),
     which the automated checks use with the repo's local PeerServer. */
  PP.PEER_PREFIX = 'ma-pp-';
  PP.CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

  PP.makeRoomCode = function () {
    var s = '';
    for (var i = 0; i < 4; i++) {
      s += PP.CODE_ALPHABET[Math.floor(Math.random() * PP.CODE_ALPHABET.length)];
    }
    return s;
  };

  PP.peerIdFor = function (code) {
    return PP.PEER_PREFIX + String(code).toUpperCase();
  };

  /* Query params, with an ES5 fallback: URLSearchParams needs Chrome 49+;
     older TV browsers fall back to a manual parse of location.search. */
  function queryParams() {
    if (typeof global.URLSearchParams === 'function') return new global.URLSearchParams(global.location.search);
    var map = {};
    var s = String(global.location.search || '').replace(/^\?/, '');
    var parts = s.split('&');
    for (var i = 0; i < parts.length; i++) {
      if (!parts[i]) continue;
      var kv = parts[i].split('=');
      try { map[decodeURIComponent(kv[0])] = kv.length > 1 ? decodeURIComponent(kv.slice(1).join('=')) : ''; } catch (e) {}
    }
    return { get: function (k) { return k in map ? map[k] : null; } };
  }

  PP.brokerOptions = function () {
    var q = queryParams();
    if (q.get('broker') === 'local') {
      return { host: global.location.hostname || 'localhost', port: 9000, path: '/', secure: false, debug: 0 };
    }
    if (q.get('brokerHost')) {
      return {
        host: q.get('brokerHost'),
        port: parseInt(q.get('brokerPort') || '443', 10),
        path: q.get('brokerPath') || '/',
        secure: q.get('brokerSecure') !== '0',
        key: q.get('brokerKey') || 'peerjs',
        debug: 0
      };
    }
    return { debug: 0 }; // PeerJS cloud defaults
  };

  /* Integer URL param with a default (test hooks use these to shorten
     the transport waits; production uses the defaults). */
  PP.paramInt = function (name, dflt) {
    var q = queryParams();
    var v = parseInt(q.get(name), 10);
    return isNaN(v) ? dflt : v;
  };

  /* Relay transport (relay.js): when a host browser can signal over
     WebRTC but never completes a data connection (the Samsung Tizen
     TV browser, proven 2026-11-14), the same wire protocol rides an
     MQTT-over-secure-WebSocket relay through a public broker instead.
     EMQX's public broker was chosen by a live two-client test from
     the build sandbox (pub/sub + retained both verified 2026-11-14);
     test.mosquitto.org was unreachable from there. Topics live under
     an app-specific prefix, one subtree per room code.
     Enable rules: ?relay=off disables; ?relay=on forces on; with the
     local test broker (?broker=local) the relay stays out unless
     ?relay=on asks for it, so the local suites see no outside calls. */
  PP.RELAY_URL = 'wss://broker.emqx.io:8084/mqtt';
  PP.RELAY_PREFIX = 'mapp/v1/';
  PP.relayEnabled = function () {
    var q = queryParams();
    if (q.get('relay') === 'off') return false;
    if (q.get('relay') === 'on') return true;
    if (q.get('broker') === 'local') return false;
    return true;
  };
  PP.relayUrl = function () {
    var q = queryParams();
    return q.get('relayUrl') || PP.RELAY_URL;
  };

  /* Player colours (preview palette from DESIGN.md + IEC gold). */
  PP.COLORS = [
    { id: 'gold',   hex: '#C9A227', name: 'Gold' },
    { id: 'red',    hex: '#e74c3c', name: 'Red' },
    { id: 'blue',   hex: '#3498db', name: 'Blue' },
    { id: 'green',  hex: '#2ecc71', name: 'Green' },
    { id: 'orange', hex: '#e67e22', name: 'Orange' }
  ];

  PP.clamp = function (v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); };
  PP.lerp = function (a, b, t) { return a + (b - a) * t; };

  global.PPShared = PP;
})(window);
