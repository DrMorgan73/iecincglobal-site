/* Motion Arena — Ping Pong: TV host. RELAY build (1.3.1).
   (Broadcast view + official rules as 1.3.0; 1.3.1 adds the relay
   transport fallback for phone controllers, male/female avatar
   variants on a keyframed animation rig, an animated crowd with
   synthesized cheers, and the control-tuning pass: timestamped
   swings with join-time clock sync, phone-side tilt filtering,
   host-side bat prediction.)
   The TV camera sits behind the near end of a 3D table (Canvas 2D
   perspective projection — no WebGL, so old TV browsers keep up).
   World space: x across (-1..1 = table), z along (-1 near / +1 far),
   h = height above the surface. Official table-tennis rules (ITTF
   shape): serve bounces on the server's half first, then the
   receiver's; a corded serve that lands in is a LET; volleying is a
   fault; rally net-cords that land in play on; edge balls are in;
   game to 11 win by 2; serves change every 2 (every 1 at deuce);
   ends switch after each game and at 5 in the deciding game;
   match = best of 5. Owns all state and scoring (per DESIGN.md).
   Modes: 'ai' (1P vs Computer), 'local' (2P same screen), 'phone'
   (PeerJS controllers, swing or drag). Runs from https, localhost,
   or file:// (USB). */
(function () {
  'use strict';
  var S = window.PPShared;
  var W = S.W, H = S.H, T = S.TABLE;
  var canvas = document.getElementById('game');
  var ctx = canvas.getContext('2d');

  /* ---------------- players & ends ----------------
     players[] are IDENTITIES (0 and 1). Physical sides: 0 = NEAR
     (bottom of the picture), 1 = FAR (the avatar's end). Ends switch
     per the rules; controllers follow their player. */
  var players = [
    { name: 'You',      color: S.COLORS[0].hex, kind: 'human', gender: 'male' },
    { name: 'Computer', color: S.COLORS[1].hex, kind: 'ai',    gender: 'female' }
  ];
  /* Lobby avatar-variant picks for the two local seats (a phone's
     own join choice overrides its seat's pick while it holds it). */
  var lobbyGender = ['male', 'female'];
  var endsSwapped = false;
  function sideOfPlayer(p) { return endsSwapped ? (p === 0 ? 1 : 0) : p; }
  function playerAtSide(side) { return endsSwapped ? (side === 0 ? 1 : 0) : side; }

  /* ---------------- state ---------------- */
  var phase = 'lobby';           // lobby | serve | rally | point | over
  var mode = 'ai';               // ai | local | phone
  var paused = false;
  var scores = [0, 0];           // by player
  var games = [0, 0];            // by player (the match score)
  var gameNumber = 1;
  var firstServer = 0;           // player serving first this game
  var server = 0;                // current server (player)
  var switchedThisGame = false;
  var gameWinner = -1, matchWinner = -1;
  var settings = { difficulty: 'normal', sound: false };
  var rallyBot = false;          // test hook: both bats auto (soak tests)
  var pointTimer = 0, serveTimer = 0;
  var lastScorer = -1, pointFlash = 0, pointReason = '';
  var rallyHits = 0, bestRally = 0, matchBestRally = 0;
  var letReplay = false;

  var ball = { x: 0, z: -0.5, h: 0.16, vx: 0, vz: 0, vh: 0, live: false };
  var flight = null;   // {fromSide,toSide,serve,bounces,crossed,cord,tPlane}
  var bats = [ { x: 0, target: 0, padVel: 0, padAt: 0 }, { x: 0, target: 0, padVel: 0, padAt: 0 } ];   // by physical side
  var lastSwingTiming = { deltaMs: null, compensated: false };  // grading audit trail
  var pendingSwing = [null, null];   // by player: {at, power}
  var lastGrade = { player: -1, grade: '', at: 0 };
  var flash = { text: '', sub: '', color: '#ffffff', t: 0, dur: 0 };
  var avatar = { x: 0, vx: 0, swingT: 0, react: '', reactT: 0, reactBig: false,
                 crouch: 0, stepPhase: 0, headT: 0 };    // far-end player figure
  var nearAnim = { swingT: 0, reactT: 0 };
  /* The swing cycle (relay-1.3.1 "real animation"): 0.62 s through
     keyframed poses — WIND-UP (arm loads back, elbow cocked, slight
     crouch), CONTACT (fast sweep through the ball, weight leans in),
     FOLLOW-THROUGH (arm crosses high, body recovers to ready).
     Contact sits at k=0.45; cycles are triggered ~that long before
     the ball reaches the plane when the host can anticipate (AI /
     local bats), or at the contact instant for phone swings and
     serves (then the visible contact + follow-through still read). */
  var SWING_DUR = 0.62, SWING_CONTACT_K = 0.45;
  var SWING_KEYS = [ // [k, shoulderAng, elbowBend, weightLean, crouchAdd]
    [0.00, -0.50, 0.50,  0.00, 0.00],
    [0.30, -2.25, 1.20, -0.22, 0.35],
    [0.45,  0.30, 0.22,  0.34, 0.10],
    [0.64,  1.05, 0.60,  0.18, 0.00],
    [1.00, -0.50, 0.50,  0.00, 0.00]
  ];
  function swingPose(k) {
    if (k <= 0) k = 0.0001;
    if (k >= 1) k = 0.9999;
    for (var i = 1; i < SWING_KEYS.length; i++) {
      if (k <= SWING_KEYS[i][0]) {
        var a = SWING_KEYS[i - 1], b = SWING_KEYS[i];
        var t = (k - a[0]) / (b[0] - a[0]);
        t = t * t * (3 - 2 * t); // smoothstep inside the segment
        return {
          sh: a[1] + (b[1] - a[1]) * t,
          el: a[2] + (b[2] - a[2]) * t,
          lean: a[3] + (b[3] - a[3]) * t,
          crouch: a[4] + (b[4] - a[4]) * t,
          phase: k < 0.32 ? 'windup' : (k < 0.52 ? 'contact' : 'follow')
        };
      }
    }
    return { sh: -0.5, el: 0.5, lean: 0, crouch: 0, phase: 'ready' };
  }
  function swingKOf(anim) { return anim.swingT > 0 ? 1 - anim.swingT / SWING_DUR : -1; }
  function startSwing(side, atContact) {
    var anim = side === 1 ? avatar : nearAnim;
    anim.swingT = atContact ? SWING_DUR * (1 - SWING_CONTACT_K) : SWING_DUR;
  }
  var aiErr = [0, 0];
  var bounceFx = 0;
  var trail = [];
  var particles = [];
  var keys = {};
  var renderInfo = { ballPx: { x: 0, y: 0, r: 0 }, shadowPx: { x: 0, y: 0 }, surfaceY: 0 };

  /* ---------------- projection ----------------
     Trapezoid broadcast view: near edge y=1005 half-width 855,
     far edge y=415 half-width 385, rational depth falloff. */
  var NEAR_Y = 1005, FAR_Y = 415, NEAR_HW = 855;
  var W_FAR = 1 / (1 + 1.22);    // depth scale at the far edge (~0.4505)
  function proj(x, z, h) {
    var u = (z + 1) / 2;
    var w = 1 / (1 + 1.22 * u);
    var g = (1 - w) / (1 - W_FAR);
    var yBase = NEAR_Y - (NEAR_Y - FAR_Y) * g;
    return {
      x: W / 2 + x * NEAR_HW * w,
      y: yBase - (h || 0) * 470 * w,
      w: w,
      r: 30 * (0.35 + 0.65 * w)
    };
  }
  function tablePath(c, grow) {
    var g = grow || 0;
    var a = proj(-1 - g, -1 - g, 0), b = proj(1 + g, -1 - g, 0),
        d = proj(1 + g, 1 + g, 0), e = proj(-1 - g, 1 + g, 0);
    c.beginPath();
    c.moveTo(a.x, a.y); c.lineTo(b.x, b.y); c.lineTo(d.x, d.y); c.lineTo(e.x, e.y);
    c.closePath();
  }
  function x01OfBat(side) { return (bats[side].x - T.batMin) / (T.batMax - T.batMin); }

  /* ---------------- quality manager ----------------
     Full effects at level 2; slow frames step down: 1 (no trail,
     fewer particles), 0 (flat crowd, no particles). Never steps up
     mid-match. Faster shed than the old build (the TV trail-smear
     finding): ~0.6 s of slow frames drops a level. */
  var quality = 2, frameAvg = 16.7, slowFrames = 0;
  function noteFrame(dtMs) {
    frameAvg = frameAvg * 0.92 + dtMs * 0.08;
    if (frameAvg > 26 && quality > 0) {
      if (++slowFrames > 18) { quality--; slowFrames = 0; staticLayer = null; netLayer = null; }
    } else if (slowFrames > 0) slowFrames--;
  }

  /* ---------------- sound (WebAudio synth, lobby toggle, default OFF) ---- */
  var AC = null;
  function ensureAudio() {
    if (AC) { if (AC.resume) AC.resume(); return true; }
    try {
      var Ctor = window.AudioContext || window.webkitAudioContext;
      if (!Ctor) return false;
      AC = new Ctor();
      return true;
    } catch (e) { return false; }
  }
  function tone(freq, dur, type, vol, delay, slideTo) {
    if (!AC) return;
    try {
      var t0 = AC.currentTime + (delay || 0);
      var o = AC.createOscillator(), g = AC.createGain();
      o.type = type || 'sine';
      o.frequency.setValueAtTime(freq, t0);
      if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
      g.gain.setValueAtTime(vol, t0);
      g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
      o.connect(g); g.connect(AC.destination);
      o.start(t0); o.stop(t0 + dur + 0.02);
    } catch (e) {}
  }
  function sfx(name) {
    if (!settings.sound || !AC) return;
    if (name === 'pop') { tone(210, 0.07, 'square', 0.20, 0, 80); tone(1200, 0.03, 'sine', 0.10); }
    else if (name === 'bounce') { tone(340, 0.045, 'sine', 0.13, 0, 240); }
    else if (name === 'net') { tone(95, 0.16, 'sawtooth', 0.10, 0, 60); }
    else if (name === 'score') { tone(660, 0.09, 'sine', 0.16); tone(880, 0.12, 'sine', 0.16, 0.09); }
    else if (name === 'win') { tone(523, 0.12, 'sine', 0.18); tone(659, 0.12, 'sine', 0.18, 0.11); tone(784, 0.12, 'sine', 0.18, 0.22); tone(1046, 0.22, 'sine', 0.18, 0.33); }
  }

  /* ---------------- flashes & particles ---------------- */
  function showFlash(text, sub, color, dur) {
    flash.text = text; flash.sub = sub || ''; flash.color = color || '#ffffff';
    flash.t = 0; flash.dur = dur || 1.15;
  }
  function burst(sx, sy, color, n) {
    if (quality === 0) return;
    for (var i = 0; i < n; i++) {
      var a = Math.random() * Math.PI * 2, sp = 120 + Math.random() * 420;
      particles.push({ x: sx, y: sy, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 60,
        life: 0.7 + Math.random() * 0.5, t: 0, color: color, r: 3 + Math.random() * 5 });
    }
  }
  function stepParticles(dt) {
    for (var i = particles.length - 1; i >= 0; i--) {
      var p = particles[i];
      p.t += dt;
      if (p.t >= p.life) { particles.splice(i, 1); continue; }
      p.vy += 620 * dt;
      p.x += p.vx * dt; p.y += p.vy * dt;
    }
  }

  /* ---------------- crowd (animated layer + generated audio) ----
     The stands are a light dynamic layer over the baked backdrop:
     a capped set of fans (fewer as quality steps down) that bounce
     on a travelling ripple when a point lands — bigger after long
     rallies — run a standing wave on game/match wins, and settle
     (dip) on faults and lets. The sound is synthesized crowd noise
     (filtered noise swells, no audio files) and only ever plays
     when the sound toggle is ON (default OFF). */
  var crowd = { excite: 0, rippleAt: -9999, waveUntil: 0, dipUntil: 0,
                plays: 0, lastPlayAt: 0 };
  var CROWD_SKINS = ['#d9a066', '#b87a4a', '#8a5a34', '#eec39a', '#6e4525'];
  var CROWD_CLOTH = ['#3a6396', '#7a439e', '#a8404f', '#3f8a68', '#b08a3d', '#4a6a8a', '#8a5570', '#555770'];
  var crowdFans = null;
  function buildCrowdFans() {
    var rnd = srand(20261114);
    crowdFans = [];
    for (var i = 0; i < 120; i++) {
      crowdFans.push({ x: 36 + rnd() * (W - 72), y: 58 + rnd() * 215,
        skin: CROWD_SKINS[(rnd() * CROWD_SKINS.length) | 0],
        cloth: CROWD_CLOTH[(rnd() * CROWD_CLOTH.length) | 0],
        ph: rnd() * Math.PI * 2, big: rnd() > 0.72 });
    }
  }
  function crowdPoint(rallyLen) {
    crowd.excite = Math.min(1, 0.38 + (rallyLen || 0) * 0.055);
    crowd.rippleAt = performance.now();
  }
  function crowdWave() {
    crowd.waveUntil = performance.now() + 2400;
    crowd.excite = 1;
    crowd.rippleAt = performance.now();
  }
  function crowdDip() { crowd.dipUntil = performance.now() + 750; }
  function stepCrowd(dt) {
    if (crowd.excite > 0) crowd.excite = Math.max(0, crowd.excite - dt * 0.45);
  }
  function crowdNoise(intensity, seconds) {
    if (!settings.sound) return;
    ensureAudio();
    if (!AC) return;
    try {
      var dur = seconds || 0.9;
      var len = Math.floor(AC.sampleRate * dur);
      var buf = AC.createBuffer(1, len, AC.sampleRate);
      var d = buf.getChannelData(0);
      for (var i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      var src = AC.createBufferSource(); src.buffer = buf;
      var bp = AC.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 0.7;
      bp.frequency.setValueAtTime(500, AC.currentTime);
      bp.frequency.linearRampToValueAtTime(950, AC.currentTime + dur * 0.4);
      bp.frequency.linearRampToValueAtTime(420, AC.currentTime + dur);
      var g = AC.createGain();
      var peak = 0.05 + 0.20 * S.clamp(intensity, 0, 1);
      g.gain.setValueAtTime(0.0001, AC.currentTime);
      g.gain.exponentialRampToValueAtTime(peak, AC.currentTime + dur * 0.25);
      g.gain.exponentialRampToValueAtTime(0.0001, AC.currentTime + dur);
      src.connect(bp); bp.connect(g); g.connect(AC.destination);
      src.start();
      crowd.plays++;
      crowd.lastPlayAt = performance.now();
    } catch (e) {}
  }
  function drawCrowd(now) {
    if (!crowdFans) buildCrowdFans();
    var n = quality === 2 ? 120 : quality === 1 ? 64 : 26;
    var rippleAge = (now - crowd.rippleAt) / 1000;
    var dip = now < crowd.dipUntil ? 1 : 0;
    var waving = now < crowd.waveUntil;
    for (var i = 0; i < n; i++) {
      var f = crowdFans[i];
      var amp = 0.8 + crowd.excite * 4.2;
      var bounce = Math.abs(Math.sin(now / 210 + f.ph - rippleAge * 5 + f.x * 0.0035)) * amp;
      var sink = dip * 4;
      var stand = 0;
      if (waving) {
        var wph = (now / 240 - f.x / 130) % (Math.PI * 2);
        stand = Math.max(0, Math.sin(wph)) * 7;
      }
      var y = f.y - bounce - stand + sink;
      ctx.fillStyle = f.cloth;
      ctx.fillRect(f.x - 4.5, y + 3, 9, 8);
      ctx.fillStyle = f.skin;
      ctx.beginPath(); ctx.arc(f.x, y, f.big ? 5 : 4.1, 0, Math.PI * 2); ctx.fill();
      if ((crowd.excite > 0.45 || waving) && f.big) {
        ctx.fillRect(f.x - 7.5, y - 6 - bounce * 0.4, 2.6, 6);
        ctx.fillRect(f.x + 4.9, y - 6 - bounce * 0.4, 2.6, 6);
      }
    }
  }

  /* ---------------- controllers ---------------- */
  function controllerOf(side) {
    if (rallyBot) return 'bot';
    var p = playerAtSide(side);
    var e = net.players[p];
    if (e) return e.mode === 'swing' ? 'phone-swing' : 'phone-auto';
    return players[p].kind === 'ai' ? 'ai' : 'local';
  }
  function diff() { return S.DIFFICULTY[settings.difficulty]; }

  /* ---------------- flow ---------------- */
  function updateServer() {
    var total = scores[0] + scores[1];
    var per = (scores[0] >= 10 && scores[1] >= 10) ? 1 : 2;
    server = (Math.floor(total / per) % 2 === 0) ? firstServer : 1 - firstServer;
  }
  function setServe() {
    phase = 'serve';
    serveTimer = 0;
    flight = null;
    ball.live = false;
    pendingSwing = [null, null];
    var side = sideOfPlayer(server);
    ball.x = bats[side].x;
    ball.z = side === 0 ? -1.04 : 1.04;
    ball.h = 0.30;
    ball.vx = 0; ball.vz = 0; ball.vh = 0;
    sendNetState();
  }
  function startGameCommon() {
    scores = [0, 0];
    bestRally = 0;
    gameWinner = -1;
    switchedThisGame = false;
    paused = false;
    bats[0].x = bats[0].target = 0;
    bats[1].x = bats[1].target = 0;
    document.getElementById('lobbyPanel').classList.add('hidden');
    document.getElementById('overPanel').classList.add('hidden');
    hidePause();
    updateServer();
    setServe();
  }
  function startMatch(m) {
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    mode = m;
    games = [0, 0];
    gameNumber = 1;
    firstServer = 0;
    matchWinner = -1;
    matchBestRally = 0;
    endsSwapped = false;
    applyModeIdentities();
    startGameCommon();
  }
  function nextGame() {
    gameNumber++;
    firstServer = (gameNumber - 1) % 2;
    endsSwapped = !endsSwapped;      // ends switch after each game
    startGameCommon();
  }
  function applyModeIdentities() {
    for (var gi = 0; gi < 2; gi++) {
      if (!net.players[gi]) players[gi].gender = lobbyGender[gi];
      else if (net.players[gi].gender) players[gi].gender = net.players[gi].gender;
    }
    if (mode === 'ai') {
      if (!net.players[0]) { players[0].name = 'You'; players[0].color = S.COLORS[0].hex; }
      if (!net.players[1]) { players[1].name = 'Computer'; players[1].color = S.COLORS[1].hex; }
      players[0].kind = net.players[0] ? 'phone' : 'human';
      players[1].kind = net.players[1] ? 'phone' : 'ai';
    } else if (mode === 'local') {
      if (!net.players[0]) { players[0].name = 'Player 1'; players[0].color = S.COLORS[0].hex; }
      if (!net.players[1]) { players[1].name = 'Player 2'; players[1].color = S.COLORS[2].hex; }
      players[0].kind = net.players[0] ? 'phone' : 'human';
      players[1].kind = net.players[1] ? 'phone' : 'human';
    } else { // phone
      players[0].kind = net.players[0] ? 'phone' : 'human';
      players[1].kind = net.players[1] ? 'phone' : 'ai';
      if (!net.players[0]) { players[0].name = 'Guest (TV)'; players[0].color = S.COLORS[0].hex; }
      if (!net.players[1]) { players[1].name = 'Computer'; players[1].color = S.COLORS[1].hex; }
    }
  }
  function toLobby() {
    phase = 'lobby';
    paused = false;
    ball.live = false;
    flight = null;
    document.getElementById('overPanel').classList.add('hidden');
    hidePause();
    var p = document.getElementById('lobbyPanel');
    p.classList.remove('hidden');
    document.getElementById('btnModeAI').focus();
    sendNetState();
  }
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* ---------------- the serve ----------------
     Official shape: toss at the server's end, first bounce on the
     SERVER's half, second on the receiver's. Ballistics: contact
     height 0.30, first-bounce time T1 = 0.44 s; the restitution
     bounce sets the second flight, and vz is solved so the first
     bounce lands on the server's half — the second then lands on
     the receiver's (net clearance ~0.20 > 0.17, verified in tests). */
  function launchServe() {
    if (phase !== 'serve') return;
    var side = sideOfPlayer(server);
    var dir = side === 0 ? 1 : -1;
    var z0 = side === 0 ? -1.04 : 1.04;
    var z1 = z0 + dir * (0.49 + Math.random() * 0.17);       // own-half bounce
    var T1 = 0.44, h0 = 0.30;
    var vz = (z1 - z0) / T1;
    var vh = (0.5 * T.gravity * T1 * T1 - h0) / T1;
    var tx = (Math.random() * 2 - 1) * 0.5;
    var T2 = 2 * ((T.gravity * T1 - vh) * T.rest) / T.gravity;
    ball.x = bats[side].x; ball.z = z0; ball.h = h0;
    ball.vx = (tx - ball.x) / (T1 + T2);
    ball.vz = vz; ball.vh = vh;
    ball.live = true;
    rallyHits = 0;
    trail.length = 0;
    flight = { fromSide: side, toSide: 1 - side, serve: true, bounces: 0,
               crossed: false, cord: false, tPlane: 0 };
    flight.tPlane = performance.now() + ((dir * T.planeZ - z0) / vz) * 1000;
    rollAiError(flight.toSide);
    startSwing(side, true);
    sfx('pop');
    phase = 'rally';
    sendNetState();
  }

  /* ---------------- returns ---------------- */
  function ballisticTo(tx, tz, T1) {
    var x0 = ball.x, z0 = ball.z, h0 = ball.h;
    var vx = (tx - x0) / T1;
    var vz = (tz - z0) / T1;
    var vh = (0.5 * T.gravity * T1 * T1 - h0) / T1;
    /* aimed returns must clear the net: raise the arc if the natural
       line would clip it (test flights bypass this on purpose) */
    var tNet = (0 - z0) / vz;
    if (tNet > 0) {
      var hNet = h0 + vh * tNet - 0.5 * T.gravity * tNet * tNet;
      if (hNet < T.netH + 0.02) vh += (T.netH + 0.045 - hNet) / tNet;
    }
    ball.vx = vx; ball.vz = vz; ball.vh = vh;
  }
  function doHit(side, grade) {
    var ctrl = controllerOf(side);
    var dir = side === 0 ? 1 : -1;
    var oppBatX = bats[1 - side].x;
    var T1, tx, tz;
    if (grade === 'PERFECT') {
      T1 = 0.60;
      tx = oppBatX >= ball.x ? -0.86 : 0.86;
      tz = dir * (0.84 + Math.random() * 0.10);
    } else if (grade === 'GRAZE') {
      T1 = 1.06;
      tx = S.clamp(ball.x + (Math.random() * 0.3 - 0.15), -0.7, 0.7);
      tz = dir * (0.36 + Math.random() * 0.18);
    } else if (ctrl === 'ai' || ctrl === 'bot') {
      var d = diff();
      T1 = (ctrl === 'bot' ? 0.9 : d.pace) * (0.92 + Math.random() * 0.16);
      tx = S.clamp(-oppBatX * 0.6 + (Math.random() * 2 - 1) * d.aimErr * 2.2, -0.9, 0.9);
      tz = dir * (0.60 + Math.random() * 0.30);
    } else {
      var off = S.clamp((ball.x - bats[side].x) / T.reach, -1, 1);
      T1 = grade === 'GOOD' ? 0.78 : 0.84 * (0.95 + Math.random() * 0.1);
      tx = S.clamp(ball.x + off * 0.8 + (Math.random() * 0.24 - 0.12), -0.92, 0.92);
      tz = dir * (0.60 + Math.random() * 0.30);
    }
    ballisticTo(tx, tz, T1);
    rallyHits++;
    startSwing(side, true);
    var bp = proj(ball.x, ball.z, ball.h);
    burst(bp.x, bp.y, '#ffffff', quality === 2 ? 5 : 3);
    sfx('pop');
    flight = { fromSide: side, toSide: 1 - side, serve: false, bounces: 0,
               crossed: false, cord: false, tPlane: 0 };
    flight.tPlane = performance.now() + (((1 - side) === 1 ? T.planeZ : -T.planeZ) - ball.z) / ball.vz * 1000;
    rollAiError(flight.toSide);
    sendNetState();
  }
  function rollAiError(side) {
    if (controllerOf(side) === 'ai') {
      aiErr[side] = (Math.random() * 2 - 1) * diff().err;
    } else {
      aiErr[side] = 0;
    }
  }

  /* ---------------- point resolution (official rules) ---------------- */
  function endFlightPoint(winnerPlayer, reason) {
    ball.live = false;
    flight = null;
    if (reason === 'NET') sfx('net');
    scorePoint(winnerPlayer, reason);
  }
  function letServe() {
    ball.live = false;
    flight = null;
    letReplay = true;
    crowdDip();
    crowdNoise(0.18, 0.5);
    showFlash('LET', 'serve clips the net and lands in — re-serve', '#e0b93a', 1.3);
    phase = 'point';
    pointTimer = 0;
    sendNetState();
  }
  function bounce() {
    ball.h = 0;
    bounceFx = 1;
    sfx('bounce');
    var inX = Math.abs(ball.x) <= T.halfW + 0.02;
    var inZ = Math.abs(ball.z) <= T.halfL + 0.02;
    if (!inX || !inZ) {           // descended outside the table
      if (!flight) return;
      if (flight.serve || flight.bounces === 0) {
        endFlightPoint(playerAtSide(flight.toSide), flight.serve ? 'SERVE — off the table' : 'OUT — off the table');
      } else {
        endFlightPoint(playerAtSide(flight.fromSide), '');
      }
      return;
    }
    if (!flight) { ball.vh = -ball.vh * T.rest; return; }
    var side = ball.z < 0 ? 0 : 1;
    flight.bounces++;
    if (flight.serve) {
      if (flight.bounces === 1) {
        if (side !== flight.fromSide) { endFlightPoint(playerAtSide(flight.toSide), 'SERVE FAULT — no bounce on own half'); return; }
        ball.vh = -ball.vh * T.rest;
      } else if (flight.bounces === 2) {
        if (side !== flight.toSide) { endFlightPoint(playerAtSide(flight.toSide), 'SERVE FAULT'); return; }
        if (flight.cord) { letServe(); return; }
        ball.vh = -ball.vh * T.rest;
      } else {
        endFlightPoint(playerAtSide(flight.fromSide), '');   // bounced twice: receiver too slow
      }
    } else {
      if (flight.bounces === 1) {
        if (side !== flight.toSide) { endFlightPoint(playerAtSide(flight.toSide), 'INTO OWN HALF'); return; }
        if (flight.cord) showFlash('NET CORD', 'play on', '#b8c4d6', 0.9);
        ball.vh = -ball.vh * T.rest;
      } else {
        endFlightPoint(playerAtSide(flight.fromSide), '');
      }
    }
  }
  function crossedNet() {
    if (!flight || flight.crossed) return;
    flight.crossed = true;
    var pen = T.netH - ball.h;
    if (pen > 0.05) {             // deep into the net: the flight dies
      endFlightPoint(playerAtSide(flight.toSide), 'INTO THE NET');
    } else if (pen > -0.02) {     // net cord: pops over, play (or let) decides at the bounce
      flight.cord = true;
      ball.vz *= 0.55;
      ball.vh = Math.max(ball.vh, 0.35);
    }
  }
  function contactLegal() {
    return flight.serve ? flight.bounces >= 2 : flight.bounces >= 1;
  }
  function contactCheck() {
    var side = flight.toSide;
    if (!contactLegal()) return;              // volley territory: no contact allowed
    var ctrl = controllerOf(side);
    if (ctrl === 'phone-swing') {
      var player = playerAtSide(side);
      var ps = pendingSwing[player];
      if (ps) {
        var dt = ps.at - flight.tPlane;
        pendingSwing[player] = null;
        if (Math.abs(dt) <= S.GRADE_WINDOWS.graze) { gradeHit(side, ps, dt); return; }
      }
      flight.awaitSwing = true;               // a swing inside the grace window can still save it
      flight.graceUntil = performance.now() + 130;
      return;
    }
    if (Math.abs(ball.x - bats[side].x) <= T.reach) doHit(side, null);
  }
  function gradeHit(side, ps, dtMs) {
    var adt = Math.abs(dtMs);
    var grade = adt <= S.GRADE_WINDOWS.perfect && ps.power >= 0.5 ? 'PERFECT'
              : adt <= S.GRADE_WINDOWS.good ? 'GOOD' : 'GRAZE';
    var player = playerAtSide(side);
    lastGrade = { player: player, grade: grade, at: performance.now() };
    showFlash(grade + '!', '', grade === 'PERFECT' ? '#2ecc71' : grade === 'GOOD' ? '#e0b93a' : '#e67e22', 0.85);
    doHit(side, grade);
  }
  function onSwing(player, power, atMs) {
    var side = sideOfPlayer(player);
    startSwing(side, true);
    if (paused) return;
    if (phase === 'serve' && player === server && controllerOf(side) === 'phone-swing') {
      launchServe();
      return;
    }
    if (phase !== 'rally' || !flight || flight.toSide !== side) return;
    if (!contactLegal()) {
      /* volley: a swing that connects before the bounce is a fault */
      var plane = side === 0 ? -T.planeZ : T.planeZ;
      if (Math.abs(ball.x - bats[side].x) <= T.reach + 0.05 &&
          Math.abs(ball.z - plane) < 0.55) {
        showFlash('VOLLEY', 'contact before the bounce — fault', '#e74c3c', 1.2);
        endFlightPoint(1 - player, 'VOLLEY — fault');
      }
      return;
    }
    pendingSwing[player] = { at: atMs, power: power };
    if (flight.awaitSwing) {                  // late swing inside the grace window
      var dt = atMs - flight.tPlane;
      pendingSwing[player] = null;
      flight.awaitSwing = false;
      if (Math.abs(dt) <= S.GRADE_WINDOWS.graze) gradeHit(side, { power: power }, dt);
    }
  }
  function resolveOut() {
    if (!flight) return;
    if (flight.serve && flight.bounces < 2) {
      endFlightPoint(playerAtSide(flight.toSide), 'SERVE — out');
    } else if (!flight.serve && flight.bounces === 0) {
      endFlightPoint(playerAtSide(flight.toSide), 'OUT');
    } else {
      endFlightPoint(playerAtSide(flight.fromSide), '');
    }
  }
  function scorePoint(scorer, reason) {
    scores[scorer]++;
    lastScorer = scorer;
    pointFlash = 1;
    pointReason = reason || '';
    bestRally = Math.max(bestRally, rallyHits);
    matchBestRally = Math.max(matchBestRally, bestRally);
    /* avatar reactions (~0.8 s; the game/match branch below bumps
       them bigger) + crowd: point ripple scaled by rally length,
       a settle-dip on faults */
    var farPlayer = playerAtSide(1);
    if (scorer === farPlayer) { avatar.react = 'cheer'; avatar.reactT = 0.85; }
    else { avatar.react = 'slump'; avatar.reactT = 0.85; }
    if (scorer === playerAtSide(0)) nearAnim.reactT = 0.8;
    crowdPoint(rallyHits);
    if (reason && (reason.indexOf('FAULT') >= 0 || reason.indexOf('out') >= 0)) crowdDip();
    crowdNoise(0.3 + Math.min(0.6, rallyHits * 0.05), 0.9);
    sfx('score');
    /* deciding game: ends switch when the first player reaches 5 */
    var isDeciding = (games[0] + games[1] === S.MATCH_MAX_GAMES - 1);
    if (isDeciding && !switchedThisGame && (scores[0] === 5 || scores[1] === 5)) {
      endsSwapped = !endsSwapped;
      switchedThisGame = true;
      showFlash('CHANGE OF ENDS', 'deciding game — players switch ends', '#e0b93a', 1.4);
    }
    var top = Math.max(scores[0], scores[1]);
    var lead = Math.abs(scores[0] - scores[1]);
    if (top >= S.WIN_SCORE && lead >= S.WIN_LEAD) {
      gameWinner = scores[0] > scores[1] ? 0 : 1;
      games[gameWinner]++;
      if (games[gameWinner] >= S.MATCH_GAMES_TO_WIN) matchWinner = gameWinner;
      phase = 'over';
      /* the big one: larger, longer reaction + standing wave */
      avatar.react = scorer === farPlayer ? 'cheer' : 'slump';
      avatar.reactT = 1.5;
      avatar.reactBig = true;
      if (scorer === playerAtSide(0)) nearAnim.reactT = 1.3;
      crowdWave();
      crowdNoise(1, 1.8);
      sfx('win');
      showGameOver();
    } else {
      phase = 'point';
      pointTimer = 0;
      updateServer();
    }
    sendNetState();
  }
  function showGameOver() {
    var isMatch = matchWinner >= 0;
    var w = isMatch ? matchWinner : gameWinner;
    document.getElementById('overTitle').innerHTML =
      '<span class="winner-name">' + escapeHtml(players[w].name) + '</span> WINS ' + (isMatch ? 'THE MATCH' : 'THE GAME');
    document.getElementById('overScore').textContent = scores[0] + ' — ' + scores[1];
    document.getElementById('overSub').textContent =
      'Games: ' + players[0].name + ' ' + games[0] + ' — ' + games[1] + ' ' + players[1].name +
      ' · Best rally: ' + bestRally + ' hits (match best ' + matchBestRally + ')' +
      (isMatch ? '' : ' · First to ' + S.MATCH_GAMES_TO_WIN + ' games takes the match');
    document.getElementById('btnAgain').innerHTML = isMatch
      ? '↻&nbsp; New Match&nbsp; <small>(Enter)</small>'
      : '↻&nbsp; Next Game&nbsp; <small>(Enter)</small>';
    var p = document.getElementById('overPanel');
    p.classList.remove('hidden');
    document.getElementById('btnAgain').focus();
  }

  /* ---------------- physics ---------------- */
  function integrate(sdt) {
    var pz = ball.z, ph = ball.h;
    ball.x += ball.vx * sdt;
    ball.z += ball.vz * sdt;
    ball.h += ball.vh * sdt;
    ball.vh -= T.gravity * sdt;
    if (flight && ((pz < 0 && ball.z >= 0) || (pz > 0 && ball.z <= 0))) crossedNet();
    if (!flight) return;
    if (ph > 0 && ball.h <= 0 && ball.vh < 0) { bounce(); return; }
    if (!flight) return;
    var plane = flight.toSide === 1 ? T.planeZ : -T.planeZ;
    if ((flight.toSide === 1 && pz < plane && ball.z >= plane) ||
        (flight.toSide === 0 && pz > plane && ball.z <= plane)) {
      contactCheck();
      if (!flight) return;
    }
    if (flight.awaitSwing && pendingSwing[playerAtSide(flight.toSide)]) {
      contactCheck();
      if (!flight) return;
    }
    if (flight.awaitSwing && performance.now() > flight.graceUntil) flight.awaitSwing = false;
    if (Math.abs(ball.z) > T.planeZ + 0.5 &&
        ((flight.toSide === 1 && ball.z > 0) || (flight.toSide === 0 && ball.z < 0))) {
      resolveOut();
    }
    if (ball.h < -0.6) resolveOut();
  }
  function stepBall(dt) {
    if (quality === 2 && phase === 'rally') {
      trail.push({ x: ball.x, z: ball.z, h: ball.h });
      if (trail.length > 9) trail.shift();
    }
    var n = 3, sdt = dt / n;
    for (var i = 0; i < n; i++) {
      if (!ball.live || !flight) break;
      integrate(sdt);
    }
    if (!ball.live) trail.length = 0;
  }

  /* ---------------- bat movement ---------------- */
  function stepBat(side, dt) {
    var b = bats[side];
    var ctrl = controllerOf(side);
    if (ctrl === 'ai' || ctrl === 'bot') {
      var d = ctrl === 'bot' ? S.DIFFICULTY.normal : diff();
      var target = 0;
      if (flight && flight.toSide === side && ball.live) target = ball.x + aiErr[side];
      else if (ball.live) target = ball.x * 0.25;
      var mv = S.clamp(target - b.x, -d.speed * dt, d.speed * dt);
      b.x += mv;
      b.target = b.x;
    } else if (ctrl === 'phone-swing' || ctrl === 'phone-auto') {
      /* prediction line: aim where the phone's stream is HEADING —
         the last target plus its measured velocity extrapolated a
         few tens of ms, the lead fading out as the packet ages so
         a stopped bat settles exactly on target; a firm ease then
         tracks that goal without the old visible trailing */
      var age = Math.max(0, (performance.now() - (b.padAt || 0)) / 1000);
      var lead = age * Math.max(0, 1 - age / 0.2);
      var goal = S.clamp(b.target + (b.padVel || 0) * lead, T.batMin, T.batMax);
      var k = Math.min(1, dt * 30);
      b.x += (goal - b.x) * k;
    } else {
      stepLocalKeys(side, dt);
      var k2 = Math.min(1, dt * 22);
      b.x += (b.target - b.x) * k2;
    }
    b.x = S.clamp(b.x, T.batMin, T.batMax);
    b.target = S.clamp(b.target, T.batMin, T.batMax);
  }
  function stepLocalKeys(side, dt) {
    var player = playerAtSide(side);
    var b = bats[side];
    var left = false, right = false;
    if (player === 0) {
      left = keys['KeyA'] || (mode !== 'local' && (keys['ArrowLeft'] || keys['ArrowUp']));
      right = keys['KeyD'] || (mode !== 'local' && (keys['ArrowRight'] || keys['ArrowDown']));
    } else {
      left = keys['ArrowLeft'] || keys['ArrowUp'];
      right = keys['ArrowRight'] || keys['ArrowDown'];
    }
    if (left) b.target -= T.batSpeed * dt;
    if (right) b.target += T.batSpeed * dt;
  }

  function update(dt) {
    /* body + crowd timers run in EVERY phase (lobby and game-over
       included) so reactions and the crowd never freeze mid-gesture */
    if (avatar.swingT > 0) avatar.swingT = Math.max(0, avatar.swingT - dt);
    if (avatar.reactT > 0) { avatar.reactT = Math.max(0, avatar.reactT - dt); if (avatar.reactT === 0) { avatar.react = ''; avatar.reactBig = false; } }
    if (nearAnim.swingT > 0) nearAnim.swingT = Math.max(0, nearAnim.swingT - dt);
    if (nearAnim.reactT > 0) nearAnim.reactT = Math.max(0, nearAnim.reactT - dt);
    /* far avatar body: springy lateral tracking (acceleration and
       easing instead of a linear slide), a ready crouch while it is
       receiving, and a head that follows the ball */
    var aTarget = bats[1].x;
    avatar.vx += ((aTarget - avatar.x) * 26 - avatar.vx * 9) * dt;
    avatar.x += avatar.vx * dt;
    avatar.stepPhase += Math.abs(avatar.vx) * dt * 7;
    var wantCrouch = (phase === 'serve' && server !== playerAtSide(1)) ||
                     (phase === 'rally' && flight && flight.toSide === 1) ? 1 : 0;
    avatar.crouch += (wantCrouch - avatar.crouch) * Math.min(1, dt * 7);
    var lookTarget = ball.live ? S.clamp((ball.x - avatar.x) * 1.6, -1, 1) : 0;
    avatar.headT += (lookTarget - avatar.headT) * Math.min(1, dt * 10);
    stepCrowd(dt);
    if (phase === 'lobby' || phase === 'over') { stepParticles(dt); return; }
    stepBat(0, dt);
    stepBat(1, dt);
    /* anticipation: open the full swing cycle early enough that its
       CONTACT keyframe lands as the ball reaches the plane */
    if (phase === 'rally' && flight && ball.live) {
      var lead = (flight.tPlane - performance.now()) / 1000;
      if (lead > 0 && lead < SWING_DUR * SWING_CONTACT_K) {
        var incAnim = flight.toSide === 1 ? avatar : nearAnim;
        if (incAnim.swingT <= 0) startSwing(flight.toSide, false);
      }
    }
    if (phase === 'serve') {
      var side = sideOfPlayer(server);
      ball.x = bats[side].x;
      ball.z = side === 0 ? -1.04 : 1.04;
      serveTimer += dt;
      var ctrl = controllerOf(side);
      if (ctrl === 'phone-swing' || ctrl === 'phone-auto') {
        if (serveTimer > 6) launchServe();               // never stall a phone game
      } else if (ctrl === 'ai' || ctrl === 'bot') {
        if (serveTimer > 0.9) launchServe();
      } else if (serveTimer > 1.6) {
        launchServe();
      }
    } else if (phase === 'rally') {
      stepBall(dt);
    } else if (phase === 'point') {
      pointTimer += dt;
      if (pointTimer > (letReplay ? 1.5 : 1.25)) {
        letReplay = false;
        if (phase === 'point') setServe();
      }
    }
    if (pointFlash > 0) pointFlash = Math.max(0, pointFlash - dt * 1.4);
    if (bounceFx > 0) bounceFx = Math.max(0, bounceFx - dt * 3.2);
    if (flash.dur > 0) { flash.t += dt; if (flash.t >= flash.dur) flash.dur = 0; }
    stepParticles(dt);
  }

  /* ---------------- rendering ---------------- */
  function rr(c, x, y, w, h, r) {
    c.beginPath();
    c.moveTo(x + r, y);
    c.arcTo(x + w, y, x + w, y + h, r);
    c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r);
    c.arcTo(x, y, x + w, y, r);
    c.closePath();
  }
  function shade(hex, f) {
    var n = parseInt(hex.slice(1), 16);
    var r = Math.min(255, Math.max(0, ((n >> 16) & 255) * f));
    var g = Math.min(255, Math.max(0, ((n >> 8) & 255) * f));
    var b = Math.min(255, Math.max(0, (n & 255) * f));
    return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
  }
  /* deterministic pseudo-random for the crowd (same every frame) */
  function srand(seed) { var s = seed; return function () { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; }; }

  var staticLayer = null;
  function buildStatic() {
    var layer = document.createElement('canvas');
    layer.width = W; layer.height = H;
    var c = layer.getContext('2d');
    /* arena darkness + floodlight pools */
    c.fillStyle = '#060f22';
    c.fillRect(0, 0, W, H);
    var glow = c.createRadialGradient(W / 2, 470, 120, W / 2, 470, 1150);
    glow.addColorStop(0, 'rgba(52,104,168,0.50)');
    glow.addColorStop(0.55, 'rgba(24,56,104,0.25)');
    glow.addColorStop(1, 'rgba(3,8,18,0)');
    c.fillStyle = glow;
    c.fillRect(0, 0, W, H);
    var fl = c.createRadialGradient(240, 30, 10, 240, 30, 420);
    fl.addColorStop(0, 'rgba(255,244,200,0.20)'); fl.addColorStop(1, 'rgba(255,244,200,0)');
    c.fillStyle = fl; c.fillRect(0, 0, 700, 460);
    var fr = c.createRadialGradient(1680, 30, 10, 1680, 30, 420);
    fr.addColorStop(0, 'rgba(255,244,200,0.20)'); fr.addColorStop(1, 'rgba(255,244,200,0)');
    c.fillStyle = fr; c.fillRect(1220, 0, 700, 460);

    /* crowd: dense dots + a silhouette heads row (density by quality) */
    var rnd = srand(20261113);
    var rows = quality === 2 ? 9 : quality === 1 ? 6 : 3;
    var cols = quality === 2 ? 118 : quality === 1 ? 84 : 44;
    var skin = ['#d9a066', '#b87a4a', '#8a5a34', '#eec39a', '#6e4525'];
    var cloth = ['#274b73', '#5b2d8e', '#8e2d3c', '#2d6e4f', '#94702d', '#33506e', '#703d57', '#446'];
    for (var ry = 0; ry < rows; ry++) {
      var yy = 52 + ry * 27 + (rnd() * 8 - 4);
      for (var rx = 0; rx < cols; rx++) {
        var xx = 30 + rx * ((W - 60) / cols) + (rnd() * 10 - 5);
        c.fillStyle = cloth[(rnd() * cloth.length) | 0];
        c.fillRect(xx - 5, yy + 5, 10, 9);
        c.fillStyle = skin[(rnd() * skin.length) | 0];
        c.beginPath(); c.arc(xx, yy, 4.6, 0, Math.PI * 2); c.fill();
      }
    }
    if (quality > 0) {
      c.fillStyle = 'rgba(4,8,16,0.55)';
      for (var hx = 16; hx < W; hx += 34) {
        c.beginPath(); c.arc(hx + (hx % 3) * 4, 306, 13, 0, Math.PI * 2); c.fill();
        c.fillRect(hx - 13, 306, 26, 16);
      }
    }
    /* arena boards */
    var bg = c.createLinearGradient(0, 322, 0, 402);
    bg.addColorStop(0, '#123a6b'); bg.addColorStop(1, '#0a2247');
    c.fillStyle = bg;
    c.fillRect(0, 322, W, 82);
    c.fillStyle = 'rgba(201,162,39,0.85)';
    c.fillRect(0, 322, W, 3);
    c.fillRect(0, 401, W, 3);
    c.fillStyle = '#ffffff';
    c.font = '900 44px -apple-system, "Segoe UI", Roboto, sans-serif';
    c.textAlign = 'left'; c.textBaseline = 'middle';
    c.fillText('MOTION ARENA', 46, 364);
    c.fillStyle = '#C9A227';
    c.font = '800 30px -apple-system, "Segoe UI", Roboto, sans-serif';
    c.fillText('· TABLE TENNIS', 452, 366);
    c.textAlign = 'right';
    c.fillStyle = 'rgba(255,255,255,0.75)';
    c.font = '700 25px -apple-system, "Segoe UI", Roboto, sans-serif';
    c.fillText('IEC · INC', 1874, 364);
    /* paddle glyph on the left board */
    c.save();
    c.translate(24, 364);
    c.fillStyle = '#e8edf4';
    c.beginPath(); c.arc(0, -6, 11, 0, Math.PI * 2); c.fill();
    c.fillRect(-2.5, 2, 5, 13);
    c.restore();

    /* floor around the table */
    var fg = c.createLinearGradient(0, 404, 0, H);
    fg.addColorStop(0, '#0a1c38'); fg.addColorStop(1, '#050d1d');
    c.fillStyle = fg;
    c.fillRect(0, 404, W, H - 404);

    /* table: apron then trapezoid surface */
    var n1 = proj(-1, -1, 0), n2 = proj(1, -1, 0), f2 = proj(1, 1, 0), f1 = proj(-1, 1, 0);
    c.fillStyle = '#071426';
    c.beginPath();
    c.moveTo(n1.x, n1.y); c.lineTo(n2.x, n2.y); c.lineTo(n2.x, n2.y + 30); c.lineTo(n1.x, n1.y + 30);
    c.closePath(); c.fill();
    var tg = c.createLinearGradient(0, f1.y, 0, n1.y);
    tg.addColorStop(0, '#14508c');
    tg.addColorStop(0.55, '#17507f');
    tg.addColorStop(1, '#1d5c96');
    c.fillStyle = tg;
    c.beginPath();
    c.moveTo(n1.x, n1.y); c.lineTo(n2.x, n2.y); c.lineTo(f2.x, f2.y); c.lineTo(f1.x, f1.y);
    c.closePath(); c.fill();
    /* gloss sheen toward the near end */
    if (quality > 0) {
      var sheen = c.createLinearGradient(0, n1.y, 0, 560);
      sheen.addColorStop(0, 'rgba(255,255,255,0.10)');
      sheen.addColorStop(1, 'rgba(255,255,255,0)');
      c.fillStyle = sheen;
      c.beginPath();
      c.moveTo(n1.x, n1.y); c.lineTo(n2.x, n2.y); c.lineTo(f2.x, f2.y); c.lineTo(f1.x, f1.y);
      c.closePath(); c.fill();
    }
    /* lines: outline + centre line */
    c.strokeStyle = 'rgba(255,255,255,0.95)';
    c.lineWidth = 5;
    c.beginPath();
    c.moveTo(n1.x, n1.y); c.lineTo(n2.x, n2.y); c.lineTo(f2.x, f2.y); c.lineTo(f1.x, f1.y);
    c.closePath(); c.stroke();
    c.lineWidth = 3;
    c.beginPath();
    c.moveTo(W / 2, n1.y); c.lineTo(W / 2, f1.y);
    c.stroke();
    staticLayer = layer;
  }
  var netLayer = null;
  function buildNet() {
    var layer = document.createElement('canvas');
    layer.width = W; layer.height = H;
    var c = layer.getContext('2d');
    var mid = proj(0, 0, 0);
    var hw = NEAR_HW * mid.w + 26;
    var topY = mid.y - T.netH * 470 * mid.w;
    c.fillStyle = 'rgba(5,10,20,0.88)';
    c.fillRect(W / 2 - hw - 7, topY - 8, 14, mid.y - topY + 30);
    c.fillRect(W / 2 + hw - 7, topY - 8, 14, mid.y - topY + 30);
    c.fillStyle = 'rgba(8,18,36,0.55)';
    c.fillRect(W / 2 - hw, topY, hw * 2, mid.y - topY);
    if (quality > 0) {
      c.strokeStyle = 'rgba(255,255,255,0.22)';
      c.lineWidth = 1.2;
      c.beginPath();
      for (var gy = topY + 6; gy < mid.y; gy += 11) { c.moveTo(W / 2 - hw, gy); c.lineTo(W / 2 + hw, gy); }
      for (var gx = W / 2 - hw + 6; gx < W / 2 + hw; gx += 11) { c.moveTo(gx, topY); c.lineTo(gx, mid.y); }
      c.stroke();
    }
    c.fillStyle = '#f4f6f8';
    c.fillRect(W / 2 - hw - 2, topY - 5, hw * 2 + 4, 8);
    netLayer = layer;
  }

  /* far-end avatar: flat IEC-original vector figure in the far
     player's colour and variant (male / female silhouettes on one
     rig); clipped so the table hides its lower body. The rig:
     spring-tracked position with stepping feet, a crouch while
     receiving, the keyframed swing cycle, head/eyes on the ball,
     and point reactions that grow on game/match points. */
  function drawAvatar(now) {
    var farPlayer = playerAtSide(1);
    var color = players[farPlayer].color;
    var female = players[farPlayer].gender === 'female';
    var base = proj(avatar.x, 1.28, 0);
    var ax = base.x, groundY = FAR_Y + 8;
    var pose = avatar.swingT > 0 ? swingPose(swingKOf(avatar)) : null;
    var crouch = avatar.crouch * 16 + (pose ? pose.crouch * 12 : 0);
    var sway = Math.sin(now / 640) * 3;
    var velLean = S.clamp(avatar.vx * 0.16, -0.16, 0.16);
    var lean = velLean + (pose ? pose.lean * 0.30 : 0);
    var big = avatar.reactBig ? 1.45 : 1;
    var cheer = avatar.react === 'cheer';
    var bounce = cheer ? Math.abs(Math.sin(now / 130)) * 7 * big : 0;
    var slump = avatar.react === 'slump' ? 9 * big : 0;
    var stepBob = Math.sin(avatar.stepPhase * 6) * S.clamp(Math.abs(avatar.vx) * 5, 0, 3.2);
    var stepOff = S.clamp(Math.abs(avatar.vx) * 26, 0, 9);
    var torsoW = female ? 100 : 116, torsoX = female ? -50 : -58;
    var hipY = -118 + crouch * 0.55;
    var torsoTop = -308 + slump + crouch;
    var headR = female ? 27 : 30;
    var headX = sway * 0.5 + avatar.headT * 7;
    var headY = torsoTop - 36 + crouch * 0.2;
    ctx.save();
    ctx.beginPath(); ctx.rect(0, 0, W, groundY); ctx.clip();
    ctx.translate(ax, groundY - bounce + Math.abs(stepBob) * 0.4);
    ctx.rotate(lean * 0.45);
    /* legs: dark kit bottoms — shorts (male) / skirt + legs (female);
       feet step alternately while the body is moving */
    if (female) {
      ctx.fillStyle = shade(color, 0.5);
      ctx.beginPath();
      ctx.moveTo(-40, hipY - 34); ctx.lineTo(40, hipY - 34);
      ctx.lineTo(50, hipY + 4); ctx.lineTo(-50, hipY + 4);
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = '#e0aa7e';
      ctx.fillRect(-34 + stepOff * 0.7, hipY, 17, -hipY - 4);
      ctx.fillRect(18 - stepOff * 0.7, hipY, 17, -hipY - 4);
    } else {
      ctx.fillStyle = '#101c30';
      ctx.fillRect(-36 + stepOff, hipY - 6, 27, -hipY + 2);
      ctx.fillRect(10 - stepOff, hipY - 6, 27, -hipY + 2);
      ctx.fillStyle = '#e0aa7e';
      ctx.fillRect(-33 + stepOff, -52, 21, 48);
      ctx.fillRect(13 - stepOff, -52, 21, 48);
    }
    /* torso (kit shirt; the female kit carries a light trim band) */
    var tg2 = ctx.createLinearGradient(-60, -300, 70, -110);
    tg2.addColorStop(0, shade(color, 1.12));
    tg2.addColorStop(1, shade(color, 0.72));
    ctx.fillStyle = tg2;
    rr(ctx, torsoX, torsoTop, torsoW, hipY + 30 - torsoTop, 34);
    ctx.fill();
    if (female) {
      ctx.fillStyle = 'rgba(255,255,255,0.75)';
      ctx.fillRect(torsoX + 6, torsoTop + 26, torsoW - 12, 7);
    }
    /* head: skin, hair (cap for male, long sides + ponytail for
       female), eyes that track the ball */
    ctx.fillStyle = '#e0aa7e';
    ctx.beginPath(); ctx.arc(headX, headY, headR, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#2b1c10';
    if (female) {
      ctx.beginPath(); ctx.arc(headX, headY - 4, headR + 1, Math.PI * 0.95, Math.PI * 2.05); ctx.fill();
      ctx.fillRect(headX - headR - 2, headY - 6, 8, 44);
      ctx.fillRect(headX + headR - 6, headY - 6, 8, 44);
      ctx.save();
      ctx.translate(headX + headR + 3, headY - 10);
      ctx.rotate(0.5 + Math.sin(now / 300) * 0.06 + velLean);
      ctx.fillRect(-4, 0, 9, 52);
      ctx.restore();
    } else {
      ctx.beginPath(); ctx.arc(headX, headY - 3, headR, Math.PI, Math.PI * 2); ctx.fill();
      ctx.fillRect(headX - headR, headY - 5, headR * 2, 8);
    }
    var look = avatar.headT * 4.5;
    ctx.fillStyle = '#1c1410';
    ctx.beginPath(); ctx.arc(headX - 10 + look, headY + 3, 2.6, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath(); ctx.arc(headX + 10 + look, headY + 3, 2.6, 0, Math.PI * 2); ctx.fill();
    /* left arm (viewer left): raised in a cheer, hanging in a slump */
    var lShX = torsoX + 6, lShY = torsoTop + 16 + slump;
    ctx.strokeStyle = shade(color, 0.9);
    ctx.lineWidth = 21; ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(lShX, lShY);
    if (cheer) { ctx.lineTo(lShX - 32, lShY - 68); ctx.lineTo(lShX - 40, lShY - 116); }
    else { ctx.lineTo(lShX - 24, lShY + 74 - crouch * 0.4); ctx.lineTo(lShX - 14, lShY + 134 - crouch * 0.5); }
    ctx.stroke();
    ctx.strokeStyle = '#e0aa7e';
    ctx.lineWidth = 15;
    ctx.beginPath();
    if (cheer) { ctx.moveTo(lShX - 40, lShY - 116); ctx.lineTo(lShX - 44, lShY - 136); }
    else { ctx.moveTo(lShX - 14, lShY + 134 - crouch * 0.5); ctx.lineTo(lShX - 10, lShY + 154 - crouch * 0.5); }
    ctx.stroke();
    /* bat arm (viewer right): the keyframed swing cycle */
    var ang, bend;
    if (pose) { ang = pose.sh; bend = pose.el; }
    else if (cheer) { ang = -2.6; bend = 0.4; }
    else { ang = -0.5 + Math.sin(now / 520) * 0.08 - avatar.crouch * 0.25; bend = 0.5 + avatar.crouch * 0.3; }
    var shX = torsoX + torsoW - 8, shY = torsoTop + 16 + slump;
    var elX = shX + Math.cos(ang) * 62, elY = shY - Math.sin(ang) * 62;
    var handX = elX + Math.cos(ang + bend) * 52, handY = elY - Math.sin(ang + bend) * 52;
    ctx.strokeStyle = shade(color, 0.9);
    ctx.lineWidth = 21;
    ctx.beginPath(); ctx.moveTo(shX, shY); ctx.lineTo(elX, elY); ctx.stroke();
    ctx.strokeStyle = '#e0aa7e';
    ctx.lineWidth = 15;
    ctx.beginPath(); ctx.moveTo(elX, elY); ctx.lineTo(handX, handY); ctx.stroke();
    /* bat */
    ctx.save();
    ctx.translate(handX, handY);
    ctx.rotate(-ang * 0.6);
    ctx.fillStyle = '#3a2415';
    ctx.fillRect(-4, 0, 8, 26);
    ctx.fillStyle = color;
    ctx.beginPath(); ctx.ellipse(0, -14, 25, 31, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'rgba(10,16,28,0.85)';
    ctx.beginPath(); ctx.ellipse(0, -14, 19, 25, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    ctx.restore();
  }

  /* near end: your bat + forearm at the bottom of the picture,
     driven by the same keyframed swing cycle as the far avatar
     (dip back on the wind-up, sweep through contact, high
     follow-through) and wearing the near player's kit — the
     female kit shows its light trim band at the wrist. */
  function drawNearBat(now) {
    var nearPlayer = playerAtSide(0);
    var color = players[nearPlayer].color;
    var female = players[nearPlayer].gender === 'female';
    var bp = proj(bats[0].x, -1.12, 0.10);
    var pump = nearAnim.reactT > 0 ? Math.sin(nearAnim.reactT * 10) * 8 : 0;
    var pose = nearAnim.swingT > 0 ? swingPose(swingKOf(nearAnim)) : null;
    var lift = pose ? pose.lean * 95 : 0;
    var back = pose && swingKOf(nearAnim) < 0.32 ? (0.32 - swingKOf(nearAnim)) * 60 : 0;
    var cxp = bp.x + back, cyp = bp.y + 66 - lift - pump;
    /* forearm / sleeve wedge from the bottom edge to the handle */
    ctx.fillStyle = shade(color, 0.55);
    ctx.beginPath();
    ctx.moveTo(cxp - 30, H);
    ctx.lineTo(cxp + 30, H);
    ctx.lineTo(cxp + 10, cyp + 66);
    ctx.lineTo(cxp - 10, cyp + 66);
    ctx.closePath(); ctx.fill();
    if (female) {
      ctx.fillStyle = 'rgba(255,255,255,0.75)';
      ctx.beginPath();
      ctx.moveTo(cxp - 17, cyp + 92); ctx.lineTo(cxp + 17, cyp + 92);
      ctx.lineTo(cxp + 13, cyp + 74); ctx.lineTo(cxp - 13, cyp + 74);
      ctx.closePath(); ctx.fill();
    }
    /* handle */
    ctx.fillStyle = '#3a2415';
    ctx.save();
    ctx.translate(cxp, cyp);
    ctx.rotate(S.clamp((bats[0].target - bats[0].x) * 0.5, -0.3, 0.3) - lift * 0.002 - (pose ? pose.sh * 0.10 : 0));
    ctx.fillRect(-8, 30, 16, 52);
    /* bat face */
    ctx.fillStyle = color;
    ctx.beginPath(); ctx.ellipse(0, 0, 56, 68, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'rgba(10,16,28,0.88)';
    ctx.beginPath(); ctx.ellipse(0, 0, 45, 57, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.20)';
    ctx.beginPath(); ctx.ellipse(-14, -20, 16, 22, -0.4, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  function drawBall() {
    var sp = proj(ball.x, ball.z, 0);
    var bp = proj(ball.x, ball.z, ball.h);
    renderInfo.shadowPx = { x: Math.round(sp.x), y: Math.round(sp.y) };
    renderInfo.surfaceY = Math.round(sp.y);
    renderInfo.ballPx = { x: Math.round(bp.x), y: Math.round(bp.y), r: Math.round(bp.r) };
    /* shadow: separates, shrinks and fades as the ball rises; pinches at the bounce */
    var pinch = 1 + bounceFx * 0.5;
    var alpha = S.clamp(0.46 - ball.h * 0.42, 0.10, 0.46);
    ctx.beginPath();
    ctx.ellipse(sp.x, sp.y, bp.r * 1.2 * pinch * (1 - Math.min(ball.h, 1) * 0.25), bp.r * 0.42 * pinch, 0, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(2,6,14,' + alpha.toFixed(3) + ')';
    ctx.fill();
    /* ball */
    var bg = ctx.createRadialGradient(bp.x - bp.r * 0.35, bp.y - bp.r * 0.4, 2, bp.x, bp.y, bp.r + 2);
    bg.addColorStop(0, '#ffffff');
    bg.addColorStop(0.65, '#eef1f6');
    bg.addColorStop(1, '#a7b6c9');
    ctx.beginPath();
    ctx.arc(bp.x, bp.y, bp.r, 0, Math.PI * 2);
    ctx.fillStyle = bg;
    ctx.fill();
  }
  function drawTrail() {
    ctx.save();
    tablePath(ctx, 0.02);
    ctx.clip();
    for (var i = 0; i < trail.length; i++) {
      var p = proj(trail[i].x, trail[i].z, trail[i].h);
      var a = (i / trail.length) * 0.16;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r * (0.35 + 0.5 * i / trail.length), 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255,255,255,' + a.toFixed(3) + ')';
      ctx.fill();
    }
    ctx.restore();
  }
  function drawParticles() {
    if (!particles.length) return;
    ctx.save();
    tablePath(ctx, 0.05);          /* effects never leave the table bounds */
    ctx.clip();
    for (var i = 0; i < particles.length; i++) {
      var p = particles[i];
      ctx.globalAlpha = Math.max(0, 1 - p.t / p.life);
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = p.color;
      ctx.fill();
    }
    ctx.restore();
    ctx.globalAlpha = 1;
  }
  function drawChips() {
    /* stacked corner score boxes, broadcast style (top-right) */
    var x0 = W - 316, wChip = 292;
    for (var i = 0; i < 2; i++) {
      var y0 = 22 + i * 76;
      ctx.fillStyle = 'rgba(5,12,26,0.82)';
      rr(ctx, x0, y0, wChip, 64, 12); ctx.fill();
      ctx.fillStyle = players[i].color;
      ctx.fillRect(x0, y0 + 8, 10, 48);
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.font = '800 25px -apple-system, "Segoe UI", Roboto, sans-serif';
      ctx.fillStyle = '#ffffff';
      var nm = players[i].name.toUpperCase();
      if (nm.length > 10) nm = nm.slice(0, 10);
      ctx.fillText('P' + (i + 1) + '  ' + nm, x0 + 24, y0 + 33);
      var sc = scores[i];
      var pulse = (lastScorer === i && pointFlash > 0) ? 1 + pointFlash * 0.3 : 1;
      ctx.font = '900 ' + Math.round(40 * pulse) + 'px -apple-system, "Segoe UI", Roboto, sans-serif';
      ctx.textAlign = 'right';
      ctx.fillStyle = players[i].color;
      ctx.fillText(String(sc), x0 + wChip - 18, y0 + 33);
      if (server === i && phase !== 'over' && phase !== 'lobby') {
        ctx.beginPath();
        ctx.arc(x0 + wChip - 52, y0 + 33, 7, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.fill();
      }
    }
    ctx.textAlign = 'right';
    ctx.font = '700 22px -apple-system, "Segoe UI", Roboto, sans-serif';
    ctx.fillStyle = 'rgba(184,196,214,0.92)';
    ctx.fillText('GAMES  ' + games[0] + ' — ' + games[1], x0 + wChip, 22 + 2 * 76 + 8);
    ctx.textAlign = 'left';
    ctx.font = '800 24px -apple-system, "Segoe UI", Roboto, sans-serif';
    ctx.fillStyle = 'rgba(255,255,255,0.85)';
    ctx.fillText('MOTION ARENA', 24, 46);
  }
  function draw(now) {
    /* FULL repaint every frame, sized from the runtime backing
       store — never assumed (TV trail-persistence finding). */
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (!staticLayer) buildStatic();
    if (!netLayer) buildNet();
    ctx.drawImage(staticLayer, 0, 0);
    drawCrowd(now);
    drawAvatar(now);
    if (quality === 2 && phase === 'rally') drawTrail();
    if (phase === 'lobby') {
      ball.x = 0; ball.z = 0; ball.h = 0.16 + Math.sin(now / 620) * 0.03;
      drawBall();
    } else if (phase !== 'point' || ball.live) {
      if (phase === 'serve' || ball.live) drawBall();
    }
    ctx.drawImage(netLayer, 0, 0);
    drawParticles();
    drawNearBat(now);
    drawChips();
    /* centre flashes: grades, LET, net cord, change of ends */
    if (flash.dur > 0) {
      var fa = flash.t < 0.12 ? flash.t / 0.12 : Math.max(0, 1 - (flash.t - flash.dur * 0.6) / (flash.dur * 0.4));
      ctx.globalAlpha = S.clamp(fa, 0, 1);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '900 84px -apple-system, "Segoe UI", Roboto, sans-serif';
      ctx.fillStyle = flash.color;
      ctx.fillText(flash.text, W / 2, 218);
      if (flash.sub) {
        ctx.font = '700 30px -apple-system, "Segoe UI", Roboto, sans-serif';
        ctx.fillStyle = 'rgba(255,255,255,0.92)';
        ctx.fillText(flash.sub, W / 2, 276);
      }
      ctx.globalAlpha = 1;
    }
    /* point banner */
    if (phase === 'point' && lastScorer >= 0 && !letReplay) {
      var sc2 = 0.75 + pointFlash * 0.4;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '900 ' + Math.round(88 * sc2) + 'px -apple-system, "Segoe UI", Roboto, sans-serif';
      ctx.fillStyle = players[lastScorer].color;
      ctx.fillText('POINT — ' + players[lastScorer].name.toUpperCase(), W / 2, H / 2 - 30);
      ctx.font = '700 30px -apple-system, "Segoe UI", Roboto, sans-serif';
      ctx.fillStyle = 'rgba(255,255,255,0.92)';
      ctx.fillText((pointReason ? pointReason + ' · ' : '') + 'rally: ' + rallyHits + ' hits', W / 2, H / 2 + 36);
    }
    /* serve hint */
    if (phase === 'serve') {
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = '800 27px -apple-system, "Segoe UI", Roboto, sans-serif';
      ctx.fillStyle = 'rgba(255,255,255,0.95)';
      ctx.fillText(players[server].name + ' to serve', W / 2, H - 118);
      ctx.font = '700 24px -apple-system, "Segoe UI", Roboto, sans-serif';
      ctx.fillStyle = 'rgba(184,196,214,0.95)';
      var sc3 = controllerOf(sideOfPlayer(server));
      var hint = sc3 === 'phone-swing' || sc3 === 'phone-auto' ? 'Serve from the phone — or it serves itself'
        : sc3 === 'ai' || sc3 === 'bot' ? 'Computer serves…'
        : 'Press ENTER or tap to serve';
      ctx.fillText(hint, W / 2, H - 82);
    }
    if (paused) {
      ctx.fillStyle = 'rgba(4,9,20,0.45)';
      ctx.fillRect(0, 0, W, H);
    }
  }

  /* ---------------- networking (PeerJS + relay fallback) ----------------
     Two transports, one protocol. WebRTC (PeerJS) is tried first;
     ~6 s after the host is up, a relay listener joins it (MQTT over
     secure WebSocket via relay.js) for phones whose direct data
     connection never completes — the Samsung TV case. A phone that
     falls back to the relay lands in the same setupConn() below. */
  var net = {
    peer: null, status: 'idle', code: '', tries: 0,
    players: [null, null],       // player -> {conn, name, color, token, mode}
    reserved: [null, null],      // player -> {token, name, color, mode, until}
    spectators: [],
    openTimer: null,
    lastIncoming: null,
    relayPeer: null, relayStatus: 'off', relayTimer: null, relayCode: ''
  };
  function controllerUrl() {
    var base = window.location.href.split('#')[0].split('?')[0];
    var last = base.substring(base.lastIndexOf('/') + 1);
    /* Folder loaded WITHOUT a trailing slash (e.g. /arena, which
       Vercel serves 200 without redirecting): the final segment has
       no file extension, so it names the folder itself and the
       controller lives INSIDE it. A segment with an extension is a
       file (host.html / index.html) and the controller is its
       sibling. Either way the result is the controller.html of the
       folder the host page actually lives in. */
    if (last && last.indexOf('.') === -1) base += '/';
    return base.substring(0, base.lastIndexOf('/') + 1) + 'controller.html';
  }
  function setDot(cls) {
    var d = document.getElementById('netDot');
    d.className = 'dot' + (cls ? ' ' + cls : '');
  }
  function netOffline(reason) {
    net.status = 'offline';
    if (net.relayStatus !== 'online') setDot('off');
    scheduleRelay(600);
    var b = document.getElementById('netBanner');
    b.innerHTML = '';
    var span = document.createElement('span');
    span.textContent = '📱 Phone controllers need an internet connection (they reach this TV through a cloud link) — none was found (' +
      reason + '). The game still works right here: 1 Player vs Computer, or 2 Players on this screen.';
    var btn = document.createElement('button');
    btn.className = 'btn btn-outline';
    btn.textContent = 'Retry phone connection';
    btn.addEventListener('click', function () { b.classList.add('hidden'); initPeer(); });
    b.appendChild(span);
    b.appendChild(btn);
    b.classList.remove('hidden');
  }
  function showLobbyLink() {
    var link = net.status === 'online' || net.relayStatus === 'online';
    if (!link) return;
    var how = net.status === 'online' && net.relayStatus === 'online' ? ' (direct + relay links live)'
      : net.relayStatus === 'online' ? ' (relay link live)' : '';
    document.getElementById('lobbyHint').textContent =
      'Phone controller: ' + controllerUrl() + ' — enter room code ' + net.code + '.' + how;
  }
  function scheduleRelay(delayMs) {
    if (!S.relayEnabled() || typeof window.RelayPeer === 'undefined') { net.relayStatus = 'off'; return; }
    if (net.relayPeer || net.relayTimer) return;
    net.relayStatus = 'waiting';
    net.relayTimer = setTimeout(function () {
      net.relayTimer = null;
      startRelay();
    }, delayMs == null ? 6000 : delayMs);
  }
  function startRelay() {
    if (net.relayPeer || !S.relayEnabled() || typeof window.RelayPeer === 'undefined') return;
    net.relayStatus = 'connecting';
    net.relayCode = net.code;
    var rp;
    try {
      rp = new window.RelayPeer(S.peerIdFor(net.code));
    } catch (e) {
      net.relayStatus = 'error';
      return;
    }
    net.relayPeer = rp;
    rp.on('open', function () {
      net.relayStatus = 'online';
      setDot('on');
      document.getElementById('netBanner').classList.add('hidden');
      showLobbyLink();
    });
    rp.on('connection', setupConn);
    rp.on('disconnected', function () {
      if (net.relayStatus === 'online') {
        net.relayStatus = 'connecting';
        try { rp.reconnect(); } catch (e) {}
      }
    });
    rp.on('error', function () {
      if (net.relayStatus !== 'online') net.relayStatus = 'error';
    });
  }
  function initPeer() {
    // Room code FIRST: the TV must show a code even when the phone
    // library itself failed to load on an old TV browser.
    net.code = S.makeRoomCode();
    document.getElementById('roomCode').textContent = net.code;
    if (net.relayPeer && net.relayCode !== net.code) {
      try { net.relayPeer.destroy(); } catch (e) {}
      net.relayPeer = null;
      net.relayStatus = 'off';
    }
    if (typeof window.Peer === 'undefined') { netOffline('controller library unavailable'); return; }
    net.status = 'connecting';
    setDot('');
    var peer;
    try {
      peer = new window.Peer(S.peerIdFor(net.code), S.brokerOptions());
    } catch (e) {
      netOffline('connection setup failed');
      return;
    }
    net.peer = peer;
    clearTimeout(net.openTimer);
    net.openTimer = setTimeout(function () {
      if (net.status !== 'online') { try { peer.destroy(); } catch (e) {} netOffline('timed out'); }
    }, 9000);
    peer.on('open', function () {
      net.status = 'online';
      net.tries = 0;
      clearTimeout(net.openTimer);
      setDot('on');
      document.getElementById('netBanner').classList.add('hidden');
      showLobbyLink();
      scheduleRelay(S.paramInt('relayWait', 6000));
    });
    peer.on('connection', setupConn);
    peer.on('disconnected', function () { if (net.status === 'online') { try { peer.reconnect(); } catch (e) {} } });
    peer.on('error', function (err) {
      var type = err && err.type ? err.type : 'unknown';
      if (type === 'unavailable-id' && net.tries < 3) {
        net.tries++;
        try { peer.destroy(); } catch (e) {}
        initPeer();
        return;
      }
      if (net.status !== 'online') netOffline(type);
    });
  }
  function setupConn(conn) {
    net.lastIncoming = conn.peer || null;
    var entry = { conn: conn, player: -1, name: '', color: '', token: '', mode: 'touch',
                  transport: conn.transport || 'webrtc', gender: '' };
    conn.on('data', function (data) {
      if (!data || typeof data !== 'object') return;
      if (data.t === 'join') {
        entry.name = String(data.name || 'Player').slice(0, 14);
        entry.color = String(data.color || S.COLORS[0].hex);
        entry.token = String(data.token || '');
        if (data.mode === 'swing' || data.mode === 'touch') entry.mode = data.mode;
        if (data.gender === 'male' || data.gender === 'female') entry.gender = data.gender;
        var p = -1, i;
        if (entry.token) {           // reclaim a reserved player slot
          for (i = 0; i < 2; i++) {
            if (net.reserved[i] && net.reserved[i].token === entry.token &&
                net.reserved[i].until > performance.now()) { p = i; break; }
          }
          if (p >= 0) net.reserved[p] = null;
        }
        if (p === -1) { for (i = 0; i < 2; i++) { if (!net.players[i] && !liveReservation(i)) { p = i; break; } } }
        entry.player = p;
        if (p >= 0) {
          net.players[p] = entry;
          players[p].name = entry.name;
          players[p].color = entry.color;
          if (entry.gender) players[p].gender = entry.gender;
          players[p].kind = 'phone';
          if (phase === 'lobby') mode = 'phone';
          conn.send({ t: 'welcome', player: p, side: p, name: entry.name, color: entry.color,
                      gender: players[p].gender, transport: entry.transport });
        } else {
          net.spectators.push(entry);
          conn.send({ t: 'full' });
        }
        refreshJoined();
        sendNetState();
      } else if (data.t === 'ping') {
        /* clock sync: answer with the host wall clock; the phone
           derives its offset from the round trip's midpoint */
        try { conn.send({ t: 'pong', id: data.id, t0: data.t0, th: Date.now() }); } catch (e) {}
      } else if (data.t === 'pad' && entry.player >= 0) {
        var v = parseFloat(data.x != null ? data.x : data.y);
        if (!isNaN(v)) {
          var pb = bats[sideOfPlayer(entry.player)];
          var newTarget = T.batMin + S.clamp(v, 0, 1) * (T.batMax - T.batMin);
          var pNow = performance.now();
          if (pb.padAt > 0 && pNow > pb.padAt) {
            var instVel = (newTarget - pb.target) / ((pNow - pb.padAt) / 1000);
            pb.padVel = S.clamp(pb.padVel * 0.5 + instVel * 0.5, -3, 3);
          }
          pb.target = newTarget;
          pb.padAt = pNow;
        }
      } else if (data.t === 'ctrl' && entry.player >= 0) {
        if (data.mode === 'swing' || data.mode === 'touch') entry.mode = data.mode;
      } else if (data.t === 'swing' && entry.player >= 0) {
        var pw = parseFloat(data.power);
        var atMs = performance.now();
        var compensated = false;
        if (typeof data.ts === 'number' && isFinite(data.ts)) {
          /* the phone stamped the swing's true moment in host wall
             time; convert onto this page's performance timeline —
             transit and detection lag stop eating the grade window */
          var conv = data.ts - (Date.now() - performance.now());
          if (Math.abs(conv - atMs) < 2500) { atMs = conv; compensated = true; }
        }
        lastSwingTiming = { deltaMs: flight ? Math.round(atMs - flight.tPlane) : null,
                            compensated: compensated };
        onSwing(entry.player, isNaN(pw) ? 0.7 : S.clamp(pw, 0, 1), atMs);
      } else if (data.t === 'serve' && entry.player >= 0) {
        if (phase === 'serve' && entry.player === server) launchServe();
        else if (phase === 'lobby') startMatch('phone');
        else if (phase === 'over') playAgain();
      }
    });
    conn.on('close', function () {
      if (entry.player >= 0 && net.players[entry.player] === entry) {
        net.players[entry.player] = null;
        /* hold the player's slot for 60 s so a dropped phone reclaims
           ITS player (and its end) on reconnect — no reload, no steal */
        net.reserved[entry.player] = { token: entry.token, name: entry.name, color: entry.color,
                                       mode: entry.mode, gender: entry.gender,
                                       until: performance.now() + 60000 };
        players[entry.player].kind = mode === 'local' || entry.player === 0 ? 'human' : 'ai';
        applyModeIdentities();
      }
      var si = net.spectators.indexOf(entry);
      if (si >= 0) net.spectators.splice(si, 1);
      refreshJoined();
      sendNetState();
    });
  }
  function liveReservation(p) {
    return net.reserved[p] && net.reserved[p].until > performance.now();
  }
  function sendNetState() {
    var base = { t: 'state', phase: phase, mode: mode, scores: scores.slice(),
      names: [players[0].name, players[1].name], colors: [players[0].color, players[1].color],
      genders: [players[0].gender, players[1].gender],
      games: games.slice(), server: server, paused: paused,
      grade: lastGrade.player >= 0 && performance.now() - lastGrade.at < 2500
        ? { player: lastGrade.player, grade: lastGrade.grade } : null };
    var all = net.players.concat(net.spectators);
    for (var i = 0; i < all.length; i++) {
      var e = all[i];
      if (!e || !e.conn || !e.conn.open) continue;
      var msg = {}; for (var k in base) msg[k] = base[k];
      msg.you = e.player;
      msg.yourServe = e.player === server && phase === 'serve';
      msg.yourEnd = e.player >= 0 ? (sideOfPlayer(e.player) === 0 ? 'NEAR' : 'FAR') : '';
      try { e.conn.send(msg); } catch (err) {}
    }
  }
  setInterval(sendNetState, 1000);
  function refreshJoined() {
    var list = document.getElementById('joinedList');
    list.innerHTML = '';
    var any = false;
    for (var i = 0; i < 2; i++) {
      var e = net.players[i];
      if (!e) continue;
      any = true;
      var chip = document.createElement('span');
      chip.className = 'player-chip';
      chip.style.background = e.color;
      chip.textContent = '📱 ' + e.name + ' — P' + (i + 1) + (e.mode === 'swing' ? ' · SWING' : '') +
        (e.transport === 'relay' ? ' · RELAY' : ' · DIRECT');
      list.appendChild(chip);
    }
    if (!any) {
      var p = document.createElement('span');
      p.className = 'pill';
      p.textContent = 'No phones yet — the game still plays on this screen';
      list.appendChild(p);
    }
  }

  /* ---------------- pause ---------------- */
  function showPause() {
    if (phase !== 'serve' && phase !== 'rally' && phase !== 'point') return;
    paused = true;
    document.getElementById('pausePanel').classList.remove('hidden');
    document.getElementById('btnResume').focus();
    sendNetState();
  }
  function hidePause() {
    paused = false;
    var p = document.getElementById('pausePanel');
    if (p) p.classList.add('hidden');
    sendNetState();
  }
  function playAgain() {
    if (matchWinner >= 0) startMatch(mode); else nextGame();
  }

  /* ---------------- UI + input wiring ---------------- */
  function refreshSettings() {
    document.getElementById('btnDiff').innerHTML =
      '🎚 Difficulty: <b>' + diff().label + '</b>&nbsp; <small>(D)</small>';
    document.getElementById('btnSound').innerHTML =
      settings.sound ? '🔊 Sound: <b>On</b>&nbsp; <small>(N)</small>' : '🔇 Sound: <b>Off</b>&nbsp; <small>(N)</small>';
    refreshGenderButtons();
  }
  function genderLabel(p) {
    return players[p].gender === 'female' ? '♀ Female' : '♂ Male';
  }
  function refreshGenderButtons() {
    var you = document.getElementById('btnGenderYou');
    var cpu = document.getElementById('btnGenderCpu');
    if (you) you.innerHTML = '🧑 You: <b>' + genderLabel(0) + '</b>&nbsp; <small>(G)</small>';
    if (cpu) cpu.innerHTML = '🤖 Computer: <b>' + genderLabel(1) + '</b>&nbsp; <small>(H)</small>';
  }
  function cycleGender(p) {
    lobbyGender[p] = lobbyGender[p] === 'male' ? 'female' : 'male';
    if (!net.players[p]) players[p].gender = lobbyGender[p];
    refreshGenderButtons();
    sendNetState();
  }
  function cycleDifficulty() {
    var idx = S.DIFFICULTY_ORDER.indexOf(settings.difficulty);
    settings.difficulty = S.DIFFICULTY_ORDER[(idx + 1) % S.DIFFICULTY_ORDER.length];
    refreshSettings();
  }
  function toggleSound() {
    settings.sound = !settings.sound;
    if (settings.sound) ensureAudio();
    refreshSettings();
  }
  document.getElementById('btnModeAI').addEventListener('click', function () { startMatch('ai'); });
  document.getElementById('btnModeLocal').addEventListener('click', function () { startMatch('local'); });
  document.getElementById('btnModePhone').addEventListener('click', function () { startMatch('phone'); });
  document.getElementById('btnAgain').addEventListener('click', playAgain);
  document.getElementById('btnLobby').addEventListener('click', toLobby);
  document.getElementById('btnDiff').addEventListener('click', cycleDifficulty);
  document.getElementById('btnSound').addEventListener('click', toggleSound);
  document.getElementById('btnGenderYou').addEventListener('click', function () { cycleGender(0); });
  document.getElementById('btnGenderCpu').addEventListener('click', function () { cycleGender(1); });
  document.getElementById('btnResume').addEventListener('click', hidePause);
  document.getElementById('btnRestartGame').addEventListener('click', function () { hidePause(); startMatch(mode); });
  document.getElementById('btnPauseLobby').addEventListener('click', function () { hidePause(); toLobby(); });

  document.addEventListener('keydown', function (e) {
    keys[e.code] = true;
    if (e.code === 'ArrowUp' || e.code === 'ArrowDown' || e.code === 'ArrowLeft' || e.code === 'ArrowRight' || e.code === 'Space') e.preventDefault();
    var onButton = document.activeElement && document.activeElement.tagName === 'BUTTON';
    if (e.code === 'KeyP') {
      if (paused) hidePause(); else showPause();
      return;
    }
    if (e.code === 'Escape') {
      if (paused) { hidePause(); return; }
      if (phase === 'over') { toLobby(); return; }
      if (phase !== 'lobby') { showPause(); return; }
    }
    if (paused) return;
    /* lobby shortcuts work even while a mode button holds focus —
       on a TV the focus starts on a button, and D/N/1/2/3 are not
       button-activation keys */
    if (phase === 'lobby') {
      if (e.code === 'Digit1') { startMatch('ai'); return; }
      if (e.code === 'Digit2') { startMatch('local'); return; }
      if (e.code === 'Digit3') { startMatch('phone'); return; }
      if (e.code === 'KeyD') { cycleDifficulty(); return; }
      if (e.code === 'KeyN') { toggleSound(); return; }
      if (e.code === 'KeyG') { cycleGender(0); return; }
      if (e.code === 'KeyH') { cycleGender(1); return; }
    }
    if (e.code === 'Enter' || e.code === 'Space') {
      if (onButton) return; // focused button handles it natively
      if (phase === 'lobby') startMatch('ai');
      else if (phase === 'serve' && controllerOf(sideOfPlayer(server)) === 'local') launchServe();
      else if (phase === 'over') playAgain();
    }
    if (e.code === 'KeyM' && phase !== 'lobby' && !paused) toLobby();
  });
  document.addEventListener('keyup', function (e) { keys[e.code] = false; });
  window.addEventListener('blur', function () {
    keys = {};
    if (!paused && (phase === 'serve' || phase === 'rally' || phase === 'point')) showPause();
  });

  function canvasPosX(e) {
    var r = canvas.getBoundingClientRect();
    var clientX = (e.touches && e.touches[0]) ? e.touches[0].clientX : e.clientX;
    return T.batMin + S.clamp((clientX - r.left) / r.width, 0, 1) * (T.batMax - T.batMin);
  }
  canvas.addEventListener('mousemove', function (e) {
    if (players[0].kind === 'human' && !net.players[0]) {
      bats[sideOfPlayer(0)].target = canvasPosX(e);
    }
  });
  canvas.addEventListener('touchstart', function (e) {
    e.preventDefault();
    if (phase === 'serve' && controllerOf(sideOfPlayer(server)) === 'local') launchServe();
  }, { passive: false });
  canvas.addEventListener('touchmove', function (e) {
    e.preventDefault();
    if (players[0].kind === 'human' && !net.players[0]) {
      bats[sideOfPlayer(0)].target = canvasPosX(e);
    }
  }, { passive: false });
  canvas.addEventListener('click', function () {
    if (phase === 'serve' && controllerOf(sideOfPlayer(server)) === 'local') launchServe();
  });

  /* ---------------- debug / test hooks (used by the check scripts) ---- */
  function bat01(side) { return (bats[side].x - T.batMin) / (T.batMax - T.batMin); }
  window.PP = {
    version: '1.3.1',
    getState: function () {
      return {
        phase: phase, mode: mode, paused: paused,
        scores: scores.slice(), games: games.slice(), gameNumber: gameNumber,
        server: server, firstServer: firstServer,
        endsSwapped: endsSwapped, switchedThisGame: switchedThisGame,
        gameWinner: gameWinner, matchWinner: matchWinner,
        winner: matchWinner >= 0 ? matchWinner : gameWinner,
        settings: { difficulty: settings.difficulty, sound: settings.sound },
        quality: quality, rallyHits: rallyHits, bestRally: bestRally,
        pointReason: pointReason,
        players: [
          { name: players[0].name, color: players[0].color, kind: players[0].kind, gender: players[0].gender },
          { name: players[1].name, color: players[1].color, kind: players[1].kind, gender: players[1].gender }
        ],
        ball3: { x: +ball.x.toFixed(3), z: +ball.z.toFixed(3), h: +ball.h.toFixed(3),
                 vx: +ball.vx.toFixed(2), vz: +ball.vz.toFixed(2), vh: +ball.vh.toFixed(2),
                 live: ball.live,
                 toSide: flight ? flight.toSide : -1, fromSide: flight ? flight.fromSide : -1,
                 serve: flight ? flight.serve : false, bounces: flight ? flight.bounces : 0,
                 cord: flight ? flight.cord : false,
                 tPlaneInMs: flight ? Math.max(0, Math.round(flight.tPlane - performance.now())) : -1 },
        bats: [Math.round(bats[0].x * 100) / 100, Math.round(bats[1].x * 100) / 100],
        bats01: [Math.round(bat01(0) * 1000) / 1000, Math.round(bat01(1) * 1000) / 1000],
        paddles: [Math.round(bat01(0) * 1000) / 1000, Math.round(bat01(1) * 1000) / 1000],
        avatar: { x01: Math.round(bat01(1) * 1000) / 1000, swing: avatar.swingT > 0, react: avatar.react,
                  gender: players[playerAtSide(1)].gender,
                  swingK: avatar.swingT > 0 ? Math.round(swingKOf(avatar) * 1000) / 1000 : -1,
                  swingPhase: avatar.swingT > 0 ? swingPose(swingKOf(avatar)).phase : 'ready',
                  crouch: Math.round(avatar.crouch * 100) / 100,
                  headT: Math.round(avatar.headT * 100) / 100,
                  reactBig: avatar.reactBig },
        crowd: { excite: Math.round(crowd.excite * 100) / 100,
                 wave: performance.now() < crowd.waveUntil,
                 dip: performance.now() < crowd.dipUntil,
                 plays: crowd.plays },
        audio: { on: settings.sound, ctxLive: !!AC, crowdPlays: crowd.plays },
        swingTiming: lastSwingTiming,
        lastGrade: { player: lastGrade.player, grade: lastGrade.grade },
        render: renderInfo,
        net: { status: net.status, code: net.code, sawIncoming: net.lastIncoming,
               sides: [!!net.players[0], !!net.players[1]],
               players: [!!net.players[0], !!net.players[1]],
               relayStatus: net.relayStatus,
               transports: [net.players[0] ? net.players[0].transport : null,
                            net.players[1] ? net.players[1].transport : null] }
      };
    },
    start: function (m) { startMatch(m || 'ai'); },
    serve: function () { launchServe(); },
    toLobby: function () { toLobby(); },
    playAgain: function () { playAgain(); },
    setScore: function (a, b) {
      scores = [a | 0, b | 0];
      var lead = Math.abs(scores[0] - scores[1]);
      if (Math.max(scores[0], scores[1]) >= S.WIN_SCORE && lead >= S.WIN_LEAD) {
        gameWinner = scores[0] > scores[1] ? 0 : 1;
        games[gameWinner]++;
        if (games[gameWinner] >= S.MATCH_GAMES_TO_WIN) matchWinner = gameWinner;
        phase = 'over';
        showGameOver();
      } else { updateServer(); setServe(); }
      sendNetState();
    },
    setGames: function (a, b) {
      games = [a | 0, b | 0];
      gameNumber = games[0] + games[1] + 1;
      sendNetState();
    },
    debugPoint: function (p) { scorePoint(p | 0, ''); },
    setPaddle: function (side, v01) {
      bats[side].x = bats[side].target = T.batMin + S.clamp(v01, 0, 1) * (T.batMax - T.batMin);
    },
    setPlayerBat: function (p, v01) {
      var side = sideOfPlayer(p);
      bats[side].x = bats[side].target = T.batMin + S.clamp(v01, 0, 1) * (T.batMax - T.batMin);
    },
    /* Construct a ball flight directly (rules + motion audits).
       opts: {serve, bounces, cord} preset the flight record. */
    testFlight: function (o) {
      var vz = o.vz || 0;
      var toSide = vz > 0 ? 1 : 0;
      ball.x = o.x; ball.z = o.z; ball.h = o.h;
      ball.vx = o.vx || 0; ball.vz = vz; ball.vh = o.vh || 0;
      ball.live = true;
      phase = 'rally';
      flight = { fromSide: 1 - toSide, toSide: toSide, serve: !!(o && o.serve),
                 bounces: (o && o.bounces != null) ? o.bounces : 0,
                 crossed: (toSide === 1 && ball.z > 0) || (toSide === 0 && ball.z < 0),
                 cord: !!(o && o.cord), tPlane: 0 };
      flight.tPlane = performance.now() + (((toSide === 1 ? T.planeZ : -T.planeZ) - ball.z) / vz) * 1000;
      trail.length = 0;
      sendNetState();
    },
    simSwing: function (player, power, deltaMs) {
      var at;
      if (flight && flight.toSide === sideOfPlayer(player)) at = flight.tPlane + (deltaMs || 0);
      else at = performance.now() + (deltaMs || 0);
      onSwing(player, power, at);
    },
    setDifficulty: function (d) {
      if (S.DIFFICULTY[d]) { settings.difficulty = d; refreshSettings(); }
    },
    setSound: function (on) { settings.sound = !!on; if (settings.sound) ensureAudio(); refreshSettings(); },
    pauseGame: function () { showPause(); },
    resumeGame: function () { hidePause(); },
    setQuality: function (q) { quality = q | 0; staticLayer = null; netLayer = null; },
    setRallyBot: function (on) { rallyBot = !!on; },
    debugAvatar: function (what) {
      if (what === 'swing') startSwing(1, false);
      else if (what === 'cheer' || what === 'slump') { avatar.react = what; avatar.reactT = 0.85; }
    },
    setGender: function (p, g) {
      if ((g === 'male' || g === 'female') && players[p | 0]) {
        lobbyGender[p | 0] = g;
        if (!net.players[p | 0]) players[p | 0].gender = g;
        refreshGenderButtons();
        sendNetState();
      }
    },
    debugCrowd: function (what) {
      if (what === 'point') { crowdPoint(12); crowdNoise(0.8, 0.9); }
      else if (what === 'wave') { crowdWave(); crowdNoise(1, 1.8); }
      else if (what === 'dip') crowdDip();
    },
    controllerUrl: function () { return controllerUrl(); },
    /* Simulated-peer hooks: run join/pad/swing/serve messages through
       the exact setupConn data handler a live PeerJS connection uses,
       with a stub transport. (The sandbox blocks WebRTC's UDP data
       plane, so the checks verify the wire at signaling level and the
       protocol through these hooks.) */
    simJoin: function (name, mode, opts) {
      opts = opts || {};
      var stub = { open: true, peer: 'simulated-peer', sent: [], _h: {},
        transport: opts.transport || 'webrtc',
        on: function (ev, fn) { this._h[ev] = fn; },
        send: function (m) { this.sent.push(m); },
        emit: function (ev, arg) { if (this._h[ev]) this._h[ev](arg); } };
      setupConn(stub);
      stub.emit('data', { t: 'join', name: name || 'Sim Player', color: S.COLORS[1].hex,
                          token: opts.token || 'sim-token', mode: mode || 'touch',
                          gender: opts.gender || undefined });
      var p = -1;
      for (var i = 0; i < stub.sent.length; i++) if (stub.sent[i].t === 'welcome') p = stub.sent[i].player;
      if (p >= 0) simStubs[p] = stub;
      return { side: p, player: p, sent: stub.sent };
    },
    simData: function (player, msg) {
      var stub = simStubs[player];
      if (stub) stub.emit('data', msg);
    },
    simState: function (player) {
      var stub = simStubs[player];
      if (!stub) return null;
      for (var i = stub.sent.length - 1; i >= 0; i--) if (stub.sent[i].t === 'state') return stub.sent[i];
      return null;
    },
    simClose: function (player) {
      var stub = simStubs[player];
      if (stub && stub._h.close) stub._h.close();
    }
  };
  var simStubs = [null, null];

  /* ---------------- main loop + boot ---------------- */
  var last = performance.now();
  function tick(now) {
    var dtMs = now - last;
    last = now;
    var dt = Math.min(0.033, dtMs / 1000);
    noteFrame(dtMs);
    if (!paused) update(dt);
    else { if (avatar.reactT > 0) { avatar.reactT = Math.max(0, avatar.reactT - dt); } stepParticles(dt); }
    draw(now);
    requestAnimationFrame(tick);
  }
  refreshJoined();
  refreshSettings();
  initPeer();
  document.getElementById('btnModeAI').focus();
  requestAnimationFrame(tick);
  if (typeof window.__ppBootDone === 'function') window.__ppBootDone();
})();
