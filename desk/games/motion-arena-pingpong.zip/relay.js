/* Motion Arena — Ping Pong: RELAY transport (build relay-1.3.1).
   A minimal MQTT 3.1.1 client over secure WebSocket, plus a
   PeerJS-shaped peer (window.RelayPeer) that carries the EXACT game
   wire protocol (join / welcome / pad / swing / ctrl / serve / state)
   through a public MQTT broker when the direct WebRTC data path
   cannot complete — the Samsung Tizen TV browser signals fine over
   WebRTC (green broker dot) but never finishes a data connection
   (proven on the real TV, 2026-11-14), while its plain WebSocket
   stack is the same one PeerJS signalling already uses successfully.

   Broker: EMQX public broker, wss://broker.emqx.io:8084/mqtt —
   chosen by a live two-client test (pub/sub + retained delivery)
   from the build sandbox on 2026-11-14; test.mosquitto.org was
   unreachable from there. QoS 0 throughout: the pad stream is
   continuous and self-healing, and state re-broadcasts every second.

   Topic scheme (app prefix + room code = per-room isolation):
     <prefix><CODE>/up/<cid>    controller -> host messages (JSON)
     <prefix><CODE>/down/<cid>  host -> that controller (JSON)
     <prefix><CODE>/x/<cid>     controller presence: its MQTT Last
                                Will lands here when it vanishes
     <prefix><CODE>/alive       retained "host is here" flag, set by
                                the host, cleared by its Last Will —
                                how a controller knows the room exists
                                before it joins (the relay equivalent
                                of PeerJS's peer-unavailable check).

   RelayPeer mirrors the slice of the PeerJS API the game uses:
   host:    new RelayPeer(peerId) + on('open'|'connection'|
            'disconnected'|'error'), reconnect(), destroy(), .id
   phone:   new RelayPeer() + on('open'|'error'), connect(peerId)
            -> conn with on('open'|'data'|'close'|'error'), .send(),
            .close(), .open, .peer — exactly like a PeerJS conn, so
            host.js setupConn() and controller.js drive it unchanged.
   Classic ES5 script: parses on the oldest engines the TV runs. */
(function (global) {
  'use strict';
  var S = global.PPShared;
  if (!S) return;

  /* ---------------- byte helpers ---------------- */
  function utf8Encode(str) {
    var s = unescape(encodeURIComponent(String(str)));
    var out = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) out[i] = s.charCodeAt(i) & 0xff;
    return out;
  }
  function utf8Decode(bytes) {
    var s = '';
    for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
    try { return decodeURIComponent(escape(s)); } catch (e) { return s; }
  }
  function concatArrays(list) {
    var n = 0, i;
    for (i = 0; i < list.length; i++) n += list[i].length;
    var out = new Uint8Array(n), off = 0;
    for (i = 0; i < list.length; i++) { out.set(list[i], off); off += list[i].length; }
    return out;
  }
  function bytesOf(arr) { return new Uint8Array(arr); }
  function encNum(n) { return bytesOf([(n >> 8) & 0xff, n & 0xff]); }
  function encStr(s) {
    var b = utf8Encode(s);
    return concatArrays([encNum(b.length), b]);
  }
  function encRL(n) {
    var a = [];
    do {
      var d = n % 128;
      n = Math.floor(n / 128);
      if (n > 0) d |= 0x80;
      a.push(d);
    } while (n > 0);
    return bytesOf(a);
  }
  function packet(header, payload) {
    return concatArrays([bytesOf([header]), encRL(payload.length), payload]);
  }

  /* ---------------- minimal MQTT client ---------------- */
  function MqttClient(url, opts) {
    this.url = url;
    this.clientId = opts.clientId;
    this.will = opts.will || null;          // {topic, payload, retain}
    this.keepAlive = opts.keepAlive || 30;  // seconds
    this.onConnect = null;                  // fn()
    this.onMessage = null;                  // fn(topic, payloadString)
    this.onClose = null;                    // fn()
    this.onError = null;                    // fn()
    this.connected = false;
    this._ws = null;
    this._buf = new Uint8Array(0);
    this._pktId = 0;
    this._pingTimer = null;
    this._dead = false;
  }
  MqttClient.prototype.connect = function () {
    var self = this;
    if (this._ws) { try { this._ws.close(); } catch (e) {} this._ws = null; }
    this._dead = false;
    this._buf = new Uint8Array(0);
    var ws;
    try {
      ws = new global.WebSocket(this.url, 'mqtt');
    } catch (e) {
      if (this.onError) this.onError(e);
      if (this.onClose) this.onClose();
      return;
    }
    this._ws = ws;
    ws.binaryType = 'arraybuffer';
    ws.onopen = function () {
      var flags = 0x02; // clean session
      var payload = [encStr(self.clientId)];
      if (self.will) {
        flags |= 0x04 | (self.will.retain ? 0x20 : 0);
        payload.push(encStr(self.will.topic));
        payload.push(encStr(self.will.payload || ''));
      }
      var vh = concatArrays([encStr('MQTT'), bytesOf(
        [4, flags, (self.keepAlive >> 8) & 0xff, self.keepAlive & 0xff])]);
      try { ws.send(packet(0x10, concatArrays([vh].concat(payload)))); } catch (e) {}
    };
    ws.onmessage = function (ev) {
      var data = new Uint8Array(ev.data);
      self._buf = concatArrays([self._buf, data]);
      self._drain();
    };
    ws.onerror = function () { if (self.onError) self.onError(new Error('websocket')); };
    ws.onclose = function () {
      var was = self.connected;
      self.connected = false;
      self._stopPing();
      self._ws = null;
      if (!self._dead && self.onClose) self.onClose(was);
    };
  };
  MqttClient.prototype._drain = function () {
    for (;;) {
      if (this._buf.length < 2) return;
      var mult = 1, len = 0, i = 1, b;
      do {
        if (i >= this._buf.length) return;
        b = this._buf[i++];
        len += (b & 0x7f) * mult;
        mult *= 128;
      } while (b & 0x80);
      if (this._buf.length < i + len) return;
      var header = this._buf[0];
      var body = this._buf.subarray(i, i + len);
      this._buf = this._buf.subarray(i + len);
      this._handle(header >> 4, header & 0x0f, body);
    }
  };
  MqttClient.prototype._handle = function (type, flags, body) {
    if (type === 2) { // CONNACK
      var rc = body.length >= 2 ? body[1] : 5;
      if (rc === 0) {
        this.connected = true;
        this._startPing();
        if (this.onConnect) this.onConnect();
      } else {
        if (this.onError) this.onError(new Error('connack ' + rc));
        try { this._ws.close(); } catch (e) {}
      }
    } else if (type === 3) { // PUBLISH
      var qos = (flags >> 1) & 0x03;
      if (body.length < 2) return;
      var tl = (body[0] << 8) | body[1];
      var topic = utf8Decode(body.subarray(2, 2 + tl));
      var off = 2 + tl + (qos > 0 ? 2 : 0);
      var payload = utf8Decode(body.subarray(off));
      if (this.onMessage) this.onMessage(topic, payload);
    }
    // SUBACK / PINGRESP / others: nothing the transport needs.
  };
  MqttClient.prototype._startPing = function () {
    var self = this;
    this._stopPing();
    var ms = Math.max(5000, (this.keepAlive * 750) | 0);
    this._pingTimer = setInterval(function () {
      if (self.connected && self._ws) {
        try { self._ws.send(packet(0xc0, new Uint8Array(0))); } catch (e) {}
      }
    }, ms);
  };
  MqttClient.prototype._stopPing = function () {
    if (this._pingTimer) { clearInterval(this._pingTimer); this._pingTimer = null; }
  };
  MqttClient.prototype.publish = function (topic, payload, retain) {
    if (!this.connected || !this._ws) return false;
    var body = concatArrays([encStr(topic), utf8Encode(payload == null ? '' : String(payload))]);
    try {
      this._ws.send(packet(retain ? 0x31 : 0x30, body));
      return true;
    } catch (e) { return false; }
  };
  MqttClient.prototype.subscribe = function (topics) {
    if (!this.connected || !this._ws) return;
    var parts = [encNum(++this._pktId & 0xffff || 1)];
    for (var i = 0; i < topics.length; i++) {
      parts.push(encStr(topics[i]));
      parts.push(bytesOf([0])); // QoS 0
    }
    try { this._ws.send(packet(0x82, concatArrays(parts))); } catch (e) {}
  };
  MqttClient.prototype.disconnect = function () {
    this._dead = true;
    this._stopPing();
    if (this._ws) {
      try { if (this.connected) this._ws.send(packet(0xe0, new Uint8Array(0))); } catch (e) {}
      try { this._ws.close(); } catch (e) {}
      this._ws = null;
    }
    this.connected = false;
  };

  /* ---------------- topics ---------------- */
  function topicBase(code) { return S.RELAY_PREFIX + String(code).toUpperCase() + '/'; }
  function codeFromPeerId(id) {
    var s = String(id || '');
    if (s.indexOf(S.PEER_PREFIX) === 0) s = s.substring(S.PEER_PREFIX.length);
    return s.toUpperCase();
  }
  function randomId(prefix) {
    return prefix + Math.random().toString(36).slice(2, 10);
  }

  /* ---------------- connection (PeerJS conn shape) ---------------- */
  function RelayConn(peer, remoteLabel) {
    this.peer = remoteLabel;      // PeerJS exposes the remote id here
    this.transport = 'relay';
    this.open = false;
    this._peer = peer;
    this._h = {};
    this._closed = false;
  }
  RelayConn.prototype.on = function (ev, fn) { this._h[ev] = fn; };
  RelayConn.prototype._emit = function (ev, arg) {
    if (this._h[ev]) { try { this._h[ev](arg); } catch (e) {} }
  };
  RelayConn.prototype.send = function (msg) {
    if (this._closed) return false;
    return this._peer._sendTo(this, msg);
  };
  RelayConn.prototype.close = function () {
    if (this._closed) return;
    this._closed = true;
    this.open = false;
    this._peer._connClosed(this, false);
  };
  RelayConn.prototype._forceClose = function () {
    if (this._closed) return;
    this._closed = true;
    this.open = false;
    this._emit('close');
  };

  /* ---------------- peer (PeerJS shape) ---------------- */
  function RelayPeer(id, opts) {
    this._h = {};
    this.destroyed = false;
    this.transport = 'relay';
    this._opts = opts || {};
    this._conns = {};        // host role: cid -> RelayConn
    this._conn = null;       // client role: the single conn
    this._mqtt = null;
    this._wasOpen = false;
    this._connectWanted = false;
    if (id) {
      this.id = String(id);
      this._role = 'host';
      this._code = codeFromPeerId(id);
      this._clientId = 'mapp-h-' + this._code + '-' + randomId('');
    } else {
      this._role = 'client';
      this._cid = randomId('c');
      this.id = this._cid;
      // The room code may be given up front (opts.roomCode) so the
      // client's Last Will can name its presence topic in the very
      // first CONNECT packet.
      this._code = (opts && opts.roomCode) ? String(opts.roomCode).toUpperCase() : '';
    }
    this._openMqtt();
  }
  RelayPeer.prototype.on = function (ev, fn) {
    (this._h[ev] = this._h[ev] || []).push(fn);
  };
  RelayPeer.prototype._emit = function (ev, arg) {
    var list = this._h[ev] || [];
    for (var i = 0; i < list.length; i++) { try { list[i](arg); } catch (e) {} }
  };
  RelayPeer.prototype._topics = function () {
    var base = topicBase(this._code);
    return {
      up: base + 'up/',         // + cid
      down: base + 'down/',     // + cid
      bye: base + 'x/',         // + cid
      alive: base + 'alive'
    };
  };
  RelayPeer.prototype._openMqtt = function () {
    var self = this;
    var will = null;
    if (this._role === 'host') {
      // If the host dies without a goodbye, the broker clears its
      // retained alive flag — controllers then see the room is gone.
      will = { topic: this._topics().alive, payload: '', retain: true };
    } else if (this._cid && this._code) {
      // If the phone vanishes (tab killed, battery, tunnel), the
      // broker posts its goodbye so the host frees the slot at once.
      will = { topic: this._topics().bye + this._cid, payload: 'bye', retain: false };
    }
    var mqtt = new MqttClient(S.relayUrl(), {
      clientId: this._clientId || ('mapp-' + this._cid),
      will: will,
      keepAlive: 30
    });
    this._mqtt = mqtt;
    mqtt.onConnect = function () { self._onMqttConnect(); };
    mqtt.onMessage = function (topic, payload) { self._onMqttMessage(topic, payload); };
    mqtt.onClose = function () { self._onMqttClose(); };
    mqtt.onError = function () {
      if (!self._wasOpen && !self.destroyed) {
        self._emit('error', { type: 'network', message: 'relay broker unreachable' });
      }
    };
    mqtt.connect();
  };
  RelayPeer.prototype._onMqttConnect = function () {
    var t = this._topics();
    if (this._role === 'host') {
      this._mqtt.subscribe([t.up + '+', t.bye + '+']);
      this._mqtt.publish(t.alive, '1', true);
      this._wasOpen = true;
      this._emit('open', this.id);
    } else {
      this._wasOpen = true;
      this._emit('open', this.id);
      if (this._connectWanted && !this._conn) this._startConn();
      else if (this._conn && !this._conn._closed) this._subscribeConn();
    }
  };
  RelayPeer.prototype._onMqttClose = function () {
    if (this.destroyed) return;
    if (this._role === 'host') {
      // PeerJS parity: host treats a broker drop as 'disconnected'
      // and the game calls reconnect().
      var cids = Object.keys(this._conns);
      for (var i = 0; i < cids.length; i++) this._conns[cids[i]].open = false;
      this._emit('disconnected');
    } else if (this._conn && this._conn.open) {
      this._conn.open = false;
      this._conn._emit('close');
    }
  };
  RelayPeer.prototype.reconnect = function () {
    if (this.destroyed) return;
    if (this._mqtt && !this._mqtt.connected) this._mqtt.connect();
  };
  RelayPeer.prototype.destroy = function () {
    if (this.destroyed) return;
    this.destroyed = true;
    if (this._role === 'host') {
      var cids = Object.keys(this._conns);
      for (var i = 0; i < cids.length; i++) this._conns[cids[i]]._forceClose();
      if (this._mqtt && this._mqtt.connected) {
        this._mqtt.publish(this._topics().alive, '', true); // clear retained
      }
    } else if (this._conn && !this._conn._closed) {
      this._connClosed(this._conn, true);
    }
    if (this._mqtt) this._mqtt.disconnect();
  };

  /* -------- host role -------- */
  RelayPeer.prototype._onHostMessage = function (topic, payload) {
    var t = this._topics();
    if (topic.indexOf(t.bye) === 0) {
      var bcid = topic.substring(t.bye.length);
      var bc = this._conns[bcid];
      if (bc) { delete this._conns[bcid]; bc._forceClose(); }
      return;
    }
    if (topic.indexOf(t.up) !== 0) return;
    var cid = topic.substring(t.up.length);
    var conn = this._conns[cid];
    if (!conn) {
      conn = new RelayConn(this, cid);
      conn.open = true;
      conn._cid = cid;
      this._conns[cid] = conn;
      this._emit('connection', conn);
    }
    var msg;
    try { msg = JSON.parse(payload); } catch (e) { return; }
    conn._emit('data', msg);
  };
  RelayPeer.prototype._sendToHostConn = function (conn, msg) {
    if (!this._mqtt) return false;
    return this._mqtt.publish(this._topics().down + conn._cid, JSON.stringify(msg), false);
  };

  /* -------- client role -------- */
  RelayPeer.prototype.connect = function (targetId, opts) {
    this._code = codeFromPeerId(targetId);
    var conn = new RelayConn(this, String(targetId));
    conn._cid = this._cid;
    this._conn = conn;
    this._connectWanted = true;
    // Arm this client's Last Will now that the room is known, so a
    // vanished phone frees its slot on the host immediately.
    if (this._mqtt) {
      this._mqtt.will = { topic: this._topics().bye + this._cid, payload: 'bye', retain: false };
    }
    if (this._mqtt && this._mqtt.connected) this._startConn();
    return conn;
  };
  RelayPeer.prototype._startConn = function () { this._subscribeConn(); };
  RelayPeer.prototype._subscribeConn = function () {
    var t = this._topics();
    this._mqtt.subscribe([t.down + this._cid, t.alive]);
    var self = this;
    clearTimeout(this._aliveTimer);
    this._aliveTimer = setTimeout(function () {
      if (self._conn && !self._conn.open && !self._conn._closed && !self.destroyed) {
        // No retained alive flag: nobody is hosting this room on the
        // relay — the PeerJS 'peer-unavailable' situation.
        self._emit('error', { type: 'peer-unavailable', message: 'relay room not found' });
      }
    }, 4000);
  };
  RelayPeer.prototype._onClientMessage = function (topic, payload) {
    var t = this._topics();
    var conn = this._conn;
    if (!conn) return;
    if (topic === t.alive) {
      if (payload) {
        if (!conn.open && !conn._closed) {
          conn.open = true;
          clearTimeout(this._aliveTimer);
          conn._emit('open');
        }
      } else if (conn.open) {
        conn.open = false;
        conn._emit('close');
      }
      return;
    }
    if (topic === t.down + this._cid && conn.open) {
      var msg;
      try { msg = JSON.parse(payload); } catch (e) { return; }
      conn._emit('data', msg);
    }
  };
  RelayPeer.prototype._onMqttMessage = function (topic, payload) {
    if (this._role === 'host') this._onHostMessage(topic, payload);
    else this._onClientMessage(topic, payload);
  };
  RelayPeer.prototype._sendTo = function (conn, msg) {
    if (!this._mqtt || conn._closed) return false;
    if (this._role === 'host') return this._sendToHostConn(conn, msg);
    return this._mqtt.publish(this._topics().up + this._cid, JSON.stringify(msg), false);
  };
  RelayPeer.prototype._connClosed = function (conn, silent) {
    if (this._role === 'client') {
      // Say goodbye on the room's presence topic so the host frees
      // (reserves) the slot right away, like a data-channel close.
      if (this._mqtt && this._mqtt.connected && this._code) {
        this._mqtt.publish(this._topics().bye + this._cid, 'bye', false);
      }
      if (!silent) conn._emit('close');
    }
  };

  global.RelayPeer = RelayPeer;
  global.PPMqtt = MqttClient; // exposed for the relay audit harness
})(window);
